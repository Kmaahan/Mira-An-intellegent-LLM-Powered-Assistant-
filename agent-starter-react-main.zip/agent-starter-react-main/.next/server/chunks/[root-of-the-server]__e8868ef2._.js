module.exports = [
"[project]/node_modules/.pnpm/camelcase-keys@9.1.3/node_modules/camelcase-keys/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/node_modules__pnpm_cbe8f8b1._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/camelcase-keys@9.1.3/node_modules/camelcase-keys/index.js [app-route] (ecmascript)");
    });
});
}),
"[externals]/node:crypto [external] (node:crypto, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[externals]/node:crypto [external] (node:crypto, cjs)");
    });
});
}),
];