module.exports = [
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$",
    ()=>Ns,
    "A",
    ()=>rs,
    "B",
    ()=>Ro,
    "C",
    ()=>vo,
    "D",
    ()=>Es,
    "E",
    ()=>ds,
    "F",
    ()=>Ws,
    "G",
    ()=>Qo,
    "H",
    ()=>ps,
    "I",
    ()=>vs,
    "J",
    ()=>ss,
    "K",
    ()=>as,
    "L",
    ()=>No,
    "M",
    ()=>ns,
    "N",
    ()=>Ps,
    "O",
    ()=>Os,
    "P",
    ()=>As,
    "Q",
    ()=>Ss,
    "R",
    ()=>Wn,
    "S",
    ()=>gs,
    "T",
    ()=>bs,
    "U",
    ()=>Xi,
    "V",
    ()=>Is,
    "W",
    ()=>es,
    "X",
    ()=>Bt,
    "Y",
    ()=>is,
    "Z",
    ()=>Cs,
    "_",
    ()=>Fs,
    "a",
    ()=>js,
    "a0",
    ()=>us,
    "a1",
    ()=>B,
    "a2",
    ()=>Ms,
    "a3",
    ()=>Ds,
    "a4",
    ()=>Rs,
    "a5",
    ()=>Zo,
    "a6",
    ()=>Xo,
    "a7",
    ()=>ms,
    "a8",
    ()=>Ji,
    "a9",
    ()=>ls,
    "aA",
    ()=>Ys,
    "aB",
    ()=>Qs,
    "aC",
    ()=>Hs,
    "aa",
    ()=>Us,
    "ab",
    ()=>bo,
    "ac",
    ()=>$o,
    "ad",
    ()=>Js,
    "ae",
    ()=>Un,
    "af",
    ()=>Nn,
    "ag",
    ()=>Ts,
    "ah",
    ()=>Uo,
    "ai",
    ()=>kr,
    "aj",
    ()=>jn,
    "ak",
    ()=>Fn,
    "al",
    ()=>Xs,
    "am",
    ()=>$s,
    "an",
    ()=>Bo,
    "ao",
    ()=>Vs,
    "ap",
    ()=>qo,
    "aq",
    ()=>Yo,
    "ar",
    ()=>Bn,
    "as",
    ()=>Ho,
    "at",
    ()=>zo,
    "au",
    ()=>Jo,
    "av",
    ()=>Bs,
    "aw",
    ()=>jo,
    "ax",
    ()=>Vo,
    "ay",
    ()=>Ko,
    "az",
    ()=>Go,
    "b",
    ()=>_s,
    "c",
    ()=>qs,
    "d",
    ()=>xs,
    "e",
    ()=>os,
    "f",
    ()=>Ks,
    "g",
    ()=>wo,
    "h",
    ()=>ws,
    "i",
    ()=>zs,
    "j",
    ()=>Mo,
    "k",
    ()=>ks,
    "l",
    ()=>L,
    "m",
    ()=>Wo,
    "n",
    ()=>Gi,
    "o",
    ()=>go,
    "p",
    ()=>N,
    "q",
    ()=>fs,
    "r",
    ()=>fo,
    "s",
    ()=>Ls,
    "t",
    ()=>In,
    "u",
    ()=>Gs,
    "v",
    ()=>hs,
    "w",
    ()=>Do,
    "x",
    ()=>cs,
    "y",
    ()=>ys,
    "z",
    ()=>ts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/livekit-client@2.15.15_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.2_react-dom@19.1.1_react@19.1.1__react@19.1.1/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const De = Math.min, ae = Math.max, $e = Math.round, _e = Math.floor, Q = (e)=>({
        x: e,
        y: e
    }), Kn = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
}, Gn = {
    start: "end",
    end: "start"
};
function Et(e, t, n) {
    return ae(e, De(t, n));
}
function He(e, t) {
    return typeof e == "function" ? e(t) : e;
}
function ce(e) {
    return e.split("-")[0];
}
function ze(e) {
    return e.split("-")[1];
}
function qt(e) {
    return e === "x" ? "y" : "x";
}
function Kt(e) {
    return e === "y" ? "height" : "width";
}
function ve(e) {
    return [
        "top",
        "bottom"
    ].includes(ce(e)) ? "y" : "x";
}
function Gt(e) {
    return qt(ve(e));
}
function Qn(e, t, n) {
    n === void 0 && (n = !1);
    const r = ze(e), i = Gt(e), o = Kt(i);
    let s = i === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
    return t.reference[o] > t.floating[o] && (s = Ne(s)), [
        s,
        Ne(s)
    ];
}
function Jn(e) {
    const t = Ne(e);
    return [
        ot(e),
        t,
        ot(t)
    ];
}
function ot(e) {
    return e.replace(/start|end/g, (t)=>Gn[t]);
}
function Xn(e, t, n) {
    const r = [
        "left",
        "right"
    ], i = [
        "right",
        "left"
    ], o = [
        "top",
        "bottom"
    ], s = [
        "bottom",
        "top"
    ];
    switch(e){
        case "top":
        case "bottom":
            return n ? t ? i : r : t ? r : i;
        case "left":
        case "right":
            return t ? o : s;
        default:
            return [];
    }
}
function Zn(e, t, n, r) {
    const i = ze(e);
    let o = Xn(ce(e), n === "start", r);
    return i && (o = o.map((s)=>s + "-" + i), t && (o = o.concat(o.map(ot)))), o;
}
function Ne(e) {
    return e.replace(/left|right|bottom|top/g, (t)=>Kn[t]);
}
function er(e) {
    return {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        ...e
    };
}
function tr(e) {
    return typeof e != "number" ? er(e) : {
        top: e,
        right: e,
        bottom: e,
        left: e
    };
}
function Fe(e) {
    const { x: t, y: n, width: r, height: i } = e;
    return {
        width: r,
        height: i,
        top: n,
        left: t,
        right: t + r,
        bottom: n + i,
        x: t,
        y: n
    };
}
function Ct(e, t, n) {
    let { reference: r, floating: i } = e;
    const o = ve(t), s = Gt(t), a = Kt(s), c = ce(t), u = o === "y", l = r.x + r.width / 2 - i.width / 2, f = r.y + r.height / 2 - i.height / 2, v = r[a] / 2 - i[a] / 2;
    let d;
    switch(c){
        case "top":
            d = {
                x: l,
                y: r.y - i.height
            };
            break;
        case "bottom":
            d = {
                x: l,
                y: r.y + r.height
            };
            break;
        case "right":
            d = {
                x: r.x + r.width,
                y: f
            };
            break;
        case "left":
            d = {
                x: r.x - i.width,
                y: f
            };
            break;
        default:
            d = {
                x: r.x,
                y: r.y
            };
    }
    switch(ze(t)){
        case "start":
            d[s] -= v * (n && u ? -1 : 1);
            break;
        case "end":
            d[s] += v * (n && u ? -1 : 1);
            break;
    }
    return d;
}
const nr = async (e, t, n)=>{
    const { placement: r = "bottom", strategy: i = "absolute", middleware: o = [], platform: s } = n, a = o.filter(Boolean), c = await (s.isRTL == null ? void 0 : s.isRTL(t));
    let u = await s.getElementRects({
        reference: e,
        floating: t,
        strategy: i
    }), { x: l, y: f } = Ct(u, r, c), v = r, d = {}, m = 0;
    for(let p = 0; p < a.length; p++){
        const { name: g, fn: h } = a[p], { x, y: E, data: O, reset: b } = await h({
            x: l,
            y: f,
            initialPlacement: r,
            placement: v,
            strategy: i,
            middlewareData: d,
            rects: u,
            platform: s,
            elements: {
                reference: e,
                floating: t
            }
        });
        l = x ?? l, f = E ?? f, d = {
            ...d,
            [g]: {
                ...d[g],
                ...O
            }
        }, b && m <= 50 && (m++, typeof b == "object" && (b.placement && (v = b.placement), b.rects && (u = b.rects === !0 ? await s.getElementRects({
            reference: e,
            floating: t,
            strategy: i
        }) : b.rects), { x: l, y: f } = Ct(u, v, c)), p = -1);
    }
    return {
        x: l,
        y: f,
        placement: v,
        strategy: i,
        middlewareData: d
    };
};
async function Qt(e, t) {
    var n;
    t === void 0 && (t = {});
    const { x: r, y: i, platform: o, rects: s, elements: a, strategy: c } = e, { boundary: u = "clippingAncestors", rootBoundary: l = "viewport", elementContext: f = "floating", altBoundary: v = !1, padding: d = 0 } = He(t, e), m = tr(d), g = a[v ? f === "floating" ? "reference" : "floating" : f], h = Fe(await o.getClippingRect({
        element: (n = await (o.isElement == null ? void 0 : o.isElement(g))) == null || n ? g : g.contextElement || await (o.getDocumentElement == null ? void 0 : o.getDocumentElement(a.floating)),
        boundary: u,
        rootBoundary: l,
        strategy: c
    })), x = f === "floating" ? {
        x: r,
        y: i,
        width: s.floating.width,
        height: s.floating.height
    } : s.reference, E = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(a.floating)), O = await (o.isElement == null ? void 0 : o.isElement(E)) ? await (o.getScale == null ? void 0 : o.getScale(E)) || {
        x: 1,
        y: 1
    } : {
        x: 1,
        y: 1
    }, b = Fe(o.convertOffsetParentRelativeRectToViewportRelativeRect ? await o.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements: a,
        rect: x,
        offsetParent: E,
        strategy: c
    }) : x);
    return {
        top: (h.top - b.top + m.top) / O.y,
        bottom: (b.bottom - h.bottom + m.bottom) / O.y,
        left: (h.left - b.left + m.left) / O.x,
        right: (b.right - h.right + m.right) / O.x
    };
}
const rr = function(e) {
    return e === void 0 && (e = {}), {
        name: "flip",
        options: e,
        async fn (t) {
            var n, r;
            const { placement: i, middlewareData: o, rects: s, initialPlacement: a, platform: c, elements: u } = t, { mainAxis: l = !0, crossAxis: f = !0, fallbackPlacements: v, fallbackStrategy: d = "bestFit", fallbackAxisSideDirection: m = "none", flipAlignment: p = !0, ...g } = He(e, t);
            if ((n = o.arrow) != null && n.alignmentOffset) return {};
            const h = ce(i), x = ve(a), E = ce(a) === a, O = await (c.isRTL == null ? void 0 : c.isRTL(u.floating)), b = v || (E || !p ? [
                Ne(a)
            ] : Jn(a)), S = m !== "none";
            !v && S && b.push(...Zn(a, p, m, O));
            const C = [
                a,
                ...b
            ], $ = await Qt(t, g), M = [];
            let z = ((r = o.flip) == null ? void 0 : r.overflows) || [];
            if (l && M.push($[h]), f) {
                const G = Qn(i, s, O);
                M.push($[G[0]], $[G[1]]);
            }
            if (z = [
                ...z,
                {
                    placement: i,
                    overflows: M
                }
            ], !M.every((G)=>G <= 0)) {
                var T, _;
                const G = (((T = o.flip) == null ? void 0 : T.index) || 0) + 1, ke = C[G];
                if (ke) return {
                    data: {
                        index: G,
                        overflows: z
                    },
                    reset: {
                        placement: ke
                    }
                };
                let Se = (_ = z.filter((de)=>de.overflows[0] <= 0).sort((de, ne)=>de.overflows[1] - ne.overflows[1])[0]) == null ? void 0 : _.placement;
                if (!Se) switch(d){
                    case "bestFit":
                        {
                            var Z;
                            const de = (Z = z.filter((ne)=>{
                                if (S) {
                                    const re = ve(ne.placement);
                                    return re === x || // Create a bias to the `y` side axis due to horizontal
                                    // reading directions favoring greater width.
                                    re === "y";
                                }
                                return !0;
                            }).map((ne)=>[
                                    ne.placement,
                                    ne.overflows.filter((re)=>re > 0).reduce((re, Vn)=>re + Vn, 0)
                                ]).sort((ne, re)=>ne[1] - re[1])[0]) == null ? void 0 : Z[0];
                            de && (Se = de);
                            break;
                        }
                    case "initialPlacement":
                        Se = a;
                        break;
                }
                if (i !== Se) return {
                    reset: {
                        placement: Se
                    }
                };
            }
            return {};
        }
    };
};
async function ir(e, t) {
    const { placement: n, platform: r, elements: i } = e, o = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), s = ce(n), a = ze(n), c = ve(n) === "y", u = [
        "left",
        "top"
    ].includes(s) ? -1 : 1, l = o && c ? -1 : 1, f = He(t, e);
    let { mainAxis: v, crossAxis: d, alignmentAxis: m } = typeof f == "number" ? {
        mainAxis: f,
        crossAxis: 0,
        alignmentAxis: null
    } : {
        mainAxis: f.mainAxis || 0,
        crossAxis: f.crossAxis || 0,
        alignmentAxis: f.alignmentAxis
    };
    return a && typeof m == "number" && (d = a === "end" ? m * -1 : m), c ? {
        x: d * l,
        y: v * u
    } : {
        x: v * u,
        y: d * l
    };
}
const or = function(e) {
    return e === void 0 && (e = 0), {
        name: "offset",
        options: e,
        async fn (t) {
            var n, r;
            const { x: i, y: o, placement: s, middlewareData: a } = t, c = await ir(t, e);
            return s === ((n = a.offset) == null ? void 0 : n.placement) && (r = a.arrow) != null && r.alignmentOffset ? {} : {
                x: i + c.x,
                y: o + c.y,
                data: {
                    ...c,
                    placement: s
                }
            };
        }
    };
}, sr = function(e) {
    return e === void 0 && (e = {}), {
        name: "shift",
        options: e,
        async fn (t) {
            const { x: n, y: r, placement: i } = t, { mainAxis: o = !0, crossAxis: s = !1, limiter: a = {
                fn: (g)=>{
                    let { x: h, y: x } = g;
                    return {
                        x: h,
                        y: x
                    };
                }
            }, ...c } = He(e, t), u = {
                x: n,
                y: r
            }, l = await Qt(t, c), f = ve(ce(i)), v = qt(f);
            let d = u[v], m = u[f];
            if (o) {
                const g = v === "y" ? "top" : "left", h = v === "y" ? "bottom" : "right", x = d + l[g], E = d - l[h];
                d = Et(x, d, E);
            }
            if (s) {
                const g = f === "y" ? "top" : "left", h = f === "y" ? "bottom" : "right", x = m + l[g], E = m - l[h];
                m = Et(x, m, E);
            }
            const p = a.fn({
                ...t,
                [v]: d,
                [f]: m
            });
            return {
                ...p,
                data: {
                    x: p.x - n,
                    y: p.y - r,
                    enabled: {
                        [v]: o,
                        [f]: s
                    }
                }
            };
        }
    };
};
function Ye() {
    return "undefined" < "u";
}
function ye(e) {
    return Jt(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function W(e) {
    var t;
    return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function X(e) {
    var t;
    return (t = (Jt(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
}
function Jt(e) {
    return Ye() ? e instanceof Node || e instanceof W(e).Node : !1;
}
function q(e) {
    return Ye() ? e instanceof Element || e instanceof W(e).Element : !1;
}
function J(e) {
    return Ye() ? e instanceof HTMLElement || e instanceof W(e).HTMLElement : !1;
}
function Pt(e) {
    return !Ye() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof W(e).ShadowRoot;
}
function Oe(e) {
    const { overflow: t, overflowX: n, overflowY: r, display: i } = K(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && ![
        "inline",
        "contents"
    ].includes(i);
}
function ar(e) {
    return [
        "table",
        "td",
        "th"
    ].includes(ye(e));
}
function qe(e) {
    return [
        ":popover-open",
        ":modal"
    ].some((t)=>{
        try {
            return e.matches(t);
        } catch  {
            return !1;
        }
    });
}
function dt(e) {
    const t = pt(), n = q(e) ? K(e) : e;
    return [
        "transform",
        "translate",
        "scale",
        "rotate",
        "perspective"
    ].some((r)=>n[r] ? n[r] !== "none" : !1) || (n.containerType ? n.containerType !== "normal" : !1) || !t && (n.backdropFilter ? n.backdropFilter !== "none" : !1) || !t && (n.filter ? n.filter !== "none" : !1) || [
        "transform",
        "translate",
        "scale",
        "rotate",
        "perspective",
        "filter"
    ].some((r)=>(n.willChange || "").includes(r)) || [
        "paint",
        "layout",
        "strict",
        "content"
    ].some((r)=>(n.contain || "").includes(r));
}
function cr(e) {
    let t = oe(e);
    for(; J(t) && !me(t);){
        if (dt(t)) return t;
        if (qe(t)) return null;
        t = oe(t);
    }
    return null;
}
function pt() {
    return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none");
}
function me(e) {
    return [
        "html",
        "body",
        "#document"
    ].includes(ye(e));
}
function K(e) {
    return W(e).getComputedStyle(e);
}
function Ke(e) {
    return q(e) ? {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    } : {
        scrollLeft: e.scrollX,
        scrollTop: e.scrollY
    };
}
function oe(e) {
    if (ye(e) === "html") return e;
    const t = // Step into the shadow DOM of the parent of a slotted node.
    e.assignedSlot || // DOM Element detected.
    e.parentNode || // ShadowRoot detected.
    Pt(e) && e.host || // Fallback.
    X(e);
    return Pt(t) ? t.host : t;
}
function Xt(e) {
    const t = oe(e);
    return me(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : J(t) && Oe(t) ? t : Xt(t);
}
function Ee(e, t, n) {
    var r;
    t === void 0 && (t = []), n === void 0 && (n = !0);
    const i = Xt(e), o = i === ((r = e.ownerDocument) == null ? void 0 : r.body), s = W(i);
    if (o) {
        const a = st(s);
        return t.concat(s, s.visualViewport || [], Oe(i) ? i : [], a && n ? Ee(a) : []);
    }
    return t.concat(i, Ee(i, [], n));
}
function st(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function Zt(e) {
    const t = K(e);
    let n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0;
    const i = J(e), o = i ? e.offsetWidth : n, s = i ? e.offsetHeight : r, a = $e(n) !== o || $e(r) !== s;
    return a && (n = o, r = s), {
        width: n,
        height: r,
        $: a
    };
}
function ht(e) {
    return q(e) ? e : e.contextElement;
}
function pe(e) {
    const t = ht(e);
    if (!J(t)) return Q(1);
    const n = t.getBoundingClientRect(), { width: r, height: i, $: o } = Zt(t);
    let s = (o ? $e(n.width) : n.width) / r, a = (o ? $e(n.height) : n.height) / i;
    return (!s || !Number.isFinite(s)) && (s = 1), (!a || !Number.isFinite(a)) && (a = 1), {
        x: s,
        y: a
    };
}
const ur = /* @__PURE__ */ Q(0);
function en(e) {
    const t = W(e);
    return !pt() || !t.visualViewport ? ur : {
        x: t.visualViewport.offsetLeft,
        y: t.visualViewport.offsetTop
    };
}
function lr(e, t, n) {
    return t === void 0 && (t = !1), !n || t && n !== W(e) ? !1 : t;
}
function ue(e, t, n, r) {
    t === void 0 && (t = !1), n === void 0 && (n = !1);
    const i = e.getBoundingClientRect(), o = ht(e);
    let s = Q(1);
    t && (r ? q(r) && (s = pe(r)) : s = pe(e));
    const a = lr(o, n, r) ? en(o) : Q(0);
    let c = (i.left + a.x) / s.x, u = (i.top + a.y) / s.y, l = i.width / s.x, f = i.height / s.y;
    if (o) {
        const v = W(o), d = r && q(r) ? W(r) : r;
        let m = v, p = st(m);
        for(; p && r && d !== m;){
            const g = pe(p), h = p.getBoundingClientRect(), x = K(p), E = h.left + (p.clientLeft + parseFloat(x.paddingLeft)) * g.x, O = h.top + (p.clientTop + parseFloat(x.paddingTop)) * g.y;
            c *= g.x, u *= g.y, l *= g.x, f *= g.y, c += E, u += O, m = W(p), p = st(m);
        }
    }
    return Fe({
        width: l,
        height: f,
        x: c,
        y: u
    });
}
function vt(e, t) {
    const n = Ke(e).scrollLeft;
    return t ? t.left + n : ue(X(e)).left + n;
}
function tn(e, t, n) {
    n === void 0 && (n = !1);
    const r = e.getBoundingClientRect(), i = r.left + t.scrollLeft - (n ? 0 : // RTL <body> scrollbar.
    vt(e, r)), o = r.top + t.scrollTop;
    return {
        x: i,
        y: o
    };
}
function fr(e) {
    let { elements: t, rect: n, offsetParent: r, strategy: i } = e;
    const o = i === "fixed", s = X(r), a = t ? qe(t.floating) : !1;
    if (r === s || a && o) return n;
    let c = {
        scrollLeft: 0,
        scrollTop: 0
    }, u = Q(1);
    const l = Q(0), f = J(r);
    if ((f || !f && !o) && ((ye(r) !== "body" || Oe(s)) && (c = Ke(r)), J(r))) {
        const d = ue(r);
        u = pe(r), l.x = d.x + r.clientLeft, l.y = d.y + r.clientTop;
    }
    const v = s && !f && !o ? tn(s, c, !0) : Q(0);
    return {
        width: n.width * u.x,
        height: n.height * u.y,
        x: n.x * u.x - c.scrollLeft * u.x + l.x + v.x,
        y: n.y * u.y - c.scrollTop * u.y + l.y + v.y
    };
}
function dr(e) {
    return Array.from(e.getClientRects());
}
function pr(e) {
    const t = X(e), n = Ke(e), r = e.ownerDocument.body, i = ae(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth), o = ae(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight);
    let s = -n.scrollLeft + vt(e);
    const a = -n.scrollTop;
    return K(r).direction === "rtl" && (s += ae(t.clientWidth, r.clientWidth) - i), {
        width: i,
        height: o,
        x: s,
        y: a
    };
}
function hr(e, t) {
    const n = W(e), r = X(e), i = n.visualViewport;
    let o = r.clientWidth, s = r.clientHeight, a = 0, c = 0;
    if (i) {
        o = i.width, s = i.height;
        const u = pt();
        (!u || u && t === "fixed") && (a = i.offsetLeft, c = i.offsetTop);
    }
    return {
        width: o,
        height: s,
        x: a,
        y: c
    };
}
function vr(e, t) {
    const n = ue(e, !0, t === "fixed"), r = n.top + e.clientTop, i = n.left + e.clientLeft, o = J(e) ? pe(e) : Q(1), s = e.clientWidth * o.x, a = e.clientHeight * o.y, c = i * o.x, u = r * o.y;
    return {
        width: s,
        height: a,
        x: c,
        y: u
    };
}
function Ot(e, t, n) {
    let r;
    if (t === "viewport") r = hr(e, n);
    else if (t === "document") r = pr(X(e));
    else if (q(t)) r = vr(t, n);
    else {
        const i = en(e);
        r = {
            x: t.x - i.x,
            y: t.y - i.y,
            width: t.width,
            height: t.height
        };
    }
    return Fe(r);
}
function nn(e, t) {
    const n = oe(e);
    return n === t || !q(n) || me(n) ? !1 : K(n).position === "fixed" || nn(n, t);
}
function mr(e, t) {
    const n = t.get(e);
    if (n) return n;
    let r = Ee(e, [], !1).filter((a)=>q(a) && ye(a) !== "body"), i = null;
    const o = K(e).position === "fixed";
    let s = o ? oe(e) : e;
    for(; q(s) && !me(s);){
        const a = K(s), c = dt(s);
        !c && a.position === "fixed" && (i = null), (o ? !c && !i : !c && a.position === "static" && !!i && [
            "absolute",
            "fixed"
        ].includes(i.position) || Oe(s) && !c && nn(e, s)) ? r = r.filter((l)=>l !== s) : i = a, s = oe(s);
    }
    return t.set(e, r), r;
}
function gr(e) {
    let { element: t, boundary: n, rootBoundary: r, strategy: i } = e;
    const s = [
        ...n === "clippingAncestors" ? qe(t) ? [] : mr(t, this._c) : [].concat(n),
        r
    ], a = s[0], c = s.reduce((u, l)=>{
        const f = Ot(t, l, i);
        return u.top = ae(f.top, u.top), u.right = De(f.right, u.right), u.bottom = De(f.bottom, u.bottom), u.left = ae(f.left, u.left), u;
    }, Ot(t, a, i));
    return {
        width: c.right - c.left,
        height: c.bottom - c.top,
        x: c.left,
        y: c.top
    };
}
function br(e) {
    const { width: t, height: n } = Zt(e);
    return {
        width: t,
        height: n
    };
}
function yr(e, t, n) {
    const r = J(t), i = X(t), o = n === "fixed", s = ue(e, !0, o, t);
    let a = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const c = Q(0);
    if (r || !r && !o) if ((ye(t) !== "body" || Oe(i)) && (a = Ke(t)), r) {
        const v = ue(t, !0, o, t);
        c.x = v.x + t.clientLeft, c.y = v.y + t.clientTop;
    } else i && (c.x = vt(i));
    const u = i && !r && !o ? tn(i, a) : Q(0), l = s.left + a.scrollLeft - c.x - u.x, f = s.top + a.scrollTop - c.y - u.y;
    return {
        x: l,
        y: f,
        width: s.width,
        height: s.height
    };
}
function Ze(e) {
    return K(e).position === "static";
}
function At(e, t) {
    if (!J(e) || K(e).position === "fixed") return null;
    if (t) return t(e);
    let n = e.offsetParent;
    return X(e) === n && (n = n.ownerDocument.body), n;
}
function rn(e, t) {
    const n = W(e);
    if (qe(e)) return n;
    if (!J(e)) {
        let i = oe(e);
        for(; i && !me(i);){
            if (q(i) && !Ze(i)) return i;
            i = oe(i);
        }
        return n;
    }
    let r = At(e, t);
    for(; r && ar(r) && Ze(r);)r = At(r, t);
    return r && me(r) && Ze(r) && !dt(r) ? n : r || cr(e) || n;
}
const wr = async function(e) {
    const t = this.getOffsetParent || rn, n = this.getDimensions, r = await n(e.floating);
    return {
        reference: yr(e.reference, await t(e.floating), e.strategy),
        floating: {
            x: 0,
            y: 0,
            width: r.width,
            height: r.height
        }
    };
};
function xr(e) {
    return K(e).direction === "rtl";
}
const Sr = {
    convertOffsetParentRelativeRectToViewportRelativeRect: fr,
    getDocumentElement: X,
    getClippingRect: gr,
    getOffsetParent: rn,
    getElementRects: wr,
    getClientRects: dr,
    getDimensions: br,
    getScale: pe,
    isElement: q,
    isRTL: xr
};
function on(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function Tr(e, t) {
    let n = null, r;
    const i = X(e);
    function o() {
        var a;
        clearTimeout(r), (a = n) == null || a.disconnect(), n = null;
    }
    function s(a, c) {
        a === void 0 && (a = !1), c === void 0 && (c = 1), o();
        const u = e.getBoundingClientRect(), { left: l, top: f, width: v, height: d } = u;
        if (a || t(), !v || !d) return;
        const m = _e(f), p = _e(i.clientWidth - (l + v)), g = _e(i.clientHeight - (f + d)), h = _e(l), E = {
            rootMargin: -m + "px " + -p + "px " + -g + "px " + -h + "px",
            threshold: ae(0, De(1, c)) || 1
        };
        let O = !0;
        function b(S) {
            const C = S[0].intersectionRatio;
            if (C !== c) {
                if (!O) return s();
                C ? s(!1, C) : r = setTimeout(()=>{
                    s(!1, 1e-7);
                }, 1e3);
            }
            C === 1 && !on(u, e.getBoundingClientRect()) && s(), O = !1;
        }
        try {
            n = new IntersectionObserver(b, {
                ...E,
                // Handle <iframe>s
                root: i.ownerDocument
            });
        } catch  {
            n = new IntersectionObserver(b, E);
        }
        n.observe(e);
    }
    return s(!0), o;
}
function Er(e, t, n, r) {
    r === void 0 && (r = {});
    const { ancestorScroll: i = !0, ancestorResize: o = !0, elementResize: s = typeof ResizeObserver == "function", layoutShift: a = typeof IntersectionObserver == "function", animationFrame: c = !1 } = r, u = ht(e), l = i || o ? [
        ...u ? Ee(u) : [],
        ...Ee(t)
    ] : [];
    l.forEach((h)=>{
        i && h.addEventListener("scroll", n, {
            passive: !0
        }), o && h.addEventListener("resize", n);
    });
    const f = u && a ? Tr(u, n) : null;
    let v = -1, d = null;
    s && (d = new ResizeObserver((h)=>{
        let [x] = h;
        x && x.target === u && d && (d.unobserve(t), cancelAnimationFrame(v), v = requestAnimationFrame(()=>{
            var E;
            (E = d) == null || E.observe(t);
        })), n();
    }), u && !c && d.observe(u), d.observe(t));
    let m, p = c ? ue(e) : null;
    c && g();
    function g() {
        const h = ue(e);
        p && !on(p, h) && n(), p = h, m = requestAnimationFrame(g);
    }
    return n(), ()=>{
        var h;
        l.forEach((x)=>{
            i && x.removeEventListener("scroll", n), o && x.removeEventListener("resize", n);
        }), f == null || f(), (h = d) == null || h.disconnect(), d = null, c && cancelAnimationFrame(m);
    };
}
const Cr = or, Pr = sr, Or = rr, Ar = (e, t, n)=>{
    const r = /* @__PURE__ */ new Map(), i = {
        platform: Sr,
        ...n
    }, o = {
        ...i.platform,
        _c: r
    };
    return nr(e, t, {
        ...i,
        platform: o
    });
};
var Uo = typeof globalThis < "u" ? globalThis : "undefined" < "u" ? window : ("TURBOPACK compile-time value", "object") < "u" ? /*TURBOPACK member replacement*/ __turbopack_context__.g : typeof self < "u" ? self : {};
function kr(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Me = {
    exports: {}
}, _r = Me.exports, kt;
function Lr() {
    return kt || (kt = 1, function(e) {
        (function(t, n) {
            e.exports ? e.exports = n() : t.log = n();
        })(_r, function() {
            var t = function() {}, n = "undefined", r = "undefined" !== n && typeof window.navigator !== n && /Trident\/|MSIE /.test(window.navigator.userAgent), i = [
                "trace",
                "debug",
                "info",
                "warn",
                "error"
            ], o = {}, s = null;
            function a(p, g) {
                var h = p[g];
                if (typeof h.bind == "function") return h.bind(p);
                try {
                    return Function.prototype.bind.call(h, p);
                } catch  {
                    return function() {
                        return Function.prototype.apply.apply(h, [
                            p,
                            arguments
                        ]);
                    };
                }
            }
            function c() {
                console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [
                    console,
                    arguments
                ])), console.trace && console.trace();
            }
            function u(p) {
                return p === "debug" && (p = "log"), typeof console === n ? !1 : ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : console[p] !== void 0 ? a(console, p) : console.log !== void 0 ? a(console, "log") : t;
            }
            function l() {
                for(var p = this.getLevel(), g = 0; g < i.length; g++){
                    var h = i[g];
                    this[h] = g < p ? t : this.methodFactory(h, p, this.name);
                }
                if (this.log = this.debug, typeof console === n && p < this.levels.SILENT) return "No console available for logging";
            }
            function f(p) {
                return function() {
                    typeof console !== n && (l.call(this), this[p].apply(this, arguments));
                };
            }
            function v(p, g, h) {
                return u(p) || f.apply(this, arguments);
            }
            function d(p, g) {
                var h = this, x, E, O, b = "loglevel";
                typeof p == "string" ? b += ":" + p : typeof p == "symbol" && (b = void 0);
                function S(T) {
                    var _ = (i[T] || "silent").toUpperCase();
                    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                    ;
                }
                function C() {
                    var T;
                    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                    {
                        var _, Z, G;
                    }
                }
                function $() {
                    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                    ;
                }
                function M(T) {
                    var _ = T;
                    if (typeof _ == "string" && h.levels[_.toUpperCase()] !== void 0 && (_ = h.levels[_.toUpperCase()]), typeof _ == "number" && _ >= 0 && _ <= h.levels.SILENT) return _;
                    throw new TypeError("log.setLevel() called with invalid level: " + T);
                }
                h.name = p, h.levels = {
                    TRACE: 0,
                    DEBUG: 1,
                    INFO: 2,
                    WARN: 3,
                    ERROR: 4,
                    SILENT: 5
                }, h.methodFactory = g || v, h.getLevel = function() {
                    return O ?? E ?? x;
                }, h.setLevel = function(T, _) {
                    return O = M(T), _ !== !1 && S(O), l.call(h);
                }, h.setDefaultLevel = function(T) {
                    E = M(T), C() || h.setLevel(T, !1);
                }, h.resetLevel = function() {
                    O = null, $(), l.call(h);
                }, h.enableAll = function(T) {
                    h.setLevel(h.levels.TRACE, T);
                }, h.disableAll = function(T) {
                    h.setLevel(h.levels.SILENT, T);
                }, h.rebuild = function() {
                    if (s !== h && (x = M(s.getLevel())), l.call(h), s === h) for(var T in o)o[T].rebuild();
                }, x = M(s ? s.getLevel() : "WARN");
                var z = C();
                z != null && (O = M(z)), l.call(h);
            }
            s = new d(), s.getLogger = function(g) {
                if (typeof g != "symbol" && typeof g != "string" || g === "") throw new TypeError("You must supply a name when creating a logger.");
                var h = o[g];
                return h || (h = o[g] = new d(g, s.methodFactory)), h;
            };
            var m = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : void 0;
            return s.noConflict = function() {
                return "undefined" !== n && window.log === s && (window.log = m), s;
            }, s.getLoggers = function() {
                return o;
            }, s.default = s, s;
        });
    }(Me)), Me.exports;
}
var Ir = Lr();
const Mr = /* @__PURE__ */ kr(Ir);
var at = function(e, t) {
    return at = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(n, r) {
        n.__proto__ = r;
    } || function(n, r) {
        for(var i in r)Object.prototype.hasOwnProperty.call(r, i) && (n[i] = r[i]);
    }, at(e, t);
};
function te(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
    at(e, t);
    function n() {
        this.constructor = e;
    }
    e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
function Rr(e, t, n, r) {
    function i(o) {
        return o instanceof n ? o : new n(function(s) {
            s(o);
        });
    }
    return new (n || (n = Promise))(function(o, s) {
        function a(l) {
            try {
                u(r.next(l));
            } catch (f) {
                s(f);
            }
        }
        function c(l) {
            try {
                u(r.throw(l));
            } catch (f) {
                s(f);
            }
        }
        function u(l) {
            l.done ? o(l.value) : i(l.value).then(a, c);
        }
        u((r = r.apply(e, t || [])).next());
    });
}
function sn(e, t) {
    var n = {
        label: 0,
        sent: function() {
            if (o[0] & 1) throw o[1];
            return o[1];
        },
        trys: [],
        ops: []
    }, r, i, o, s = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
    return s.next = a(0), s.throw = a(1), s.return = a(2), typeof Symbol == "function" && (s[Symbol.iterator] = function() {
        return this;
    }), s;
    //TURBOPACK unreachable
    ;
    function a(u) {
        return function(l) {
            return c([
                u,
                l
            ]);
        };
    }
    function c(u) {
        if (r) throw new TypeError("Generator is already executing.");
        for(; s && (s = 0, u[0] && (n = 0)), n;)try {
            if (r = 1, i && (o = u[0] & 2 ? i.return : u[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, u[1])).done) return o;
            switch(i = 0, o && (u = [
                u[0] & 2,
                o.value
            ]), u[0]){
                case 0:
                case 1:
                    o = u;
                    break;
                case 4:
                    return n.label++, {
                        value: u[1],
                        done: !1
                    };
                case 5:
                    n.label++, i = u[1], u = [
                        0
                    ];
                    continue;
                case 7:
                    u = n.ops.pop(), n.trys.pop();
                    continue;
                default:
                    if (o = n.trys, !(o = o.length > 0 && o[o.length - 1]) && (u[0] === 6 || u[0] === 2)) {
                        n = 0;
                        continue;
                    }
                    if (u[0] === 3 && (!o || u[1] > o[0] && u[1] < o[3])) {
                        n.label = u[1];
                        break;
                    }
                    if (u[0] === 6 && n.label < o[1]) {
                        n.label = o[1], o = u;
                        break;
                    }
                    if (o && n.label < o[2]) {
                        n.label = o[2], n.ops.push(u);
                        break;
                    }
                    o[2] && n.ops.pop(), n.trys.pop();
                    continue;
            }
            u = t.call(e, n);
        } catch (l) {
            u = [
                6,
                l
            ], i = 0;
        } finally{
            r = o = 0;
        }
        if (u[0] & 5) throw u[1];
        return {
            value: u[0] ? u[1] : void 0,
            done: !0
        };
    }
}
function ge(e) {
    var t = typeof Symbol == "function" && Symbol.iterator, n = t && e[t], r = 0;
    if (n) return n.call(e);
    if (e && typeof e.length == "number") return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            };
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function le(e, t) {
    var n = typeof Symbol == "function" && e[Symbol.iterator];
    if (!n) return e;
    var r = n.call(e), i, o = [], s;
    try {
        for(; (t === void 0 || t-- > 0) && !(i = r.next()).done;)o.push(i.value);
    } catch (a) {
        s = {
            error: a
        };
    } finally{
        try {
            i && !i.done && (n = r.return) && n.call(r);
        } finally{
            if (s) throw s.error;
        }
    }
    return o;
}
function be(e, t, n) {
    if (n || arguments.length === 2) for(var r = 0, i = t.length, o; r < i; r++)(o || !(r in t)) && (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
    return e.concat(o || Array.prototype.slice.call(t));
}
function he(e) {
    return this instanceof he ? (this.v = e, this) : new he(e);
}
function Dr(e, t, n) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var r = n.apply(e, t || []), i, o = [];
    return i = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), a("next"), a("throw"), a("return", s), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    //TURBOPACK unreachable
    ;
    function s(d) {
        return function(m) {
            return Promise.resolve(m).then(d, f);
        };
    }
    function a(d, m) {
        r[d] && (i[d] = function(p) {
            return new Promise(function(g, h) {
                o.push([
                    d,
                    p,
                    g,
                    h
                ]) > 1 || c(d, p);
            });
        }, m && (i[d] = m(i[d])));
    }
    function c(d, m) {
        try {
            u(r[d](m));
        } catch (p) {
            v(o[0][3], p);
        }
    }
    function u(d) {
        d.value instanceof he ? Promise.resolve(d.value.v).then(l, f) : v(o[0][2], d);
    }
    function l(d) {
        c("next", d);
    }
    function f(d) {
        c("throw", d);
    }
    function v(d, m) {
        d(m), o.shift(), o.length && c(o[0][0], o[0][1]);
    }
}
function $r(e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var t = e[Symbol.asyncIterator], n;
    return t ? t.call(e) : (e = typeof ge == "function" ? ge(e) : e[Symbol.iterator](), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
        return this;
    }, n);
    //TURBOPACK unreachable
    ;
    function r(o) {
        n[o] = e[o] && function(s) {
            return new Promise(function(a, c) {
                s = e[o](s), i(a, c, s.done, s.value);
            });
        };
    }
    function i(o, s, a, c) {
        Promise.resolve(c).then(function(u) {
            o({
                value: u,
                done: a
            });
        }, s);
    }
}
function P(e) {
    return typeof e == "function";
}
function mt(e) {
    var t = function(r) {
        Error.call(r), r.stack = new Error().stack;
    }, n = e(t);
    return n.prototype = Object.create(Error.prototype), n.prototype.constructor = n, n;
}
var et = mt(function(e) {
    return function(n) {
        e(this), this.message = n ? n.length + ` errors occurred during unsubscription:
` + n.map(function(r, i) {
            return i + 1 + ") " + r.toString();
        }).join(`
  `) : "", this.name = "UnsubscriptionError", this.errors = n;
    };
});
function Ue(e, t) {
    if (e) {
        var n = e.indexOf(t);
        0 <= n && e.splice(n, 1);
    }
}
var Ae = function() {
    function e(t) {
        this.initialTeardown = t, this.closed = !1, this._parentage = null, this._finalizers = null;
    }
    return e.prototype.unsubscribe = function() {
        var t, n, r, i, o;
        if (!this.closed) {
            this.closed = !0;
            var s = this._parentage;
            if (s) if (this._parentage = null, Array.isArray(s)) try {
                for(var a = ge(s), c = a.next(); !c.done; c = a.next()){
                    var u = c.value;
                    u.remove(this);
                }
            } catch (p) {
                t = {
                    error: p
                };
            } finally{
                try {
                    c && !c.done && (n = a.return) && n.call(a);
                } finally{
                    if (t) throw t.error;
                }
            }
            else s.remove(this);
            var l = this.initialTeardown;
            if (P(l)) try {
                l();
            } catch (p) {
                o = p instanceof et ? p.errors : [
                    p
                ];
            }
            var f = this._finalizers;
            if (f) {
                this._finalizers = null;
                try {
                    for(var v = ge(f), d = v.next(); !d.done; d = v.next()){
                        var m = d.value;
                        try {
                            _t(m);
                        } catch (p) {
                            o = o ?? [], p instanceof et ? o = be(be([], le(o)), le(p.errors)) : o.push(p);
                        }
                    }
                } catch (p) {
                    r = {
                        error: p
                    };
                } finally{
                    try {
                        d && !d.done && (i = v.return) && i.call(v);
                    } finally{
                        if (r) throw r.error;
                    }
                }
            }
            if (o) throw new et(o);
        }
    }, e.prototype.add = function(t) {
        var n;
        if (t && t !== this) if (this.closed) _t(t);
        else {
            if (t instanceof e) {
                if (t.closed || t._hasParent(this)) return;
                t._addParent(this);
            }
            (this._finalizers = (n = this._finalizers) !== null && n !== void 0 ? n : []).push(t);
        }
    }, e.prototype._hasParent = function(t) {
        var n = this._parentage;
        return n === t || Array.isArray(n) && n.includes(t);
    }, e.prototype._addParent = function(t) {
        var n = this._parentage;
        this._parentage = Array.isArray(n) ? (n.push(t), n) : n ? [
            n,
            t
        ] : t;
    }, e.prototype._removeParent = function(t) {
        var n = this._parentage;
        n === t ? this._parentage = null : Array.isArray(n) && Ue(n, t);
    }, e.prototype.remove = function(t) {
        var n = this._finalizers;
        n && Ue(n, t), t instanceof e && t._removeParent(this);
    }, e.EMPTY = function() {
        var t = new e();
        return t.closed = !0, t;
    }(), e;
}(), an = Ae.EMPTY;
function cn(e) {
    return e instanceof Ae || e && "closed" in e && P(e.remove) && P(e.add) && P(e.unsubscribe);
}
function _t(e) {
    P(e) ? e() : e.unsubscribe();
}
var Nr = {
    Promise: void 0
}, Fr = {
    setTimeout: function(e, t) {
        for(var n = [], r = 2; r < arguments.length; r++)n[r - 2] = arguments[r];
        return setTimeout.apply(void 0, be([
            e,
            t
        ], le(n)));
    },
    clearTimeout: function(e) {
        return clearTimeout(e);
    },
    delegate: void 0
};
function un(e) {
    Fr.setTimeout(function() {
        throw e;
    });
}
function je() {}
function Re(e) {
    e();
}
var gt = function(e) {
    te(t, e);
    function t(n) {
        var r = e.call(this) || this;
        return r.isStopped = !1, n ? (r.destination = n, cn(n) && n.add(r)) : r.destination = Wr, r;
    }
    return t.create = function(n, r, i) {
        return new Ce(n, r, i);
    }, t.prototype.next = function(n) {
        this.isStopped || this._next(n);
    }, t.prototype.error = function(n) {
        this.isStopped || (this.isStopped = !0, this._error(n));
    }, t.prototype.complete = function() {
        this.isStopped || (this.isStopped = !0, this._complete());
    }, t.prototype.unsubscribe = function() {
        this.closed || (this.isStopped = !0, e.prototype.unsubscribe.call(this), this.destination = null);
    }, t.prototype._next = function(n) {
        this.destination.next(n);
    }, t.prototype._error = function(n) {
        try {
            this.destination.error(n);
        } finally{
            this.unsubscribe();
        }
    }, t.prototype._complete = function() {
        try {
            this.destination.complete();
        } finally{
            this.unsubscribe();
        }
    }, t;
}(Ae), Ur = function() {
    function e(t) {
        this.partialObserver = t;
    }
    return e.prototype.next = function(t) {
        var n = this.partialObserver;
        if (n.next) try {
            n.next(t);
        } catch (r) {
            Le(r);
        }
    }, e.prototype.error = function(t) {
        var n = this.partialObserver;
        if (n.error) try {
            n.error(t);
        } catch (r) {
            Le(r);
        }
        else Le(t);
    }, e.prototype.complete = function() {
        var t = this.partialObserver;
        if (t.complete) try {
            t.complete();
        } catch (n) {
            Le(n);
        }
    }, e;
}(), Ce = function(e) {
    te(t, e);
    function t(n, r, i) {
        var o = e.call(this) || this, s;
        return P(n) || !n ? s = {
            next: n ?? void 0,
            error: r ?? void 0,
            complete: i ?? void 0
        } : s = n, o.destination = new Ur(s), o;
    }
    return t;
}(gt);
function Le(e) {
    un(e);
}
function jr(e) {
    throw e;
}
var Wr = {
    closed: !0,
    next: je,
    error: jr,
    complete: je
}, bt = function() {
    return typeof Symbol == "function" && Symbol.observable || "@@observable";
}();
function Ge(e) {
    return e;
}
function Br(e) {
    return e.length === 0 ? Ge : e.length === 1 ? e[0] : function(n) {
        return e.reduce(function(r, i) {
            return i(r);
        }, n);
    };
}
var k = function() {
    function e(t) {
        t && (this._subscribe = t);
    }
    return e.prototype.lift = function(t) {
        var n = new e();
        return n.source = this, n.operator = t, n;
    }, e.prototype.subscribe = function(t, n, r) {
        var i = this, o = Hr(t) ? t : new Ce(t, n, r);
        return Re(function() {
            var s = i, a = s.operator, c = s.source;
            o.add(a ? a.call(o, c) : c ? i._subscribe(o) : i._trySubscribe(o));
        }), o;
    }, e.prototype._trySubscribe = function(t) {
        try {
            return this._subscribe(t);
        } catch (n) {
            t.error(n);
        }
    }, e.prototype.forEach = function(t, n) {
        var r = this;
        return n = Lt(n), new n(function(i, o) {
            var s = new Ce({
                next: function(a) {
                    try {
                        t(a);
                    } catch (c) {
                        o(c), s.unsubscribe();
                    }
                },
                error: o,
                complete: i
            });
            r.subscribe(s);
        });
    }, e.prototype._subscribe = function(t) {
        var n;
        return (n = this.source) === null || n === void 0 ? void 0 : n.subscribe(t);
    }, e.prototype[bt] = function() {
        return this;
    }, e.prototype.pipe = function() {
        for(var t = [], n = 0; n < arguments.length; n++)t[n] = arguments[n];
        return Br(t)(this);
    }, e.prototype.toPromise = function(t) {
        var n = this;
        return t = Lt(t), new t(function(r, i) {
            var o;
            n.subscribe(function(s) {
                return o = s;
            }, function(s) {
                return i(s);
            }, function() {
                return r(o);
            });
        });
    }, e.create = function(t) {
        return new e(t);
    }, e;
}();
function Lt(e) {
    var t;
    return (t = e ?? Nr.Promise) !== null && t !== void 0 ? t : Promise;
}
function Vr(e) {
    return e && P(e.next) && P(e.error) && P(e.complete);
}
function Hr(e) {
    return e && e instanceof gt || Vr(e) && cn(e);
}
function zr(e) {
    return P(e == null ? void 0 : e.lift);
}
function j(e) {
    return function(t) {
        if (zr(t)) return t.lift(function(n) {
            try {
                return e(n, this);
            } catch (r) {
                this.error(r);
            }
        });
        throw new TypeError("Unable to lift unknown Observable type");
    };
}
function F(e, t, n, r, i) {
    return new Yr(e, t, n, r, i);
}
var Yr = function(e) {
    te(t, e);
    function t(n, r, i, o, s, a) {
        var c = e.call(this, n) || this;
        return c.onFinalize = s, c.shouldUnsubscribe = a, c._next = r ? function(u) {
            try {
                r(u);
            } catch (l) {
                n.error(l);
            }
        } : e.prototype._next, c._error = o ? function(u) {
            try {
                o(u);
            } catch (l) {
                n.error(l);
            } finally{
                this.unsubscribe();
            }
        } : e.prototype._error, c._complete = i ? function() {
            try {
                i();
            } catch (u) {
                n.error(u);
            } finally{
                this.unsubscribe();
            }
        } : e.prototype._complete, c;
    }
    return t.prototype.unsubscribe = function() {
        var n;
        if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
            var r = this.closed;
            e.prototype.unsubscribe.call(this), !r && ((n = this.onFinalize) === null || n === void 0 || n.call(this));
        }
    }, t;
}(gt), qr = mt(function(e) {
    return function() {
        e(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed";
    };
}), ee = function(e) {
    te(t, e);
    function t() {
        var n = e.call(this) || this;
        return n.closed = !1, n.currentObservers = null, n.observers = [], n.isStopped = !1, n.hasError = !1, n.thrownError = null, n;
    }
    return t.prototype.lift = function(n) {
        var r = new It(this, this);
        return r.operator = n, r;
    }, t.prototype._throwIfClosed = function() {
        if (this.closed) throw new qr();
    }, t.prototype.next = function(n) {
        var r = this;
        Re(function() {
            var i, o;
            if (r._throwIfClosed(), !r.isStopped) {
                r.currentObservers || (r.currentObservers = Array.from(r.observers));
                try {
                    for(var s = ge(r.currentObservers), a = s.next(); !a.done; a = s.next()){
                        var c = a.value;
                        c.next(n);
                    }
                } catch (u) {
                    i = {
                        error: u
                    };
                } finally{
                    try {
                        a && !a.done && (o = s.return) && o.call(s);
                    } finally{
                        if (i) throw i.error;
                    }
                }
            }
        });
    }, t.prototype.error = function(n) {
        var r = this;
        Re(function() {
            if (r._throwIfClosed(), !r.isStopped) {
                r.hasError = r.isStopped = !0, r.thrownError = n;
                for(var i = r.observers; i.length;)i.shift().error(n);
            }
        });
    }, t.prototype.complete = function() {
        var n = this;
        Re(function() {
            if (n._throwIfClosed(), !n.isStopped) {
                n.isStopped = !0;
                for(var r = n.observers; r.length;)r.shift().complete();
            }
        });
    }, t.prototype.unsubscribe = function() {
        this.isStopped = this.closed = !0, this.observers = this.currentObservers = null;
    }, Object.defineProperty(t.prototype, "observed", {
        get: function() {
            var n;
            return ((n = this.observers) === null || n === void 0 ? void 0 : n.length) > 0;
        },
        enumerable: !1,
        configurable: !0
    }), t.prototype._trySubscribe = function(n) {
        return this._throwIfClosed(), e.prototype._trySubscribe.call(this, n);
    }, t.prototype._subscribe = function(n) {
        return this._throwIfClosed(), this._checkFinalizedStatuses(n), this._innerSubscribe(n);
    }, t.prototype._innerSubscribe = function(n) {
        var r = this, i = this, o = i.hasError, s = i.isStopped, a = i.observers;
        return o || s ? an : (this.currentObservers = null, a.push(n), new Ae(function() {
            r.currentObservers = null, Ue(a, n);
        }));
    }, t.prototype._checkFinalizedStatuses = function(n) {
        var r = this, i = r.hasError, o = r.thrownError, s = r.isStopped;
        i ? n.error(o) : s && n.complete();
    }, t.prototype.asObservable = function() {
        var n = new k();
        return n.source = this, n;
    }, t.create = function(n, r) {
        return new It(n, r);
    }, t;
}(k), It = function(e) {
    te(t, e);
    function t(n, r) {
        var i = e.call(this) || this;
        return i.destination = n, i.source = r, i;
    }
    return t.prototype.next = function(n) {
        var r, i;
        (i = (r = this.destination) === null || r === void 0 ? void 0 : r.next) === null || i === void 0 || i.call(r, n);
    }, t.prototype.error = function(n) {
        var r, i;
        (i = (r = this.destination) === null || r === void 0 ? void 0 : r.error) === null || i === void 0 || i.call(r, n);
    }, t.prototype.complete = function() {
        var n, r;
        (r = (n = this.destination) === null || n === void 0 ? void 0 : n.complete) === null || r === void 0 || r.call(n);
    }, t.prototype._subscribe = function(n) {
        var r, i;
        return (i = (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(n)) !== null && i !== void 0 ? i : an;
    }, t;
}(ee), ln = function(e) {
    te(t, e);
    function t(n) {
        var r = e.call(this) || this;
        return r._value = n, r;
    }
    return Object.defineProperty(t.prototype, "value", {
        get: function() {
            return this.getValue();
        },
        enumerable: !1,
        configurable: !0
    }), t.prototype._subscribe = function(n) {
        var r = e.prototype._subscribe.call(this, n);
        return !r.closed && n.next(this._value), r;
    }, t.prototype.getValue = function() {
        var n = this, r = n.hasError, i = n.thrownError, o = n._value;
        if (r) throw i;
        return this._throwIfClosed(), o;
    }, t.prototype.next = function(n) {
        e.prototype.next.call(this, this._value = n);
    }, t;
}(ee), Kr = {
    now: function() {
        return Date.now();
    }
}, Gr = function(e) {
    te(t, e);
    function t(n, r) {
        return e.call(this) || this;
    }
    return t.prototype.schedule = function(n, r) {
        return this;
    }, t;
}(Ae), Mt = {
    setInterval: function(e, t) {
        for(var n = [], r = 2; r < arguments.length; r++)n[r - 2] = arguments[r];
        return setInterval.apply(void 0, be([
            e,
            t
        ], le(n)));
    },
    clearInterval: function(e) {
        return clearInterval(e);
    },
    delegate: void 0
}, Qr = function(e) {
    te(t, e);
    function t(n, r) {
        var i = e.call(this, n, r) || this;
        return i.scheduler = n, i.work = r, i.pending = !1, i;
    }
    return t.prototype.schedule = function(n, r) {
        var i;
        if (r === void 0 && (r = 0), this.closed) return this;
        this.state = n;
        var o = this.id, s = this.scheduler;
        return o != null && (this.id = this.recycleAsyncId(s, o, r)), this.pending = !0, this.delay = r, this.id = (i = this.id) !== null && i !== void 0 ? i : this.requestAsyncId(s, this.id, r), this;
    }, t.prototype.requestAsyncId = function(n, r, i) {
        return i === void 0 && (i = 0), Mt.setInterval(n.flush.bind(n, this), i);
    }, t.prototype.recycleAsyncId = function(n, r, i) {
        if (i === void 0 && (i = 0), i != null && this.delay === i && this.pending === !1) return r;
        r != null && Mt.clearInterval(r);
    }, t.prototype.execute = function(n, r) {
        if (this.closed) return new Error("executing a cancelled action");
        this.pending = !1;
        var i = this._execute(n, r);
        if (i) return i;
        this.pending === !1 && this.id != null && (this.id = this.recycleAsyncId(this.scheduler, this.id, null));
    }, t.prototype._execute = function(n, r) {
        var i = !1, o;
        try {
            this.work(n);
        } catch (s) {
            i = !0, o = s || new Error("Scheduled action threw falsy error");
        }
        if (i) return this.unsubscribe(), o;
    }, t.prototype.unsubscribe = function() {
        if (!this.closed) {
            var n = this, r = n.id, i = n.scheduler, o = i.actions;
            this.work = this.state = this.scheduler = null, this.pending = !1, Ue(o, this), r != null && (this.id = this.recycleAsyncId(i, r, null)), this.delay = null, e.prototype.unsubscribe.call(this);
        }
    }, t;
}(Gr), Rt = function() {
    function e(t, n) {
        n === void 0 && (n = e.now), this.schedulerActionCtor = t, this.now = n;
    }
    return e.prototype.schedule = function(t, n, r) {
        return n === void 0 && (n = 0), new this.schedulerActionCtor(this, t).schedule(r, n);
    }, e.now = Kr.now, e;
}(), Jr = function(e) {
    te(t, e);
    function t(n, r) {
        r === void 0 && (r = Rt.now);
        var i = e.call(this, n, r) || this;
        return i.actions = [], i._active = !1, i;
    }
    return t.prototype.flush = function(n) {
        var r = this.actions;
        if (this._active) {
            r.push(n);
            return;
        }
        var i;
        this._active = !0;
        do if (i = n.execute(n.state, n.delay)) break;
        while (n = r.shift())
        if (this._active = !1, i) {
            for(; n = r.shift();)n.unsubscribe();
            throw i;
        }
    }, t;
}(Rt), Xr = new Jr(Qr);
function Zr(e) {
    return e && P(e.schedule);
}
function ei(e) {
    return e[e.length - 1];
}
function yt(e) {
    return Zr(ei(e)) ? e.pop() : void 0;
}
var wt = function(e) {
    return e && typeof e.length == "number" && typeof e != "function";
};
function fn(e) {
    return P(e == null ? void 0 : e.then);
}
function dn(e) {
    return P(e[bt]);
}
function pn(e) {
    return Symbol.asyncIterator && P(e == null ? void 0 : e[Symbol.asyncIterator]);
}
function hn(e) {
    return new TypeError("You provided " + (e !== null && typeof e == "object" ? "an invalid object" : "'" + e + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
}
function ti() {
    return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator;
}
var vn = ti();
function mn(e) {
    return P(e == null ? void 0 : e[vn]);
}
function gn(e) {
    return Dr(this, arguments, function() {
        var n, r, i, o;
        return sn(this, function(s) {
            switch(s.label){
                case 0:
                    n = e.getReader(), s.label = 1;
                case 1:
                    s.trys.push([
                        1,
                        ,
                        9,
                        10
                    ]), s.label = 2;
                case 2:
                    return [
                        4,
                        he(n.read())
                    ];
                case 3:
                    return r = s.sent(), i = r.value, o = r.done, o ? [
                        4,
                        he(void 0)
                    ] : [
                        3,
                        5
                    ];
                case 4:
                    return [
                        2,
                        s.sent()
                    ];
                case 5:
                    return [
                        4,
                        he(i)
                    ];
                case 6:
                    return [
                        4,
                        s.sent()
                    ];
                case 7:
                    return s.sent(), [
                        3,
                        2
                    ];
                case 8:
                    return [
                        3,
                        10
                    ];
                case 9:
                    return n.releaseLock(), [
                        7
                    ];
                case 10:
                    return [
                        2
                    ];
            }
        });
    });
}
function bn(e) {
    return P(e == null ? void 0 : e.getReader);
}
function H(e) {
    if (e instanceof k) return e;
    if (e != null) {
        if (dn(e)) return ni(e);
        if (wt(e)) return ri(e);
        if (fn(e)) return ii(e);
        if (pn(e)) return yn(e);
        if (mn(e)) return oi(e);
        if (bn(e)) return si(e);
    }
    throw hn(e);
}
function ni(e) {
    return new k(function(t) {
        var n = e[bt]();
        if (P(n.subscribe)) return n.subscribe(t);
        throw new TypeError("Provided object does not correctly implement Symbol.observable");
    });
}
function ri(e) {
    return new k(function(t) {
        for(var n = 0; n < e.length && !t.closed; n++)t.next(e[n]);
        t.complete();
    });
}
function ii(e) {
    return new k(function(t) {
        e.then(function(n) {
            t.closed || (t.next(n), t.complete());
        }, function(n) {
            return t.error(n);
        }).then(null, un);
    });
}
function oi(e) {
    return new k(function(t) {
        var n, r;
        try {
            for(var i = ge(e), o = i.next(); !o.done; o = i.next()){
                var s = o.value;
                if (t.next(s), t.closed) return;
            }
        } catch (a) {
            n = {
                error: a
            };
        } finally{
            try {
                o && !o.done && (r = i.return) && r.call(i);
            } finally{
                if (n) throw n.error;
            }
        }
        t.complete();
    });
}
function yn(e) {
    return new k(function(t) {
        ai(e, t).catch(function(n) {
            return t.error(n);
        });
    });
}
function si(e) {
    return yn(gn(e));
}
function ai(e, t) {
    var n, r, i, o;
    return Rr(this, void 0, void 0, function() {
        var s, a;
        return sn(this, function(c) {
            switch(c.label){
                case 0:
                    c.trys.push([
                        0,
                        5,
                        6,
                        11
                    ]), n = $r(e), c.label = 1;
                case 1:
                    return [
                        4,
                        n.next()
                    ];
                case 2:
                    if (r = c.sent(), !!r.done) return [
                        3,
                        4
                    ];
                    if (s = r.value, t.next(s), t.closed) return [
                        2
                    ];
                    c.label = 3;
                case 3:
                    return [
                        3,
                        1
                    ];
                case 4:
                    return [
                        3,
                        11
                    ];
                case 5:
                    return a = c.sent(), i = {
                        error: a
                    }, [
                        3,
                        11
                    ];
                case 6:
                    return c.trys.push([
                        6,
                        ,
                        9,
                        10
                    ]), r && !r.done && (o = n.return) ? [
                        4,
                        o.call(n)
                    ] : [
                        3,
                        8
                    ];
                case 7:
                    c.sent(), c.label = 8;
                case 8:
                    return [
                        3,
                        10
                    ];
                case 9:
                    if (i) throw i.error;
                    return [
                        7
                    ];
                case 10:
                    return [
                        7
                    ];
                case 11:
                    return t.complete(), [
                        2
                    ];
            }
        });
    });
}
function ie(e, t, n, r, i) {
    r === void 0 && (r = 0), i === void 0 && (i = !1);
    var o = t.schedule(function() {
        n(), i ? e.add(this.schedule(null, r)) : this.unsubscribe();
    }, r);
    if (e.add(o), !i) return o;
}
function wn(e, t) {
    return t === void 0 && (t = 0), j(function(n, r) {
        n.subscribe(F(r, function(i) {
            return ie(r, e, function() {
                return r.next(i);
            }, t);
        }, function() {
            return ie(r, e, function() {
                return r.complete();
            }, t);
        }, function(i) {
            return ie(r, e, function() {
                return r.error(i);
            }, t);
        }));
    });
}
function xn(e, t) {
    return t === void 0 && (t = 0), j(function(n, r) {
        r.add(e.schedule(function() {
            return n.subscribe(r);
        }, t));
    });
}
function ci(e, t) {
    return H(e).pipe(xn(t), wn(t));
}
function ui(e, t) {
    return H(e).pipe(xn(t), wn(t));
}
function li(e, t) {
    return new k(function(n) {
        var r = 0;
        return t.schedule(function() {
            r === e.length ? n.complete() : (n.next(e[r++]), n.closed || this.schedule());
        });
    });
}
function fi(e, t) {
    return new k(function(n) {
        var r;
        return ie(n, t, function() {
            r = e[vn](), ie(n, t, function() {
                var i, o, s;
                try {
                    i = r.next(), o = i.value, s = i.done;
                } catch (a) {
                    n.error(a);
                    return;
                }
                s ? n.complete() : n.next(o);
            }, 0, !0);
        }), function() {
            return P(r == null ? void 0 : r.return) && r.return();
        };
    });
}
function Sn(e, t) {
    if (!e) throw new Error("Iterable cannot be null");
    return new k(function(n) {
        ie(n, t, function() {
            var r = e[Symbol.asyncIterator]();
            ie(n, t, function() {
                r.next().then(function(i) {
                    i.done ? n.complete() : n.next(i.value);
                });
            }, 0, !0);
        });
    });
}
function di(e, t) {
    return Sn(gn(e), t);
}
function pi(e, t) {
    if (e != null) {
        if (dn(e)) return ci(e, t);
        if (wt(e)) return li(e, t);
        if (fn(e)) return ui(e, t);
        if (pn(e)) return Sn(e, t);
        if (mn(e)) return fi(e, t);
        if (bn(e)) return di(e, t);
    }
    throw hn(e);
}
function Qe(e, t) {
    return t ? pi(e, t) : H(e);
}
function Dt() {
    for(var e = [], t = 0; t < arguments.length; t++)e[t] = arguments[t];
    var n = yt(e);
    return Qe(e, n);
}
function hi(e) {
    return e instanceof Date && !isNaN(e);
}
var vi = mt(function(e) {
    return function(n) {
        n === void 0 && (n = null), e(this), this.message = "Timeout has occurred", this.name = "TimeoutError", this.info = n;
    };
});
function mi(e, t) {
    var n = hi(e) ? {
        first: e
    } : typeof e == "number" ? {
        each: e
    } : e, r = n.first, i = n.each, o = n.with, s = o === void 0 ? gi : o, a = n.scheduler, c = a === void 0 ? Xr : a, u = n.meta, l = u === void 0 ? null : u;
    if (r == null && i == null) throw new TypeError("No timeout provided.");
    return j(function(f, v) {
        var d, m, p = null, g = 0, h = function(x) {
            m = ie(v, c, function() {
                try {
                    d.unsubscribe(), H(s({
                        meta: l,
                        lastValue: p,
                        seen: g
                    })).subscribe(v);
                } catch (E) {
                    v.error(E);
                }
            }, x);
        };
        d = f.subscribe(F(v, function(x) {
            m == null || m.unsubscribe(), g++, v.next(p = x), i > 0 && h(i);
        }, void 0, void 0, function() {
            m != null && m.closed || m == null || m.unsubscribe(), p = null;
        })), !g && h(r != null ? typeof r == "number" ? r : +r - c.now() : i);
    });
}
function gi(e) {
    throw new vi(e);
}
function A(e, t) {
    return j(function(n, r) {
        var i = 0;
        n.subscribe(F(r, function(o) {
            r.next(e.call(t, o, i++));
        }));
    });
}
var bi = Array.isArray;
function yi(e, t) {
    return bi(t) ? e.apply(void 0, be([], le(t))) : e(t);
}
function wi(e) {
    return A(function(t) {
        return yi(e, t);
    });
}
function xi(e, t, n, r, i, o, s, a) {
    var c = [], u = 0, l = 0, f = !1, v = function() {
        f && !c.length && !u && t.complete();
    }, d = function(p) {
        return u < r ? m(p) : c.push(p);
    }, m = function(p) {
        u++;
        var g = !1;
        H(n(p, l++)).subscribe(F(t, function(h) {
            t.next(h);
        }, function() {
            g = !0;
        }, void 0, function() {
            if (g) try {
                u--;
                for(var h = function() {
                    var x = c.shift();
                    s || m(x);
                }; c.length && u < r;)h();
                v();
            } catch (x) {
                t.error(x);
            }
        }));
    };
    return e.subscribe(F(t, d, function() {
        f = !0, v();
    })), function() {};
}
function xt(e, t, n) {
    return n === void 0 && (n = 1 / 0), P(t) ? xt(function(r, i) {
        return A(function(o, s) {
            return t(r, o, i, s);
        })(H(e(r, i)));
    }, n) : (typeof t == "number" && (n = t), j(function(r, i) {
        return xi(r, i, e, n);
    }));
}
function Si(e) {
    return xt(Ge, e);
}
function Ti() {
    return Si(1);
}
function We() {
    for(var e = [], t = 0; t < arguments.length; t++)e[t] = arguments[t];
    return Ti()(Qe(e, yt(e)));
}
var Ei = [
    "addListener",
    "removeListener"
], Ci = [
    "addEventListener",
    "removeEventListener"
], Pi = [
    "on",
    "off"
];
function ct(e, t, n, r) {
    if (P(n) && (r = n, n = void 0), r) return ct(e, t, n).pipe(wi(r));
    var i = le(ki(e) ? Ci.map(function(a) {
        return function(c) {
            return e[a](t, c, n);
        };
    }) : Oi(e) ? Ei.map($t(e, t)) : Ai(e) ? Pi.map($t(e, t)) : [], 2), o = i[0], s = i[1];
    if (!o && wt(e)) return xt(function(a) {
        return ct(a, t, n);
    })(H(e));
    if (!o) throw new TypeError("Invalid event target");
    return new k(function(a) {
        var c = function() {
            for(var u = [], l = 0; l < arguments.length; l++)u[l] = arguments[l];
            return a.next(1 < u.length ? u : u[0]);
        };
        return o(c), function() {
            return s(c);
        };
    });
}
function $t(e, t) {
    return function(n) {
        return function(r) {
            return e[n](t, r);
        };
    };
}
function Oi(e) {
    return P(e.addListener) && P(e.removeListener);
}
function Ai(e) {
    return P(e.on) && P(e.off);
}
function ki(e) {
    return P(e.addEventListener) && P(e.removeEventListener);
}
function Je(e, t) {
    return j(function(n, r) {
        var i = 0;
        n.subscribe(F(r, function(o) {
            return e.call(t, o, i++) && r.next(o);
        }));
    });
}
function _i(e, t, n, r, i) {
    return function(o, s) {
        var a = n, c = t, u = 0;
        o.subscribe(F(s, function(l) {
            var f = u++;
            c = a ? e(c, l, f) : (a = !0, l), s.next(c);
        }, i));
    };
}
function Li(e, t) {
    return t === void 0 && (t = Ge), e = e ?? Ii, j(function(n, r) {
        var i, o = !0;
        n.subscribe(F(r, function(s) {
            var a = t(s);
            (o || !e(i, a)) && (o = !1, i = a, r.next(s));
        }));
    });
}
function Ii(e, t) {
    return e === t;
}
function ut(e, t) {
    return j(_i(e, t, arguments.length >= 2, !0));
}
function Mi(e) {
    e === void 0 && (e = {});
    var t = e.connector, n = t === void 0 ? function() {
        return new ee();
    } : t, r = e.resetOnError, i = r === void 0 ? !0 : r, o = e.resetOnComplete, s = o === void 0 ? !0 : o, a = e.resetOnRefCountZero, c = a === void 0 ? !0 : a;
    return function(u) {
        var l, f, v, d = 0, m = !1, p = !1, g = function() {
            f == null || f.unsubscribe(), f = void 0;
        }, h = function() {
            g(), l = v = void 0, m = p = !1;
        }, x = function() {
            var E = l;
            h(), E == null || E.unsubscribe();
        };
        return j(function(E, O) {
            d++, !p && !m && g();
            var b = v = v ?? n();
            O.add(function() {
                d--, d === 0 && !p && !m && (f = tt(x, c));
            }), b.subscribe(O), !l && d > 0 && (l = new Ce({
                next: function(S) {
                    return b.next(S);
                },
                error: function(S) {
                    p = !0, g(), f = tt(h, i, S), b.error(S);
                },
                complete: function() {
                    m = !0, g(), f = tt(h, s), b.complete();
                }
            }), H(E).subscribe(l));
        })(u);
    };
}
function tt(e, t) {
    for(var n = [], r = 2; r < arguments.length; r++)n[r - 2] = arguments[r];
    if (t === !0) {
        e();
        return;
    }
    if (t !== !1) {
        var i = new Ce({
            next: function() {
                i.unsubscribe(), e();
            }
        });
        return H(t.apply(void 0, be([], le(n)))).subscribe(i);
    }
}
function Ri(e) {
    return j(function(t, n) {
        var r = !1, i = F(n, function() {
            i == null || i.unsubscribe(), r = !0;
        }, je);
        H(e).subscribe(i), t.subscribe(F(n, function(o) {
            return r && n.next(o);
        }));
    });
}
function D() {
    for(var e = [], t = 0; t < arguments.length; t++)e[t] = arguments[t];
    var n = yt(e);
    return j(function(r, i) {
        (n ? We(e, r, n) : We(e, r)).subscribe(i);
    });
}
function Tn(e, t) {
    return j(function(n, r) {
        var i = null, o = 0, s = !1, a = function() {
            return s && !i && r.complete();
        };
        n.subscribe(F(r, function(c) {
            i == null || i.unsubscribe();
            var u = 0, l = o++;
            H(e(c, l)).subscribe(i = F(r, function(f) {
                return r.next(t ? t(c, f, l, u++) : f);
            }, function() {
                i = null, a();
            }));
        }, function() {
            s = !0, a();
        }));
    });
}
function Nt(e) {
    return j(function(t, n) {
        H(e).subscribe(F(n, function() {
            return n.complete();
        }, je)), !n.closed && t.subscribe(n);
    });
}
function Di(e, t, n) {
    var r = P(e) || t || n ? {
        next: e,
        error: t,
        complete: n
    } : e;
    return r ? j(function(i, o) {
        var s;
        (s = r.subscribe) === null || s === void 0 || s.call(r);
        var a = !0;
        i.subscribe(F(o, function(c) {
            var u;
            (u = r.next) === null || u === void 0 || u.call(r, c), o.next(c);
        }, function() {
            var c;
            a = !1, (c = r.complete) === null || c === void 0 || c.call(r), o.complete();
        }, function(c) {
            var u;
            a = !1, (u = r.error) === null || u === void 0 || u.call(r, c), o.error(c);
        }, function() {
            var c, u;
            a && ((c = r.unsubscribe) === null || c === void 0 || c.call(r)), (u = r.finalize) === null || u === void 0 || u.call(r);
        }));
    }) : Ge;
}
var $i = Object.defineProperty, Ni = Object.defineProperties, Fi = Object.getOwnPropertyDescriptors, Ft = Object.getOwnPropertySymbols, Ui = Object.prototype.hasOwnProperty, ji = Object.prototype.propertyIsEnumerable, Ut = (e, t, n)=>t in e ? $i(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n, Y = (e, t)=>{
    for(var n in t || (t = {}))Ui.call(t, n) && Ut(e, n, t[n]);
    if (Ft) for (var n of Ft(t))ji.call(t, n) && Ut(e, n, t[n]);
    return e;
}, se = (e, t)=>Ni(e, Fi(t)), V = (e, t, n)=>new Promise((r, i)=>{
        var o = (c)=>{
            try {
                a(n.next(c));
            } catch (u) {
                i(u);
            }
        }, s = (c)=>{
            try {
                a(n.throw(c));
            } catch (u) {
                i(u);
            }
        }, a = (c)=>c.done ? r(c.value) : Promise.resolve(c.value).then(o, s);
        a((n = n.apply(e, t)).next());
    }), En = "lk";
function B(e) {
    return typeof e > "u" ? !1 : Wi(e) || Bi(e);
}
function Wi(e) {
    var t;
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && e.hasOwnProperty("track") && typeof ((t = e.publication) == null ? void 0 : t.track) < "u" : !1;
}
function Bi(e) {
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && e.hasOwnProperty("publication") && typeof e.publication < "u" : !1;
}
function Pe(e) {
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && typeof e.publication > "u" : !1;
}
function N(e) {
    if (typeof e == "string" || typeof e == "number") return `${e}`;
    if (Pe(e)) return `${e.participant.identity}_${e.source}_placeholder`;
    if (B(e)) return `${e.participant.identity}_${e.publication.source}_${e.publication.trackSid}`;
    throw new Error(`Can't generate a id for the given track reference: ${e}`);
}
function jo(e, t) {
    return e === void 0 || t === void 0 ? !1 : B(e) && B(t) ? e.publication.trackSid === t.publication.trackSid : N(e) === N(t);
}
function Wo(e, t) {
    return typeof t > "u" ? !1 : B(e) ? t.some((n)=>n.participant.identity === e.participant.identity && B(n) && n.publication.trackSid === e.publication.trackSid) : Pe(e) ? t.some((n)=>n.participant.identity === e.participant.identity && Pe(n) && n.source === e.source) : !1;
}
function Vi(e, t) {
    return Pe(e) && B(t) && t.participant.identity === e.participant.identity && t.source === e.source;
}
function Bo() {
    const e = document.createElement("p");
    e.style.width = "100%", e.style.height = "200px";
    const t = document.createElement("div");
    t.style.position = "absolute", t.style.top = "0px", t.style.left = "0px", t.style.visibility = "hidden", t.style.width = "200px", t.style.height = "150px", t.style.overflow = "hidden", t.appendChild(e), document.body.appendChild(t);
    const n = e.offsetWidth;
    t.style.overflow = "scroll";
    let r = e.offsetWidth;
    return n === r && (r = t.clientWidth), document.body.removeChild(t), n - r;
}
function Vo() {
    return typeof document < "u";
}
function Hi(e) {
    e = Y({}, e);
    const t = "(?:(?:[a-z]+:)?//)?", n = "(?:\\S+(?::\\S*)?@)?", r = new RegExp("(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}", "g").source, u = `(?:${t}|www\\.)${n}(?:localhost|${r}|(?:(?:[a-z\\u00a1-\\uffff0-9][-_]*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#][^\\s"]*)?`;
    return e.exact ? new RegExp(`(?:^${u}$)`, "i") : new RegExp(u, "ig");
}
var jt = "[^\\.\\s@:](?:[^\\s@:]*[^\\s@:\\.])?@[^\\.\\s@]+(?:\\.[^\\.\\s@]+)*";
function zi({ exact: e } = {}) {
    return e ? new RegExp(`^${jt}$`) : new RegExp(jt, "g");
}
function Ho(e, t, n) {
    return Er(e, t, ()=>V(this, null, function*() {
            const { x: i, y: o } = yield Ar(e, t, {
                placement: "top",
                middleware: [
                    Cr(6),
                    Or(),
                    Pr({
                        padding: 5
                    })
                ]
            });
            n == null || n(i, o);
        }));
}
function zo(e, t) {
    return !e.contains(t.target);
}
var Yo = ()=>({
        email: zi(),
        url: Hi({})
    });
function qo(e, t) {
    const n = Object.entries(t).map(([o, s], a)=>Array.from(e.matchAll(s)).map(({ index: c, 0: u })=>({
                type: o,
                weight: a,
                content: u,
                index: c ?? 0
            }))).flat().sort((o, s)=>{
        const a = o.index - s.index;
        return a !== 0 ? a : o.weight - s.weight;
    }).filter(({ index: o }, s, a)=>{
        if (s === 0) return !0;
        const c = a[s - 1];
        return c.index + c.content.length <= o;
    }), r = [];
    let i = 0;
    for (const { type: o, content: s, index: a } of n)a > i && r.push(e.substring(i, a)), r.push({
        type: o,
        content: s
    }), i = a + s.length;
    return e.length > i && r.push(e.substring(i)), r;
}
var Yi = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].RoomMetadataChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ActiveSpeakersChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionQualityChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantConnected,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantPermissionsChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantMetadataChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantNameChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantAttributesChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackMuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackUnmuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackUnpublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackStreamStateChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackSubscriptionFailed,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackSubscriptionPermissionChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackSubscriptionStatusChanged
], Cn = [
    ...Yi,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].LocalTrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].LocalTrackUnpublished
], qi = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnpublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackMuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnmuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackStreamStateChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscribed,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnsubscribed,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionPermissionChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionFailed,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished
], Ki = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ConnectionQualityChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].IsSpeakingChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantMetadataChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantPermissionsChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackMuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnmuted,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnpublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackStreamStateChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionFailed,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionPermissionChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionStatusChanged
], Pn = [
    ...Ki,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished
], L = Mr.getLogger("lk-components-js");
L.setDefaultLevel("WARN");
function Ko(e, t = {}) {
    var n;
    L.setLevel(e), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setLogLevel"])((n = t.liveKitClientLogLevel) != null ? n : e);
}
function Go(e, t = {}) {
    var n;
    const r = L.methodFactory;
    L.methodFactory = (i, o, s)=>{
        const a = r(i, o, s), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LogLevel"][i], u = c >= o && c < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LogLevel"].silent;
        return (l, f)=>{
            f ? a(l, f) : a(l), u && e(c, l, f);
        };
    }, L.setLevel(L.getLevel()), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setLogExtension"])((n = t.liveKitClientLogExtension) != null ? n : e);
}
var Qo = [
    {
        columns: 1,
        rows: 1
    },
    {
        columns: 1,
        rows: 2,
        orientation: "portrait"
    },
    {
        columns: 2,
        rows: 1,
        orientation: "landscape"
    },
    {
        columns: 2,
        rows: 2,
        minWidth: 560
    },
    {
        columns: 3,
        rows: 3,
        minWidth: 700
    },
    {
        columns: 4,
        rows: 4,
        minWidth: 960
    },
    {
        columns: 5,
        rows: 5,
        minWidth: 1100
    }
];
function Gi(e, t, n, r) {
    if (e.length < 1) throw new Error("At least one grid layout definition must be provided.");
    const i = Qi(e);
    if (n <= 0 || r <= 0) return i[0];
    let o = 0;
    const s = n / r > 1 ? "landscape" : "portrait";
    let a = i.find((c, u, l)=>{
        o = u;
        const f = l.findIndex((v, d)=>{
            const m = !v.orientation || v.orientation === s, p = d > u, g = v.maxTiles === c.maxTiles;
            return p && g && m;
        }) !== -1;
        return c.maxTiles >= t && !f;
    });
    if (a === void 0) if (a = i[i.length - 1], a) L.warn(`No layout found for: participantCount: ${t}, width/height: ${n}/${r} fallback to biggest available layout (${a}).`);
    else throw new Error("No layout or fallback layout found.");
    if ((n < a.minWidth || r < a.minHeight) && o > 0) {
        const c = i[o - 1];
        a = Gi(i.slice(0, o), c.maxTiles, n, r);
    }
    return a;
}
function Qi(e) {
    return [
        ...e
    ].map((t)=>{
        var n, r;
        return {
            name: `${t.columns}x${t.rows}`,
            columns: t.columns,
            rows: t.rows,
            maxTiles: t.columns * t.rows,
            minWidth: (n = t.minWidth) != null ? n : 0,
            minHeight: (r = t.minHeight) != null ? r : 0,
            orientation: t.orientation
        };
    }).sort((t, n)=>t.maxTiles !== n.maxTiles ? t.maxTiles - n.maxTiles : t.minWidth !== 0 || n.minWidth !== 0 ? t.minWidth - n.minWidth : t.minHeight !== 0 || n.minHeight !== 0 ? t.minHeight - n.minHeight : 0);
}
function Jo() {
    return typeof navigator < "u" && navigator.mediaDevices && !!navigator.mediaDevices.getDisplayMedia;
}
function Xo(e, t) {
    var n;
    return se(Y({}, e), {
        receivedAtMediaTimestamp: (n = t.rtpTimestamp) != null ? n : 0,
        receivedAt: t.timestamp
    });
}
function Zo(e, t, n) {
    return [
        ...e,
        ...t
    ].reduceRight((r, i)=>(r.find((o)=>o.id === i.id) || r.unshift(i), r), []).slice(0 - n);
}
var Ji = /* @__PURE__ */ ((e)=>(e.AgentState = "lk.agent.state", e.PublishOnBehalf = "lk.publish_on_behalf", e.TranscriptionFinal = "lk.transcription_final", e.TranscriptionSegmentId = "lk.segment_id", e.TranscribedTrackId = "lk.transcribed_track_id", e))(Ji || {}), On = [], An = {
    showChat: !1,
    unreadMessages: 0,
    showSettings: !1
};
function Xi(e) {
    return typeof e == "object";
}
function es(e) {
    return Array.isArray(e) && e.filter(Xi).length > 0;
}
function kn(e, t) {
    return t.audioLevel - e.audioLevel;
}
function _n(e, t) {
    return e.isSpeaking === t.isSpeaking ? 0 : e.isSpeaking ? -1 : 1;
}
function Ln(e, t) {
    var n, r, i, o;
    return e.lastSpokeAt !== void 0 || t.lastSpokeAt !== void 0 ? ((r = (n = t.lastSpokeAt) == null ? void 0 : n.getTime()) != null ? r : 0) - ((o = (i = e.lastSpokeAt) == null ? void 0 : i.getTime()) != null ? o : 0) : 0;
}
function Be(e, t) {
    var n, r, i, o;
    return ((r = (n = e.joinedAt) == null ? void 0 : n.getTime()) != null ? r : 0) - ((o = (i = t.joinedAt) == null ? void 0 : i.getTime()) != null ? o : 0);
}
function Zi(e, t) {
    return B(e) ? B(t) ? 0 : -1 : B(t) ? 1 : 0;
}
function eo(e, t) {
    const n = e.participant.isCameraEnabled, r = t.participant.isCameraEnabled;
    return n !== r ? n ? -1 : 1 : 0;
}
function ts(e) {
    const t = [], n = [], r = [], i = [];
    e.forEach((a)=>{
        a.participant.isLocal && a.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera ? t.push(a) : a.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare ? n.push(a) : a.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera ? r.push(a) : i.push(a);
    });
    const o = to(n), s = no(r);
    return [
        ...t,
        ...o,
        ...s,
        ...i
    ];
}
function to(e) {
    const t = [], n = [];
    return e.forEach((i)=>{
        i.participant.isLocal ? t.push(i) : n.push(i);
    }), t.sort((i, o)=>Be(i.participant, o.participant)), n.sort((i, o)=>Be(i.participant, o.participant)), [
        ...n,
        ...t
    ];
}
function no(e) {
    const t = [], n = [];
    return e.forEach((r)=>{
        r.participant.isLocal ? t.push(r) : n.push(r);
    }), n.sort((r, i)=>r.participant.isSpeaking && i.participant.isSpeaking ? kn(r.participant, i.participant) : r.participant.isSpeaking !== i.participant.isSpeaking ? _n(r.participant, i.participant) : r.participant.lastSpokeAt !== i.participant.lastSpokeAt ? Ln(r.participant, i.participant) : B(r) !== B(i) ? Zi(r, i) : r.participant.isCameraEnabled !== i.participant.isCameraEnabled ? eo(r, i) : Be(r.participant, i.participant)), [
        ...t,
        ...n
    ];
}
function ns(e) {
    const t = [
        ...e
    ];
    t.sort((r, i)=>{
        if (r.isSpeaking && i.isSpeaking) return kn(r, i);
        if (r.isSpeaking !== i.isSpeaking) return _n(r, i);
        if (r.lastSpokeAt !== i.lastSpokeAt) return Ln(r, i);
        const o = r.videoTrackPublications.size > 0, s = i.videoTrackPublications.size > 0;
        return o !== s ? o ? -1 : 1 : Be(r, i);
    });
    const n = t.find((r)=>r.isLocal);
    if (n) {
        const r = t.indexOf(n);
        r >= 0 && (t.splice(r, 1), t.length > 0 ? t.splice(0, 0, n) : t.push(n));
    }
    return t;
}
function ro(e, t) {
    return e.reduce((n, r, i)=>i % t === 0 ? [
            ...n,
            [
                r
            ]
        ] : [
            ...n.slice(0, -1),
            [
                ...n.slice(-1)[0],
                r
            ]
        ], []);
}
function Wt(e, t) {
    const n = Math.max(e.length, t.length);
    return new Array(n).fill([]).map((r, i)=>[
            e[i],
            t[i]
        ]);
}
function Ve(e, t, n) {
    return e.filter((r)=>!t.map((i)=>n(i)).includes(n(r)));
}
function lt(e) {
    return e.map((t)=>typeof t == "string" || typeof t == "number" ? `${t}` : N(t));
}
function io(e, t) {
    return {
        dropped: Ve(e, t, N),
        added: Ve(t, e, N)
    };
}
function oo(e) {
    return e.added.length !== 0 || e.dropped.length !== 0;
}
function ft(e, t) {
    const n = t.findIndex((r)=>N(r) === N(e));
    if (n === -1) throw new Error(`Element not part of the array: ${N(e)} not in ${lt(t)}`);
    return n;
}
function so(e, t, n) {
    const r = ft(e, n), i = ft(t, n);
    return n.splice(r, 1, t), n.splice(i, 1, e), n;
}
function ao(e, t) {
    const n = ft(e, t);
    return t.splice(n, 1), t;
}
function co(e, t) {
    return [
        ...t,
        e
    ];
}
function nt(e, t) {
    return ro(e, t);
}
function rs(e, t, n) {
    let r = uo(e, t);
    if (r.length < t.length) {
        const s = Ve(t, r, N);
        r = [
            ...r,
            ...s
        ];
    }
    const i = nt(r, n), o = nt(t, n);
    if (Wt(i, o).forEach(([s, a], c)=>{
        if (s && a) {
            const u = nt(r, n)[c], l = io(u, a);
            oo(l) && (L.debug(`Detected visual changes on page: ${c}, current: ${lt(s)}, next: ${lt(a)}`, {
                changes: l
            }), l.added.length === l.dropped.length && Wt(l.added, l.dropped).forEach(([f, v])=>{
                if (f && v) r = so(f, v, r);
                else throw new Error(`For a swap action we need a addition and a removal one is missing: ${f}, ${v}`);
            }), l.added.length === 0 && l.dropped.length > 0 && l.dropped.forEach((f)=>{
                r = ao(f, r);
            }), l.added.length > 0 && l.dropped.length === 0 && l.added.forEach((f)=>{
                r = co(f, r);
            }));
        }
    }), r.length > t.length) {
        const s = Ve(r, t, N);
        r = r.filter((a)=>!s.map(N).includes(N(a)));
    }
    return r;
}
function uo(e, t) {
    return e.map((n)=>{
        const r = t.find((i)=>// If the IDs match or ..
            N(n) === N(i) || // ... if the current item is a placeholder and the new item is the track reference can replace it.
            typeof n != "number" && Pe(n) && B(i) && Vi(n, i));
        return r ?? n;
    });
}
function U(e) {
    return `${En}-${e}`;
}
function is(e) {
    const t = Bt(e), n = In(e.participant).pipe(A(()=>Bt(e)), D(t));
    return {
        className: U(e.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera || e.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare ? "participant-media-video" : "participant-media-audio"),
        trackObserver: n
    };
}
function Bt(e) {
    if (B(e)) return e.publication;
    {
        const { source: t, name: n, participant: r } = e;
        if (t && n) return r.getTrackPublications().find((i)=>i.source === t && i.trackName === n);
        if (n) return r.getTrackPublicationByName(n);
        if (t) return r.getTrackPublication(t);
        throw new Error("At least one of source and name needs to be defined");
    }
}
function fe(e, ...t) {
    return new k((r)=>{
        const i = ()=>{
            r.next(e);
        };
        return t.forEach((s)=>{
            e.on(s, i);
        }), ()=>{
            t.forEach((s)=>{
                e.off(s, i);
            });
        };
    }).pipe(D(e));
}
function we(e, t) {
    return new k((r)=>{
        const i = (...s)=>{
            r.next(s);
        };
        return e.on(t, i), ()=>{
            e.off(t, i);
        };
    });
}
function os(e) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged).pipe(A(([t])=>t), D(e.state));
}
function ss(e) {
    return fe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].RoomMetadataChanged, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged).pipe(A((n)=>({
            name: n.name,
            metadata: n.metadata
        })));
}
function as(e) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ActiveSpeakersChanged).pipe(A(([t])=>t));
}
function cs(e, t, n = !0) {
    const r = new k((o)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Room"].getLocalDevices(e, n).then((s)=>{
            o.next(s), o.complete();
        }).catch((s)=>{
            t == null || t(s), o.next([]), o.complete();
        });
    }), i = new k((o)=>{
        var s;
        const a = ()=>V(this, null, function*() {
                try {
                    const c = yield __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Room"].getLocalDevices(e, n);
                    o.next(c);
                } catch (c) {
                    t == null || t(c);
                }
            });
        if ("undefined" < "u") {
            if (!window.isSecureContext) throw new Error("Accessing media devices is available only in secure contexts (HTTPS and localhost), in some or all supporting browsers. See: https://developer.mozilla.org/en-US/docs/Web/API/Navigator/mediaDevices");
            (s = navigator == null ? void 0 : navigator.mediaDevices) == null || s.addEventListener("devicechange", a);
        }
        return ()=>{
            var c;
            (c = navigator == null ? void 0 : navigator.mediaDevices) == null || c.removeEventListener("devicechange", a);
        };
    });
    return We(r, i);
}
function lo(e) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].DataReceived);
}
function fo(e) {
    return fe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].AudioPlaybackStatusChanged).pipe(A((n)=>({
            canPlayAudio: n.canPlaybackAudio
        })));
}
function po(e) {
    return fe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].VideoPlaybackStatusChanged).pipe(A((n)=>({
            canPlayVideo: n.canPlaybackVideo
        })));
}
function ho(e, t) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ActiveDeviceChanged).pipe(Je(([n])=>n === t), A(([n, r])=>(L.debug("activeDeviceObservable | RoomEvent.ActiveDeviceChanged", {
            kind: n,
            deviceId: r
        }), r)));
}
function us(e, t) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantEncryptionStatusChanged).pipe(Je(([, n])=>(t == null ? void 0 : t.identity) === (n == null ? void 0 : n.identity) || !n && (t == null ? void 0 : t.identity) === e.localParticipant.identity), A(([n])=>n), D(t != null && t.isLocal ? t.isE2EEEnabled : !!(t != null && t.isEncrypted)));
}
function ls(e) {
    return we(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].RecordingStatusChanged).pipe(A(([t])=>t), D(e.isRecording));
}
function xe(e, ...t) {
    return new k((r)=>{
        const i = ()=>{
            r.next(e);
        };
        return t.forEach((s)=>{
            e.on(s, i);
        }), ()=>{
            t.forEach((s)=>{
                e.off(s, i);
            });
        };
    }).pipe(D(e));
}
function In(e) {
    return xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackMuted, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnmuted, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantPermissionsChanged, // ParticipantEvent.IsSpeakingChanged,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackPublished, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnpublished, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].MediaDevicesError, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscriptionStatusChanged).pipe(A((n)=>{
        const { isMicrophoneEnabled: r, isCameraEnabled: i, isScreenShareEnabled: o } = n, s = n.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone), a = n.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera);
        return {
            isCameraEnabled: i,
            isMicrophoneEnabled: r,
            isScreenShareEnabled: o,
            cameraTrack: a,
            microphoneTrack: s,
            participant: n
        };
    }));
}
function vo(e) {
    return e ? xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantMetadataChanged, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantNameChanged).pipe(A(({ name: n, identity: r, metadata: i })=>({
            name: n,
            identity: r,
            metadata: i
        })), D({
        name: e.name,
        identity: e.identity,
        metadata: e.metadata
    })) : void 0;
}
function mo(e) {
    return Xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ConnectionQualityChanged).pipe(A(([n])=>n), D(e.connectionQuality));
}
function Xe(e, t) {
    return new k((r)=>{
        const i = (...s)=>{
            r.next(s);
        };
        return e.on(t, i), ()=>{
            e.off(t, i);
        };
    });
}
function go(e) {
    var t, n, r, i;
    return xe(e.participant, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackMuted, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnmuted, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackSubscribed, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].TrackUnsubscribed, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished).pipe(A((o)=>{
        var s, a;
        const c = (s = e.publication) != null ? s : o.getTrackPublication(e.source);
        return (a = c == null ? void 0 : c.isMuted) != null ? a : !0;
    }), D((i = (r = (t = e.publication) == null ? void 0 : t.isMuted) != null ? r : (n = e.participant.getTrackPublication(e.source)) == null ? void 0 : n.isMuted) != null ? i : !0));
}
function fs(e) {
    return Xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].IsSpeakingChanged).pipe(A(([t])=>t));
}
function ds(e, t = {}) {
    var n;
    let r;
    const i = new k((c)=>(r = c, ()=>a.unsubscribe())).pipe(D(Array.from(e.remoteParticipants.values()))), o = (n = t.additionalRoomEvents) != null ? n : Cn, s = Array.from(/* @__PURE__ */ new Set([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantConnected,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged,
        ...o
    ])), a = fe(e, ...s).subscribe((c)=>r == null ? void 0 : r.next(Array.from(c.remoteParticipants.values())));
    return e.remoteParticipants.size > 0 && (r == null || r.next(Array.from(e.remoteParticipants.values()))), i;
}
function ps(e, t, n = {}) {
    var r;
    const i = (r = n.additionalEvents) != null ? r : Pn;
    return fe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantConnected, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged).pipe(Tn((s)=>{
        const a = s.getParticipantByIdentity(t);
        return a ? xe(a, ...i) : new k((c)=>c.next(void 0));
    }), D(e.getParticipantByIdentity(t)));
}
function hs(e) {
    return Xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].ParticipantPermissionsChanged).pipe(A(()=>e.permissions), D(e.permissions));
}
function vs(e, { kind: t, identity: n }, r = {}) {
    var i;
    const o = (i = r.additionalEvents) != null ? i : Pn, s = (c)=>{
        let u = !0;
        return t && (u = u && c.kind === t), n && (u = u && c.identity === n), u;
    };
    return fe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantConnected, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged).pipe(Tn((c)=>{
        const u = Array.from(c.remoteParticipants.values()).find((l)=>s(l));
        return u ? xe(u, ...o) : new k((l)=>l.next(void 0));
    }), D(Array.from(e.remoteParticipants.values()).find((c)=>s(c))));
}
function ms(e) {
    return typeof e > "u" ? new k() : Xe(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].AttributesChanged).pipe(A(([t])=>({
            changed: t,
            attributes: e.attributes
        })), D({
        changed: e.attributes,
        attributes: e.attributes
    }));
}
function gs(e, t, n, r, i) {
    const { localParticipant: o } = t, s = (f, v)=>{
        let d = !1;
        switch(f){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera:
                d = v.isCameraEnabled;
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone:
                d = v.isMicrophoneEnabled;
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare:
                d = v.isScreenShareEnabled;
                break;
        }
        return d;
    }, a = In(o).pipe(A((f)=>s(e, f.participant)), D(s(e, o))), c = new ee(), u = (f, v)=>V(this, null, function*() {
            try {
                switch(v ?? (v = n), c.next(!0), e){
                    case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera:
                        return yield o.setCameraEnabled(f ?? !o.isCameraEnabled, v, r), o.isCameraEnabled;
                    case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone:
                        return yield o.setMicrophoneEnabled(f ?? !o.isMicrophoneEnabled, v, r), o.isMicrophoneEnabled;
                    case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare:
                        return yield o.setScreenShareEnabled(f ?? !o.isScreenShareEnabled, v, r), o.isScreenShareEnabled;
                    default:
                        throw new TypeError("Tried to toggle unsupported source");
                }
            } catch (d) {
                if (i && d instanceof Error) {
                    i == null || i(d);
                    return;
                } else throw d;
            } finally{
                c.next(!1);
            }
        });
    return {
        className: U("button"),
        toggle: u,
        enabledObserver: a,
        pendingObserver: c.asObservable()
    };
}
function bs() {
    let e = !1;
    const t = new ee(), n = new ee(), r = (o)=>V(this, null, function*() {
            n.next(!0), e = o ?? !e, t.next(e), n.next(!1);
        });
    return {
        className: U("button"),
        toggle: r,
        enabledObserver: t.asObservable(),
        pendingObserver: n.asObservable()
    };
}
function ys(e, t, n) {
    const r = new ln(void 0), i = ho(t, e), o = (a, ...c)=>V(this, [
            a,
            ...c
        ], function*(u, l = {}) {
            var f, v, d;
            if (t) {
                const m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBrowser"])();
                if (e === "audiooutput" && ((m == null ? void 0 : m.name) === "Safari" || (m == null ? void 0 : m.os) === "iOS")) {
                    L.warn("Switching audio output device is not supported on Safari and iOS.");
                    return;
                }
                L.debug(`Switching active device of kind "${e}" with id ${u}.`), yield t.switchActiveDevice(e, u, l.exact);
                const p = (f = t.getActiveDevice(e)) != null ? f : u;
                p !== u && u !== "default" && L.info(`We tried to select the device with id (${u}), but the browser decided to select the device with id (${p}) instead.`);
                let g;
                e === "audioinput" ? g = (v = t.localParticipant.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone)) == null ? void 0 : v.track : e === "videoinput" && (g = (d = t.localParticipant.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera)) == null ? void 0 : d.track);
                const h = u === "default" && !g || u === "default" && (g == null ? void 0 : g.mediaStreamTrack.label.startsWith("Default"));
                r.next(h ? u : p);
            }
        });
    return {
        className: U("media-device-select"),
        activeDeviceObservable: i,
        setActiveMediaDevice: o
    };
}
function ws(e) {
    const t = (r)=>{
        e.disconnect(r);
    };
    return {
        className: U("disconnect-button"),
        disconnect: t
    };
}
function xs(e) {
    const t = U("connection-quality"), n = mo(e);
    return {
        className: t,
        connectionQualityObserver: n
    };
}
function Ss(e) {
    let t = "track-muted-indicator-camera";
    switch(e.source){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera:
            t = "track-muted-indicator-camera";
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone:
            t = "track-muted-indicator-microphone";
            break;
    }
    const n = U(t), r = go(e);
    return {
        className: n,
        mediaMutedObserver: r
    };
}
function Ts(e) {
    return {
        className: "lk-participant-name",
        infoObserver: vo(e)
    };
}
function Es() {
    return {
        className: U("participant-tile")
    };
}
var bo = {
    CHAT: "lk.chat",
    TRANSCRIPTION: "lk.transcription"
}, yo = {
    CHAT: "lk-chat-topic"
};
function Mn(e, t) {
    return V(this, arguments, function*(n, r, i = {}) {
        const { reliable: o, destinationIdentities: s, topic: a } = i;
        yield n.publishData(r, {
            destinationIdentities: s,
            topic: a,
            reliable: o
        });
    });
}
function wo(e, t, n) {
    const r = Array.isArray(t) ? t : [
        t
    ], i = lo(e).pipe(Je(([, , , c])=>t === void 0 || c !== void 0 && r.includes(c)), A(([c, u, , l])=>{
        const f = {
            payload: c,
            topic: l,
            from: u
        };
        return n == null || n(f), f;
    }));
    let o;
    const s = new k((c)=>{
        o = c;
    });
    return {
        messageObservable: i,
        isSendingObservable: s,
        send: (c, ...u)=>V(this, [
                c,
                ...u
            ], function*(l, f = {}) {
                o.next(!0);
                try {
                    yield Mn(e.localParticipant, l, Y({
                        topic: r[0]
                    }, f));
                } finally{
                    o.next(!1);
                }
            })
    };
}
var Ie = /* @__PURE__ */ new WeakMap();
function xo(e) {
    return e.ignoreLegacy == !0;
}
var So = (e)=>JSON.parse(new TextDecoder().decode(e)), To = (e)=>new TextEncoder().encode(JSON.stringify(e));
function Cs(e, t) {
    var n, r, i, o, s, a;
    const c = ()=>{
        var b, S, C;
        return ((b = e.serverInfo) == null ? void 0 : b.edition) === 1 || !!((S = e.serverInfo) != null && S.version) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["compareVersions"])((C = e.serverInfo) == null ? void 0 : C.version, "1.8.2") > 0;
    }, u = new ee(), l = (n = t == null ? void 0 : t.channelTopic) != null ? n : bo.CHAT, f = (r = t == null ? void 0 : t.channelTopic) != null ? r : yo.CHAT;
    let v = !1;
    Ie.has(e) || (v = !0);
    const d = (i = Ie.get(e)) != null ? i : /* @__PURE__ */ new Map(), m = (o = d.get(l)) != null ? o : new ee();
    d.set(l, m), Ie.set(e, d);
    const p = (s = t == null ? void 0 : t.messageDecoder) != null ? s : So;
    if (v) {
        e.registerTextStreamHandler(l, (S, C)=>V(this, null, function*() {
                const { id: $, timestamp: M } = S.info;
                Qe(S).pipe(ut((T, _)=>T + _), A((T)=>({
                        id: $,
                        timestamp: M,
                        message: T,
                        from: e.getParticipantByIdentity(C.identity),
                        type: "chatMessage"
                    }))).subscribe({
                    next: (T)=>m.next(T)
                });
            }));
        const { messageObservable: b } = wo(e, [
            f
        ]);
        b.pipe(A((S)=>{
            const C = p(S.payload);
            return xo(C) ? void 0 : se(Y({}, C), {
                type: "chatMessage",
                from: S.from
            });
        }), Je((S)=>!!S), Nt(u)).subscribe(m);
    }
    const g = m.pipe(ut((b, S)=>{
        if ("id" in S && b.find((C)=>{
            var $, M;
            return (($ = C.from) == null ? void 0 : $.identity) === ((M = S.from) == null ? void 0 : M.identity) && C.id === S.id;
        })) {
            const C = b.findIndex(($)=>$.id === S.id);
            if (C > -1) {
                const $ = b[C];
                b[C] = se(Y({}, S), {
                    timestamp: $.timestamp,
                    editTimestamp: S.timestamp
                });
            }
            return [
                ...b
            ];
        }
        return [
            ...b,
            S
        ];
    }, []), Nt(u)), h = new ln(!1), x = (a = t == null ? void 0 : t.messageEncoder) != null ? a : To, E = (b, S)=>V(this, null, function*() {
            var C;
            S || (S = {}), (C = S.topic) != null || (S.topic = l), h.next(!0);
            try {
                const M = {
                    id: (yield e.localParticipant.sendText(b, S)).id,
                    timestamp: Date.now(),
                    message: b
                }, z = se(Y({}, M), {
                    attachedFiles: S.attachments
                }), T = se(Y({}, z), {
                    type: "chatMessage",
                    from: e.localParticipant,
                    attributes: S.attributes
                });
                m.next(T);
                const _ = x(se(Y({}, M), {
                    ignoreLegacy: c()
                }));
                try {
                    yield Mn(e.localParticipant, _, {
                        reliable: !0,
                        topic: f
                    });
                } catch (Z) {
                    L.info("could not send message in legacy chat format", Z);
                }
                return T;
            } finally{
                h.next(!1);
            }
        });
    function O() {
        u.next(), u.complete(), m.complete(), Ie.delete(e), e.unregisterTextStreamHandler(l);
    }
    return e.once(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Disconnected, O), {
        messageObservable: g,
        isSendingObservable: h,
        send: E
    };
}
function Ps() {
    const e = (n)=>V(this, null, function*() {
            L.info("Start Audio for room: ", n), yield n.startAudio();
        });
    return {
        className: U("start-audio-button"),
        roomAudioPlaybackAllowedObservable: fo,
        handleStartAudioPlayback: e
    };
}
function Os() {
    const e = (n)=>V(this, null, function*() {
            L.info("Start Video for room: ", n), yield n.startVideo();
        });
    return {
        className: U("start-audio-button"),
        roomVideoPlaybackAllowedObservable: po,
        handleStartVideoPlayback: e
    };
}
function As() {
    return {
        className: [
            U("button"),
            U("chat-toggle")
        ].join(" ")
    };
}
function ks() {
    return {
        className: [
            U("button"),
            U("focus-toggle-button")
        ].join(" ")
    };
}
function _s() {
    return {
        className: "lk-clear-pin-button lk-button"
    };
}
function Ls() {
    return {
        className: "lk-room-container"
    };
}
function Vt(e, t, n = !0) {
    const i = [
        e.localParticipant,
        ...Array.from(e.remoteParticipants.values())
    ], o = [];
    return i.forEach((s)=>{
        t.forEach((a)=>{
            const c = Array.from(s.trackPublications.values()).filter((u)=>u.source === a && // either return all or only the ones that are subscribed
                (!n || u.track)).map((u)=>({
                    participant: s,
                    publication: u,
                    source: u.source
                }));
            o.push(...c);
        });
    }), {
        trackReferences: o,
        participants: i
    };
}
function Ht(e, t, n = !1) {
    const { sources: r, kind: i, name: o } = t;
    return Array.from(e.trackPublications.values()).filter((a)=>(!r || r.includes(a.source)) && (!i || a.kind === i) && (!o || a.trackName === o) && // either return all or only the ones that are subscribed
        (!n || a.track)).map((a)=>({
            participant: e,
            publication: a,
            source: a.source
        }));
}
function Is(e, t, n) {
    var r, i;
    const o = (r = n.additionalRoomEvents) != null ? r : Cn, s = (i = n.onlySubscribed) != null ? i : !0, a = Array.from(/* @__PURE__ */ new Set([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantConnected,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].LocalTrackPublished,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].LocalTrackUnpublished,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackPublished,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackUnpublished,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].TrackSubscriptionStatusChanged,
        ...o
    ]).values());
    return fe(e, ...a).pipe(A((u)=>{
        const l = Vt(u, t, s);
        return L.debug(`TrackReference[] was updated. (length ${l.trackReferences.length})`, l), l;
    }), D(Vt(e, t, s)));
}
function Ms(e, t) {
    return xe(e, ...qi).pipe(A((r)=>{
        const i = Ht(r, t);
        return L.debug(`TrackReference[] was updated. (length ${i.length})`, i), i;
    }), D(Ht(e, t)));
}
function Rn(e, t) {
    return new k((r)=>{
        const i = (...s)=>{
            r.next(s);
        };
        return e.on(t, i), ()=>{
            e.off(t, i);
        };
    });
}
function Rs(e) {
    return Rn(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TrackEvent"].TranscriptionReceived);
}
function Ds(e) {
    return Rn(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TrackEvent"].TimeSyncUpdate).pipe(A(([t])=>t));
}
function $s(e, t = 1e3) {
    if (e === null) return Dt(!1);
    const n = ct(e, "mousemove", {
        passive: !0
    }).pipe(A(()=>!0)), r = n.pipe(mi({
        each: t,
        with: ()=>We(Dt(!1), r.pipe(Ri(n)))
    }), Li());
    return r;
}
function Eo(e, t) {
    if (typeof localStorage > "u") {
        L.error("Local storage is not available.");
        return;
    }
    try {
        if (t) {
            const n = Object.fromEntries(Object.entries(t).filter(([, r])=>r !== ""));
            localStorage.setItem(e, JSON.stringify(n));
        }
    } catch (n) {
        L.error(`Error setting item to local storage: ${n}`);
    }
}
function Co(e) {
    if (typeof localStorage > "u") {
        L.error("Local storage is not available.");
        return;
    }
    try {
        const t = localStorage.getItem(e);
        if (!t) {
            L.warn(`Item with key ${e} does not exist in local storage.`);
            return;
        }
        return JSON.parse(t);
    } catch (t) {
        L.error(`Error getting item from local storage: ${t}`);
        return;
    }
}
function Po(e) {
    return {
        load: ()=>Co(e),
        save: (t)=>Eo(e, t)
    };
}
var Oo = `${En}-user-choices`, Te = {
    videoEnabled: !0,
    audioEnabled: !0,
    videoDeviceId: "default",
    audioDeviceId: "default",
    username: ""
}, { load: Ao, save: ko } = Po(Oo);
function Ns(e, t = !1) {
    t !== !0 && ko(e);
}
function Fs(e, t = !1) {
    var n, r, i, o, s;
    const a = {
        videoEnabled: (n = e == null ? void 0 : e.videoEnabled) != null ? n : Te.videoEnabled,
        audioEnabled: (r = e == null ? void 0 : e.audioEnabled) != null ? r : Te.audioEnabled,
        videoDeviceId: (i = e == null ? void 0 : e.videoDeviceId) != null ? i : Te.videoDeviceId,
        audioDeviceId: (o = e == null ? void 0 : e.audioDeviceId) != null ? o : Te.audioDeviceId,
        username: (s = e == null ? void 0 : e.username) != null ? s : Te.username
    };
    if (t) return a;
    {
        const c = Ao();
        return Y(Y({}, a), c ?? {});
    }
}
var rt = null, it = null, _o = 0;
function zt() {
    return rt || (rt = /* @__PURE__ */ new Map()), rt;
}
function Lo() {
    return it || (it = /* @__PURE__ */ new WeakMap()), it;
}
function Io(e, t) {
    const n = Lo();
    let r = n.get(e);
    return r || (r = `room_${_o++}`, n.set(e, r)), `${r}:${t}`;
}
function Us(e, t) {
    const n = Io(e, t), r = zt(), i = r.get(n);
    if (i) return i;
    const o = new ee();
    let s = [];
    const a = "lk.segment_id", c = o.pipe(Di({
        subscribe: ()=>{
            e.registerTextStreamHandler(t, (u, l)=>V(this, null, function*() {
                    var f;
                    const v = Qe(u).pipe(ut((m, p)=>m + p, "")), d = !!((f = u.info.attributes) != null && f[a]);
                    v.subscribe((m)=>{
                        const p = s.findIndex((g)=>{
                            var h, x;
                            return g.streamInfo.id === u.info.id || d && ((h = g.streamInfo.attributes) == null ? void 0 : h[a]) === ((x = u.info.attributes) == null ? void 0 : x[a]);
                        });
                        p !== -1 ? (s[p] = se(Y({}, s[p]), {
                            text: m
                        }), o.next([
                            ...s
                        ])) : (s.push({
                            text: m,
                            participantInfo: l,
                            streamInfo: u.info
                        }), o.next([
                            ...s
                        ]));
                    });
                }));
        },
        finalize: ()=>{
            e.unregisterTextStreamHandler(t);
        }
    }), Mi());
    return r.set(n, c), e.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Disconnected, ()=>{
        zt().delete(n), s = [], o.next([]);
    }), c;
}
function Dn(e, t) {
    if (t.msg === "show_chat") return {
        ...e,
        showChat: !0,
        unreadMessages: 0
    };
    if (t.msg === "hide_chat") return {
        ...e,
        showChat: !1
    };
    if (t.msg === "toggle_chat") {
        const n = {
            ...e,
            showChat: !e.showChat
        };
        return n.showChat === !0 && (n.unreadMessages = 0), n;
    } else return t.msg === "unread_msg" ? {
        ...e,
        unreadMessages: t.count
    } : t.msg === "toggle_settings" ? {
        ...e,
        showSettings: !e.showSettings
    } : {
        ...e
    };
}
function $n(e, t) {
    return t.msg === "set_pin" ? [
        t.trackReference
    ] : t.msg === "clear_pin" ? [] : {
        ...e
    };
}
const Nn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function js() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Nn);
    if (!e) throw Error("Tried to access LayoutContext context outside a LayoutContextProvider provider.");
    return e;
}
function Ws(e) {
    const t = Mo();
    if (e ?? (e = t), !e) throw Error("Tried to access LayoutContext context outside a LayoutContextProvider provider.");
    return e;
}
function Bs() {
    const [e, t] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useReducer"]($n, On), [n, r] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useReducer"](Dn, An);
    return {
        pin: {
            dispatch: t,
            state: e
        },
        widget: {
            dispatch: r,
            state: n
        }
    };
}
function Vs(e) {
    const [t, n] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useReducer"]($n, On), [r, i] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useReducer"](Dn, An);
    return e ?? {
        pin: {
            dispatch: n,
            state: t
        },
        widget: {
            dispatch: i,
            state: r
        }
    };
}
function Mo() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Nn);
}
const Fn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function Hs() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Fn);
    if (!e) throw Error("tried to access track context outside of track context provider");
    return e;
}
function Un() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Fn);
}
function zs(e) {
    const t = Un(), n = e ?? t;
    if (!n) throw new Error("No TrackRef, make sure you are inside a TrackRefContext or pass the TrackRef explicitly");
    return n;
}
const jn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function Ys() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](jn);
    if (!e) throw Error("tried to access participant context outside of participant context provider");
    return e;
}
function Ro() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](jn);
}
function qs(e) {
    const t = Ro(), n = Un(), r = e ?? t ?? (n == null ? void 0 : n.participant);
    if (!r) throw new Error("No participant provided, make sure you are inside a participant context or pass the participant explicitly");
    return r;
}
const Wn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function Ks() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Wn);
    if (!e) throw Error("tried to access room context outside of livekit room component");
    return e;
}
function Do() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Wn);
}
function Gs(e) {
    const t = Do(), n = e ?? t;
    if (!n) throw new Error("No room provided, make sure you are inside a Room context or pass the room explicitly");
    return n;
}
const Bn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function Qs() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Bn);
    if (!e) throw Error("tried to access session context outside of SessionProvider component");
    return e;
}
function $o() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](Bn);
}
function Js(e) {
    const t = $o(), n = e ?? t;
    if (!n) throw new Error("No session provided, make sure you are inside a Session context or pass the session explicitly");
    return n;
}
const No = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"](void 0);
function Xs(e) {
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"](No);
    if (e === !0) {
        if (t) return t;
        throw Error("tried to access feature context, but none is present");
    }
    return t;
}
;
 //# sourceMappingURL=contexts-CjCD4TaH.mjs.map
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/room-BH8Rm3Ha.mjs [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "L",
    ()=>W,
    "a",
    ()=>G,
    "c",
    ()=>H,
    "m",
    ()=>M,
    "r",
    ()=>T,
    "u",
    ()=>$,
    "w",
    ()=>Q
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.2_react-dom@19.1.1_react@19.1.1__react@19.1.1/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/livekit-client@2.15.15_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs [app-ssr] (ecmascript)");
;
;
;
function L(n) {
    var e, o, t = "";
    if (typeof n == "string" || typeof n == "number") t += n;
    else if (typeof n == "object") if (Array.isArray(n)) {
        var r = n.length;
        for(e = 0; e < r; e++)n[e] && (o = L(n[e])) && (t && (t += " "), t += o);
    } else for(o in n)n[o] && (t && (t += " "), t += o);
    return t;
}
function A() {
    for(var n, e, o = 0, t = "", r = arguments.length; o < r; o++)(n = arguments[o]) && (e = L(n)) && (t && (t += " "), t += e);
    return t;
}
function I(...n) {
    return (...e)=>{
        for (const o of n)if (typeof o == "function") try {
            o(...e);
        } catch (t) {
            console.error(t);
        }
    };
}
function M(...n) {
    const e = {
        ...n[0]
    };
    for(let o = 1; o < n.length; o++){
        const t = n[o];
        for(const r in t){
            const d = e[r], a = t[r];
            typeof d == "function" && typeof a == "function" && // This is a lot faster than a regex.
            r[0] === "o" && r[1] === "n" && r.charCodeAt(2) >= /* 'A' */ 65 && r.charCodeAt(2) <= /* 'Z' */ 90 ? e[r] = I(d, a) : (r === "className" || r === "UNSAFE_className") && typeof d == "string" && typeof a == "string" ? e[r] = A(d, a) : e[r] = a !== void 0 ? a : d;
        }
    }
    return e;
}
function J(n) {
    return n !== void 0;
}
function G(...n) {
    return M(...n.filter(J));
}
function H(n, e, o) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Children"].map(n, (t)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isValidElement"](t) && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Children"].only(n) ? (t.props.className && (e ?? (e = {}), e.className = A(t.props.className, e.className), e.style = {
            ...t.props.style,
            ...e.style
        }), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneElement"](t, {
            ...e,
            key: o
        })) : t);
}
function Q(n) {
    var e, o;
    if ("undefined" < "u" && typeof process < "u" && // eslint-disable-next-line turbo/no-undeclared-env-vars
    (((e = process == null ? void 0 : process.env) == null ? void 0 : e.NODE_ENV) === "dev" || // eslint-disable-next-line turbo/no-undeclared-env-vars
    ((o = process == null ? void 0 : process.env) == null ? void 0 : o.NODE_ENV) === "development")) {
        const t = document.querySelector(".lk-room-container");
        t && !getComputedStyle(t).getPropertyValue("--lk-has-imported-styles") && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn("It looks like you're not using the `@livekit/components-styles package`. To render the UI with the default styling, please import it in your layout or page.");
    }
}
function T(n, e) {
    return n === "processor" && e && typeof e == "object" && "name" in e ? e.name : n === "e2ee" && e ? "e2ee-enabled" : e;
}
const q = {
    connect: !0,
    audio: !1,
    video: !1
};
function $(n) {
    const { token: e, serverUrl: o, options: t, room: r, connectOptions: d, connect: a, audio: p, video: y, screen: g, onConnected: v, onDisconnected: h, onError: c, onMediaDeviceFailure: b, onEncryptionError: E, simulateParticipants: w, ...N } = {
        ...q,
        ...n
    };
    t && r && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn("when using a manually created room, the options object will be ignored. set the desired options directly when creating the room instead.");
    const [s, O] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](), C = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](a);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        O(r ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Room"](t));
    }, [
        r,
        JSON.stringify(t, T)
    ]);
    const F = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const { className: m } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])();
        return M(N, {
            className: m
        });
    }, [
        N
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!s) return;
        const m = ()=>{
            const f = s.localParticipant;
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("trying to publish local tracks"), Promise.all([
                f.setMicrophoneEnabled(!!p, typeof p != "boolean" ? p : void 0),
                f.setCameraEnabled(!!y, typeof y != "boolean" ? y : void 0),
                f.setScreenShareEnabled(!!g, typeof g != "boolean" ? g : void 0)
            ]).catch((R)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn(R), c == null || c(R);
            });
        }, P = (f, R)=>{
            const K = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MediaDeviceFailure"].getFailure(f);
            b == null || b(K, R);
        }, S = (f)=>{
            E == null || E(f);
        }, k = (f)=>{
            h == null || h(f);
        }, D = ()=>{
            v == null || v();
        };
        return s.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].SignalConnected, m).on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].MediaDevicesError, P).on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].EncryptionError, S).on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Disconnected, k).on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Connected, D), ()=>{
            s.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].SignalConnected, m).off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].MediaDevicesError, P).off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].EncryptionError, S).off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Disconnected, k).off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].Connected, D);
        };
    }, [
        s,
        p,
        y,
        g,
        c,
        E,
        b,
        v,
        h
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (s) {
            if (w) {
                s.simulateParticipants({
                    participants: {
                        count: w
                    },
                    publish: {
                        audio: !0,
                        useRealTracks: !0
                    }
                });
                return;
            }
            if (a) {
                if (C.current = !0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("connecting"), !e) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("no token yet");
                    return;
                }
                if (!o) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn("no livekit url provided"), c == null || c(Error("no livekit url provided"));
                    return;
                }
                s.connect(o, e, d).catch((m)=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn(m), C.current === !0 && (c == null || c(m));
                });
            } else __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("disconnecting because connect is false"), C.current = !1, s.disconnect();
        }
    }, [
        a,
        e,
        JSON.stringify(d),
        s,
        c,
        o,
        w
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (s) return ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].info("disconnecting on onmount"), s.disconnect();
        };
    }, [
        s
    ]), {
        room: s,
        htmlProps: F
    };
}
const W = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function(e, o) {
    const { room: t, htmlProps: r } = $(e);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: o,
        ...r
    }, t && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["R"].Provider, {
        value: t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["L"].Provider, {
        value: e.featureFlags
    }, e.children)));
});
;
 //# sourceMappingURL=room-BH8Rm3Ha.mjs.map
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$",
    ()=>on,
    "A",
    ()=>On,
    "B",
    ()=>Hn,
    "C",
    ()=>De,
    "D",
    ()=>kn,
    "E",
    ()=>Ln,
    "F",
    ()=>qt,
    "G",
    ()=>ve,
    "H",
    ()=>Bt,
    "I",
    ()=>Fn,
    "J",
    ()=>xn,
    "K",
    ()=>zt,
    "L",
    ()=>Vn,
    "M",
    ()=>me,
    "N",
    ()=>Bn,
    "O",
    ()=>Wt,
    "P",
    ()=>Jn,
    "Q",
    ()=>Yn,
    "R",
    ()=>dn,
    "S",
    ()=>Oe,
    "T",
    ()=>es,
    "U",
    ()=>ns,
    "V",
    ()=>se,
    "W",
    ()=>sn,
    "X",
    ()=>rs,
    "Y",
    ()=>rn,
    "Z",
    ()=>ss,
    "_",
    ()=>os,
    "a",
    ()=>ee,
    "a0",
    ()=>an,
    "a1",
    ()=>as,
    "a2",
    ()=>mn,
    "a3",
    ()=>cs,
    "a4",
    ()=>is,
    "a5",
    ()=>gn,
    "a6",
    ()=>us,
    "b",
    ()=>Gn,
    "c",
    ()=>An,
    "d",
    ()=>Rn,
    "e",
    ()=>In,
    "f",
    ()=>jn,
    "g",
    ()=>zn,
    "h",
    ()=>Qn,
    "i",
    ()=>Pn,
    "j",
    ()=>A,
    "k",
    ()=>$n,
    "l",
    ()=>Un,
    "m",
    ()=>Zn,
    "n",
    ()=>Dn,
    "o",
    ()=>_n,
    "p",
    ()=>Wn,
    "q",
    ()=>Vt,
    "r",
    ()=>jt,
    "s",
    ()=>ts,
    "t",
    ()=>Kn,
    "u",
    ()=>wn,
    "v",
    ()=>qn,
    "w",
    ()=>Qt,
    "x",
    ()=>Xn,
    "y",
    ()=>Nn,
    "z",
    ()=>Tn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.2_react-dom@19.1.1_react@19.1.1__react@19.1.1/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/room-BH8Rm3Ha.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/livekit-client@2.15.15_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
const Ft = (e)=>{
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](e);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        n.current = e;
    }), n;
};
function xt(e, n) {
    const t = Ht(), s = Ft(n);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLayoutEffect"](()=>{
        let o = !1;
        const c = e.current;
        if (!c) return;
        function a(i, d) {
            o || s.current(i, d);
        }
        return t == null || t.subscribe(c, a), ()=>{
            o = !0, t == null || t.unsubscribe(c, a);
        };
    }, [
        e.current,
        t,
        s
    ]), t == null ? void 0 : t.observer;
}
function Ut() {
    let e = !1, n = [];
    const t = /* @__PURE__ */ new Map();
    if ("undefined" > "u") return;
    const s = new ResizeObserver((o, c)=>{
        n = n.concat(o), e || window.requestAnimationFrame(()=>{
            const a = /* @__PURE__ */ new Set();
            for(let i = 0; i < n.length; i++){
                if (a.has(n[i].target)) continue;
                a.add(n[i].target);
                const d = t.get(n[i].target);
                d == null || d.forEach((l)=>l(n[i], c));
            }
            n = [], e = !1;
        }), e = !0;
    });
    return {
        observer: s,
        subscribe (o, c) {
            s.observe(o);
            const a = t.get(o) ?? [];
            a.push(c), t.set(o, a);
        },
        unsubscribe (o, c) {
            const a = t.get(o) ?? [];
            if (a.length === 1) {
                s.unobserve(o), t.delete(o);
                return;
            }
            const i = a.indexOf(c);
            i !== -1 && a.splice(i, 1), t.set(o, a);
        }
    };
}
let ae;
const Ht = ()=>ae || (ae = Ut()), Vt = (e)=>{
    const [n, t] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({
        width: 0,
        height: 0
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLayoutEffect"](()=>{
        if (e.current) {
            const { width: o, height: c } = e.current.getBoundingClientRect();
            t({
                width: o,
                height: c
            });
        }
    }, [
        e.current
    ]);
    const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((o)=>t(o.contentRect), []);
    return xt(e, s), n;
};
function A(e, n, t = !0) {
    const [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](n);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (t && o(n), "undefined" > "u" || !e) return;
        const c = e.subscribe(o);
        return ()=>c.unsubscribe();
    }, [
        e,
        t
    ]), s;
}
function Tn(e) {
    const n = (c)=>"undefined" < "u" ? window.matchMedia(c).matches : !1, [t, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](n(e));
    function o() {
        s(n(e));
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const c = window.matchMedia(e);
        return o(), c.addListener ? c.addListener(o) : c.addEventListener("change", o), ()=>{
            c.removeListener ? c.removeListener(o) : c.removeEventListener("change", o);
        };
    }, [
        e
    ]), t;
}
function kn(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async ()=>{
        await n.startAudio();
    }, [
        n
    ]), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["r"])(n), [
        n
    ]), { canPlayAudio: o } = A(s, {
        canPlayAudio: n.canPlaybackAudio
    });
    return {
        canPlayAudio: o,
        startAudio: t
    };
}
function wn(e) {
    const { state: n, dispatch: t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])().pin;
    return {
        buttonProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
            const { className: o } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["b"])();
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(e, {
                className: o,
                disabled: !(n != null && n.length),
                onClick: ()=>{
                    t && t({
                        msg: "clear_pin"
                    });
                }
            });
        }, [
            e,
            t,
            n
        ])
    };
}
function Pn(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(e.participant), { className: t, connectionQualityObserver: s } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["d"])(n), [
        n
    ]), o = A(s, n.connectionQuality);
    return {
        className: t,
        quality: o
    };
}
function ee(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(n), [
        n
    ]);
    return A(t, n.state);
}
function Ln(e, n) {
    const t = typeof e == "function" ? e : n, s = typeof e == "string" ? e : void 0, o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])(), { send: c, messageObservable: a, isSendingObservable: i } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["g"])(o, s, t), [
        o,
        s,
        t
    ]), d = A(a, void 0), l = A(i, !1);
    return {
        message: d,
        send: c,
        isSending: l
    };
}
function An(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])(), t = ee(n);
    return {
        buttonProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
            const { className: o, disconnect: c } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["h"])(n);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(e, {
                className: o,
                onClick: ()=>c(e.stopTracks ?? !0),
                disabled: t === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected
            });
        }, [
            n,
            e,
            t
        ])
    };
}
function qt(e) {
    if (e.publication instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LocalTrackPublication"]) {
        const n = e.publication.track;
        if (n) {
            const { facingMode: t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["facingModeFromLocalTrack"])(n);
            return t;
        }
    }
    return "undefined";
}
function Rn({ trackRef: e, props: n }) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(e), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(), { className: o } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(), []), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(t, s == null ? void 0 : s.pin.state), [
        t,
        s == null ? void 0 : s.pin.state
    ]);
    return {
        mergedProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(n, {
                className: o,
                onClick: (i)=>{
                    var d, l, b, u, p;
                    (d = n.onClick) == null || d.call(n, i), c ? (b = s == null ? void 0 : (l = s.pin).dispatch) == null || b.call(l, {
                        msg: "clear_pin"
                    }) : (p = s == null ? void 0 : (u = s.pin).dispatch) == null || p.call(u, {
                        msg: "set_pin",
                        trackReference: t
                    });
                }
            }), [
            n,
            o,
            t,
            c,
            s == null ? void 0 : s.pin
        ]),
        inFocus: c
    };
}
function Dn(e, n, t = {}) {
    const s = t.gridLayouts ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["G"], { width: o, height: c } = Vt(e), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"])(s, n, o, c);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        e.current && a && (e.current.style.setProperty("--lk-col-count", a == null ? void 0 : a.columns.toString()), e.current.style.setProperty("--lk-row-count", a == null ? void 0 : a.rows.toString()));
    }, [
        e,
        a
    ]), {
        layout: a,
        containerWidth: o,
        containerHeight: c
    };
}
function ve(e, n = {}) {
    var i, d;
    const t = typeof e == "string" ? n.participant : e.participant, s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(t), o = typeof e == "string" ? {
        participant: s,
        source: e
    } : e, [c, a] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](!!((i = o.publication) != null && i.isMuted || (d = s.getTrackPublication(o.source)) != null && d.isMuted));
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["o"])(o).subscribe(a);
        return ()=>l.unsubscribe();
    }, [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(o)
    ]), c;
}
function Bt(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(e), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(n), [
        n
    ]);
    return A(t, n.isSpeaking);
}
function De(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e.room), [t, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](n.localParticipant), [o, c] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.isMicrophoneEnabled), [a, i] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.isCameraEnabled), [d, l] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.isScreenShareEnabled), [b, u] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.lastMicrophoneError), [p, g] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.lastCameraError), [M, T] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](void 0), [L, k] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](void 0), D = (R)=>{
        i(R.isCameraEnabled), c(R.isMicrophoneEnabled), l(R.isScreenShareEnabled), k(R.cameraTrack), T(R.microphoneTrack), u(R.participant.lastMicrophoneError), g(R.participant.lastCameraError), s(R.participant);
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["t"])(n.localParticipant).subscribe(D);
        return ()=>R.unsubscribe();
    }, [
        n
    ]), {
        isMicrophoneEnabled: o,
        isScreenShareEnabled: d,
        isCameraEnabled: a,
        microphoneTrack: M,
        cameraTrack: L,
        lastMicrophoneError: b,
        lastCameraError: p,
        localParticipant: t
    };
}
function On() {
    const e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])(), n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["v"])(e.localParticipant), [
        e
    ]);
    return A(n, e.localParticipant.permissions);
}
function In({ kind: e, room: n, track: t, requestPermissions: s, onError: o }) {
    const c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>n ?? c ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Room"](), [
        n,
        c
    ]), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["x"])(e, o, s), [
        e,
        s,
        o
    ]), d = A(i, []), [l, b] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]((a == null ? void 0 : a.getActiveDevice(e)) ?? "default"), { className: u, activeDeviceObservable: p, setActiveMediaDevice: g } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["y"])(e, a), [
        e,
        a,
        t
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const M = p.subscribe((T)=>{
            T && (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].info("setCurrentDeviceId", T), b(T));
        });
        return ()=>{
            M == null || M.unsubscribe();
        };
    }, [
        p
    ]), {
        devices: d,
        className: u,
        activeDeviceId: l,
        setActiveMediaDevice: g
    };
}
function Nn({ kind: e, onError: n }) {
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["x"])(e, n), [
        e,
        n
    ]);
    return A(t, []);
}
function jt(e, n, t = {}) {
    const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"]([]), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](-1), c = n !== o.current, a = typeof t.customSortFunction == "function" ? t.customSortFunction(e) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"])(e);
    let i = [
        ...a
    ];
    if (c === !1) try {
        i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["A"])(s.current, a, n);
    } catch (d) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].error("Error while running updatePages(): ", d);
    }
    return c ? s.current = a : s.current = i, o.current = n, i;
}
function _n(e, n) {
    const [t, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](1), o = Math.max(Math.ceil(n.length / e), 1);
    t > o && s(o);
    const c = t * e, a = c - e, i = (u)=>{
        s((p)=>u === "next" ? p === o ? p : p + 1 : p === 1 ? p : p - 1);
    }, d = (u)=>{
        u > o ? s(o) : u < 1 ? s(1) : s(u);
    }, b = jt(n, e).slice(a, c);
    return {
        totalPageCount: o,
        nextPage: ()=>i("next"),
        prevPage: ()=>i("previous"),
        setPage: d,
        firstItemIndex: a,
        lastItemIndex: c,
        tracks: b,
        currentPage: t
    };
}
function Fn(e = {}) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"])();
    e.participant && (n = e.participant);
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["C"])(n), [
        n
    ]), { identity: s, name: o, metadata: c } = A(t, {
        name: n == null ? void 0 : n.name,
        identity: n == null ? void 0 : n.identity,
        metadata: n == null ? void 0 : n.metadata
    });
    return {
        identity: s,
        name: o,
        metadata: c
    };
}
function xn(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(e.participant), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["v"])(n), [
        n
    ]);
    return A(t, n.permissions);
}
function Un({ trackRef: e, onParticipantClick: n, disableSpeakingIndicator: t, htmlProps: s }) {
    const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(e), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const { className: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["D"])();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(s, {
            className: p,
            onClick: (g)=>{
                var M;
                if ((M = s.onClick) == null || M.call(s, g), typeof n == "function") {
                    const T = o.publication ?? o.participant.getTrackPublication(o.source);
                    n({
                        participant: o.participant,
                        track: T
                    });
                }
            }
        });
    }, [
        s,
        n,
        o.publication,
        o.source,
        o.participant
    ]), a = o.participant.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            participant: o.participant,
            source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
            publication: a
        }), [
        a,
        o.participant
    ]), d = ve(o), l = ve(i), b = Bt(o.participant), u = qt(o);
    return {
        elementProps: {
            "data-lk-audio-muted": l,
            "data-lk-video-muted": d,
            "data-lk-speaking": t === !0 ? !1 : b,
            "data-lk-local-participant": o.participant.isLocal,
            "data-lk-source": o.source,
            "data-lk-facing-mode": u,
            ...c
        }
    };
}
function me(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e.room), [t, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]([]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["E"])(n, {
            additionalRoomEvents: e.updateOnlyOn
        }).subscribe(s);
        return ()=>o.unsubscribe();
    }, [
        n,
        JSON.stringify(e.updateOnlyOn)
    ]), t;
}
function zt(e = {}) {
    const n = me(e), { localParticipant: t } = De(e);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>[
            t,
            ...n
        ], [
        t,
        n
    ]);
}
function Hn(e) {
    return e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["F"])(e), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(e == null ? void 0 : e.pin.state) !== void 0 && e.pin.state.length >= 1 ? e.pin.state : [], [
        e.pin.state
    ]);
}
function Vn(e, n = {}) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])(), [s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](n.updateOnlyOn), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>typeof e == "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["H"])(t, e, {
            additionalEvents: s
        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["I"])(t, e, {
            additionalEvents: s
        }), [
        t,
        JSON.stringify(e),
        s
    ]), [c, a] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({
        p: void 0
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const i = o.subscribe((d)=>a({
                p: d
            }));
        return ()=>i.unsubscribe();
    }, [
        o
    ]), c.p;
}
function qn(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e.room), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["J"])(n), [
        n
    ]), { name: s, metadata: o } = A(t, {
        name: n.name,
        metadata: n.metadata
    });
    return {
        name: s,
        metadata: o
    };
}
function Wt(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e == null ? void 0 : e.room), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["K"])(n), [
        n
    ]);
    return A(t, n.activeSpeakers);
}
function Bn(e) {
    const [n, t] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["M"])(e)), s = Wt();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        t((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["M"])(e));
    }, [
        s,
        e
    ]), n;
}
function jn({ room: e, props: n }) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e), { className: s, roomAudioPlaybackAllowedObservable: o, handleStartAudioPlayback: c } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["N"])(), []), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>o(t), [
        t,
        o
    ]), { canPlayAudio: i } = A(a, {
        canPlayAudio: t.canPlaybackAudio
    });
    return {
        mergedProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(n, {
                className: s,
                onClick: ()=>{
                    c(t);
                },
                style: {
                    display: i ? "none" : "block"
                }
            }), [
            n,
            s,
            i,
            c,
            t
        ]),
        canPlayAudio: i
    };
}
function zn({ room: e, props: n }) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e), { className: s, roomVideoPlaybackAllowedObservable: o, handleStartVideoPlayback: c } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["O"])(), []), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>o(t), [
        t,
        o
    ]), { canPlayVideo: i } = A(a, {
        canPlayVideo: t.canPlaybackVideo
    });
    return {
        mergedProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(n, {
                className: s,
                onClick: ()=>{
                    c(t);
                },
                style: {
                    display: i ? "none" : "block"
                }
            }), [
            n,
            s,
            i,
            c,
            t
        ]),
        canPlayVideo: i
    };
}
function Wn(e, n = {}) {
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](null), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](null), o = n.minSwipeDistance ?? 50, c = (d)=>{
        s.current = null, t.current = d.targetTouches[0].clientX;
    }, a = (d)=>{
        s.current = d.targetTouches[0].clientX;
    }, i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](()=>{
        if (!t.current || !s.current) return;
        const d = t.current - s.current, l = d > o, b = d < -o;
        l && n.onLeftSwipe && n.onLeftSwipe(), b && n.onRightSwipe && n.onRightSwipe();
    }, [
        o,
        n
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const d = e.current;
        return d && (d.addEventListener("touchstart", c, {
            passive: !0
        }), d.addEventListener("touchmove", a, {
            passive: !0
        }), d.addEventListener("touchend", i, {
            passive: !0
        })), ()=>{
            d && (d.removeEventListener("touchstart", c), d.removeEventListener("touchmove", a), d.removeEventListener("touchend", i));
        };
    }, [
        e,
        i
    ]);
}
function Gn({ props: e }) {
    const { dispatch: n, state: t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])().widget, { className: s } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["P"])(), []);
    return {
        mergedProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(e, {
                className: s,
                onClick: ()=>{
                    n && n({
                        msg: "toggle_chat"
                    });
                },
                "aria-pressed": t != null && t.showChat ? "true" : "false",
                "data-lk-unread-msgs": t ? t.unreadMessages < 10 ? t.unreadMessages.toFixed(0) : "9+" : "0"
            }), [
            e,
            s,
            n,
            t
        ])
    };
}
function Jn(e, n, t = {}) {
    const [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](void 0);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        var a;
        if (e === void 0) throw Error("token endpoint needs to be defined");
        if (((a = t.userInfo) == null ? void 0 : a.identity) === void 0) return;
        (async ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("fetching token");
            const i = new URLSearchParams({
                ...t.userInfo,
                roomName: n
            }), d = await fetch(`${e}?${i.toString()}`);
            if (!d.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].error(`Could not fetch token. Server responded with status ${d.status}: ${d.statusText}`);
                return;
            }
            const { accessToken: l } = await d.json();
            o(l);
        })();
    }, [
        e,
        n,
        JSON.stringify(t)
    ]), s;
}
function $n(e) {
    var c, a;
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(e), { className: t, mediaMutedObserver: s } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Q"])(n), [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(n)
    ]);
    return {
        isMuted: A(s, !!((c = n.publication) != null && c.isMuted || (a = n.participant.getTrackPublication(n.source)) != null && a.isMuted)),
        className: t
    };
}
function Qn({ source: e, onChange: n, initialState: t, captureOptions: s, publishOptions: o, onDeviceError: c, room: a, ...i }) {
    var m;
    const d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>a ?? d, [
        a,
        d
    ]), b = (m = l == null ? void 0 : l.localParticipant) == null ? void 0 : m.getTrackPublication(e), u = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](!1), { toggle: p, className: g, pendingObserver: M, enabledObserver: T } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>l ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["S"])(e, l, s, o, c) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["T"])(), [
        l,
        e,
        JSON.stringify(s),
        o
    ]), L = A(M, !1), k = A(T, t ?? !!(b != null && b.isEnabled));
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        n == null || n(k, u.current), u.current = !1;
    }, [
        k,
        n
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        t !== void 0 && (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("forcing initial toggle state", e, t), p(t));
    }, []);
    const D = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(i, {
            className: g
        }), [
        i,
        g
    ]), R = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((f)=>{
        var h;
        u.current = !0, p().catch(()=>u.current = !1), (h = i.onClick) == null || h.call(i, f);
    }, [
        i,
        p
    ]);
    return {
        toggle: p,
        enabled: k,
        pending: L,
        track: b,
        buttonProps: {
            ...D,
            "aria-pressed": k,
            "data-lk-source": e,
            "data-lk-enabled": k,
            disabled: L,
            onClick: R
        }
    };
}
function Kn(e = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShareAudio,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Unknown
], n = {}) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(n.room), [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]([]), [c, a] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]([]), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>e.map((l)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["U"])(l) ? l.source : l), [
        JSON.stringify(e)
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["V"])(t, i, {
            additionalRoomEvents: n.updateOnlyOn,
            onlySubscribed: n.onlySubscribed
        }).subscribe(({ trackReferences: b, participants: u })=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("setting track bundles", b, u), o(b), a(u);
        });
        return ()=>l.unsubscribe();
    }, [
        t,
        JSON.stringify(n.onlySubscribed),
        JSON.stringify(n.updateOnlyOn),
        JSON.stringify(e)
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["W"])(e)) {
            const l = Jt(e, c), b = Array.from(s);
            return c.forEach((u)=>{
                l.has(u.identity) && (l.get(u.identity) ?? []).forEach((g)=>{
                    if (s.find(({ participant: T, publication: L })=>u.identity === T.identity && L.source === g)) return;
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug(`Add ${g} placeholder for participant ${u.identity}.`);
                    const M = {
                        participant: u,
                        source: g
                    };
                    b.push(M);
                });
            }), b;
        } else return s;
    }, [
        s,
        c,
        e
    ]);
}
function Gt(e, n) {
    const t = new Set(e);
    for (const s of n)t.delete(s);
    return t;
}
function Jt(e, n) {
    const t = /* @__PURE__ */ new Map();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["W"])(e)) {
        const s = e.filter((o)=>o.withPlaceholder).map((o)=>o.source);
        n.forEach((o)=>{
            const c = o.getTrackPublications().map((i)=>{
                var d;
                return (d = i.track) == null ? void 0 : d.source;
            }).filter((i)=>i !== void 0), a = Array.from(Gt(new Set(s), new Set(c)));
            a.length > 0 && t.set(o.identity, a);
        });
    }
    return t;
}
function $t(e) {
    const [n, t] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["X"])(e)), { trackObserver: s } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Y"])(e), [
        e.participant.sid ?? e.participant.identity,
        e.source
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const o = s.subscribe((c)=>{
            t(c);
        });
        return ()=>o == null ? void 0 : o.unsubscribe();
    }, [
        s
    ]), {
        participant: e.participant,
        source: e.source ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Unknown,
        publication: n
    };
}
function Yn(e, n) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n);
    return $t({
        name: e,
        participant: t
    });
}
function Qt(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e == null ? void 0 : e.room), t = ee(n), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>t === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected, [
        t
    ]), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Z"])(n, e), [
        n,
        e,
        s
    ]), c = A(o.isSendingObservable, !1), a = A(o.messageObservable, []);
    return {
        send: o.send,
        chatMessages: a,
        isSending: c
    };
}
function Xn(e = {}) {
    const [n, t] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_"])(e.defaults, e.preventLoad ?? !1)), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((d)=>{
        t((l)=>({
                ...l,
                audioEnabled: d
            }));
    }, []), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((d)=>{
        t((l)=>({
                ...l,
                videoEnabled: d
            }));
    }, []), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((d)=>{
        t((l)=>({
                ...l,
                audioDeviceId: d
            }));
    }, []), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((d)=>{
        t((l)=>({
                ...l,
                videoDeviceId: d
            }));
    }, []), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((d)=>{
        t((l)=>({
                ...l,
                username: d
            }));
    }, []);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["$"])(n, e.preventSave ?? !1);
    }, [
        n,
        e.preventSave
    ]), {
        userChoices: n,
        saveAudioInputEnabled: s,
        saveVideoInputEnabled: o,
        saveAudioInputDeviceId: c,
        saveVideoInputDeviceId: a,
        saveUsername: i
    };
}
function Zn(e, n = {}) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(e), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(n.room), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a0"])(s, t), [
        s,
        t
    ]);
    return A(o, t.isLocal ? t.isE2EEEnabled : !!(t != null && t.isEncrypted));
}
function es(e, n = {
    fftSize: 32,
    smoothingTimeConstant: 0
}) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a1"])(e) ? e.publication.track : e, [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](0);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!t || !t.mediaStream) return;
        const { cleanup: c, analyser: a } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createAudioAnalyser"])(t, n), i = a.frequencyBinCount, d = new Uint8Array(i), b = setInterval(()=>{
            a.getByteFrequencyData(d);
            let u = 0;
            for(let p = 0; p < d.length; p++){
                const g = d[p];
                u += g * g;
            }
            o(Math.sqrt(u / d.length) / 255);
        }, 1e3 / 30);
        return ()=>{
            c(), clearInterval(b);
        };
    }, [
        t,
        t == null ? void 0 : t.mediaStream,
        JSON.stringify(n)
    ]), s;
}
const Kt = (e)=>{
    const n = (t)=>{
        let c = 1 - Math.max(-100, Math.min(-10, t)) * -1 / 100;
        return c = Math.sqrt(c), c;
    };
    return e.map((t)=>t === -1 / 0 ? 0 : n(t));
}, Yt = {
    bands: 5,
    loPass: 100,
    hiPass: 600,
    updateInterval: 32,
    analyserOptions: {
        fftSize: 2048
    }
};
function ts(e, n = {}) {
    var a;
    const t = e instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"] ? e : (a = e == null ? void 0 : e.publication) == null ? void 0 : a.track, s = {
        ...Yt,
        ...n
    }, [o, c] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](new Array(s.bands).fill(0));
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!t || !(t != null && t.mediaStream)) {
            c((g)=>g.slice().fill(0));
            return;
        }
        const { analyser: i, cleanup: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createAudioAnalyser"])(t, s.analyserOptions), l = i.frequencyBinCount, b = new Float32Array(l), p = setInterval(()=>{
            i.getFloatFrequencyData(b);
            let g = new Float32Array(b.length);
            for(let k = 0; k < b.length; k++)g[k] = b[k];
            g = g.slice(n.loPass, n.hiPass);
            const M = Kt(g), T = Math.ceil(M.length / s.bands), L = [];
            for(let k = 0; k < s.bands; k++){
                const D = M.slice(k * T, (k + 1) * T).reduce((R, m)=>R += m, 0);
                L.push(D / T);
            }
            c(L);
        }, s.updateInterval);
        return ()=>{
            d(), clearInterval(p);
        };
    }, [
        t,
        t == null ? void 0 : t.mediaStream,
        JSON.stringify(n)
    ]), o;
}
const Xt = {
    barCount: 120,
    volMultiplier: 5,
    updateInterval: 20
};
function ns(e, n = {}) {
    var b;
    const t = e instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"] ? e : (b = e == null ? void 0 : e.publication) == null ? void 0 : b.track, s = {
        ...Xt,
        ...n
    }, o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](new Float32Array()), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](performance.now()), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](0), [i, d] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]([]), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((u)=>{
        d(Array.from(en(u, s.barCount).map((p)=>Math.sqrt(p) * s.volMultiplier)));
    }, []);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!t || !(t != null && t.mediaStream)) return;
        const { analyser: u, cleanup: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createAudioAnalyser"])(t, {
            fftSize: Se(s.barCount)
        }), g = Se(s.barCount), M = new Float32Array(g), T = ()=>{
            if (L = requestAnimationFrame(T), u.getFloatTimeDomainData(M), o.current.map((k, D)=>k + M[D]), a.current += 1, performance.now() - c.current >= s.updateInterval) {
                const k = M.map((D)=>D / a.current);
                l(k), c.current = performance.now(), a.current = 0;
            }
        };
        let L = requestAnimationFrame(T);
        return ()=>{
            p(), cancelAnimationFrame(L);
        };
    }, [
        t,
        t == null ? void 0 : t.mediaStream,
        JSON.stringify(n),
        l
    ]), {
        bars: i
    };
}
function Se(e) {
    return e < 32 ? 32 : Zt(e);
}
function Zt(e) {
    let n = 2;
    for(; e >>= 1;)n <<= 1;
    return n;
}
function en(e, n) {
    const t = Math.floor(e.length / n), s = new Float32Array(n);
    for(let o = 0; o < n; o++){
        const c = t * o;
        let a = 0;
        for(let i = 0; i < t; i++)a = a + Math.abs(e[c + i]);
        s[o] = a / t;
    }
    return s;
}
function se(e, n = {}) {
    let t, s;
    typeof n == "string" ? t = n : (t = n == null ? void 0 : n.participantIdentity, s = n == null ? void 0 : n.room);
    const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"])(), c = zt({
        room: s,
        updateOnlyOn: []
    }), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>t ? c.find((l)=>l.identity === t) : o, [
        t,
        c,
        o
    ]), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        if (a) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a2"])(a, {
            sources: e
        });
    }, [
        a,
        JSON.stringify(e)
    ]);
    return A(i, []);
}
function tn(e) {
    var t, s, o;
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        var c;
        return (c = e == null ? void 0 : e.publication) != null && c.track ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a3"])(e == null ? void 0 : e.publication.track) : void 0;
    }, [
        (t = e == null ? void 0 : e.publication) == null ? void 0 : t.track
    ]);
    return A(n, {
        timestamp: Date.now(),
        rtpTimestamp: (o = (s = e == null ? void 0 : e.publication) == null ? void 0 : s.track) == null ? void 0 : o.rtpTimestamp
    });
}
const nn = {
    bufferSize: 100
};
function sn(e, n) {
    const t = {
        ...nn,
        ...n
    }, [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]([]), c = tn(e), a = (i)=>{
        var d;
        (d = t.onTranscription) == null || d.call(t, i), o((l)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a5"])(l, // when first receiving a segment, add the current media timestamp to it
            i.map((b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a6"])(b, c)), t.bufferSize));
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!(e != null && e.publication)) return;
        const i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a4"])(e.publication).subscribe((d)=>{
            a(...d);
        });
        return ()=>{
            i.unsubscribe();
        };
    }, [
        e && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(e),
        a
    ]), {
        segments: s
    };
}
function rn(e = {}) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"])(), t = e.participant ?? n, s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](// weird typescript constraint
    ()=>t ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a7"])(t) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a7"])(t), [
        t
    ]);
    return A(s, {
        attributes: t == null ? void 0 : t.attributes
    });
}
function ss(e, n = {}) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n.participant), [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.attributes[e]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!t) return;
        const c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a7"])(t).subscribe((a)=>{
            a.changed[e] !== void 0 && o(a.attributes[e]);
        });
        return ()=>{
            c.unsubscribe();
        };
    }, [
        t,
        e
    ]), s;
}
const ye = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].AgentState;
function rs() {
    const e = me(), n = e.find((u)=>u.kind === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantKind"].AGENT && !(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].PublishOnBehalf in u.attributes)), t = e.find((u)=>u.kind === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantKind"].AGENT && u.attributes[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].PublishOnBehalf] === (n == null ? void 0 : n.identity)), s = se([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera
    ], n == null ? void 0 : n.identity), o = se([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera
    ], t == null ? void 0 : t.identity), c = s.find((u)=>u.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone) ?? o.find((u)=>u.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone), a = s.find((u)=>u.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera) ?? o.find((u)=>u.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera), { segments: i } = sn(c), d = ee(), { attributes: l } = rn({
        participant: n
    }), b = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>d === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected ? "disconnected" : d === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connecting || !n || !(l != null && l[ye]) ? "connecting" : l[ye], [
        l,
        n,
        d
    ]);
    return {
        agent: n,
        state: b,
        audioTrack: c,
        videoTrack: a,
        agentTranscriptions: i,
        agentAttributes: l
    };
}
function os(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(e), t = ee(n), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a9"])(n), [
        n,
        t
    ]);
    return A(s, n.isRecording);
}
function on(e, n) {
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(n == null ? void 0 : n.room), o = ee(t) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected, c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aa"])(t, e), [
        t,
        e
    ]);
    return {
        textStreams: A(o ? void 0 : c, [])
    };
}
function an(e) {
    const { participantIdentities: n, trackSids: t } = e ?? {}, { textStreams: s } = on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ab"].TRANSCRIPTION, {
        room: e == null ? void 0 : e.room
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>s.filter((c)=>n ? n.includes(c.participantInfo.identity) : !0).filter((c)=>{
            var a;
            return t ? t.includes(((a = c.streamInfo.attributes) == null ? void 0 : a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].TranscribedTrackId]) ?? "") : !0;
        }), [
        s,
        n,
        t
    ]);
}
const Ce = 2, Me = 400, Ee = 3, Te = 1e3;
function as(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]), t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Mutex"](), []), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>t.lock().then(async (b)=>{
            for(;;){
                const u = n.current.pop();
                if (!u) {
                    b();
                    break;
                }
                switch(u.type){
                    case "connect":
                        await u.room.connect(...u.args).then(u.resolve).catch(u.reject);
                        break;
                    case "disconnect":
                        await u.room.disconnect(...u.args).then(u.resolve).catch(u.reject);
                        break;
                }
            }
        }), []), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((b)=>{
        let u = 0;
        o.current = o.current.filter((p)=>{
            const g = b.getTime() - p.getTime() < Te;
            return g && (u += 1), g;
        }), u > Ee && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn(`useSequentialRoomConnectDisconnect: room changed reference rapidly (over ${Ee}x in ${Te}ms). This is not recommended.`);
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        n.current = [];
        const b = /* @__PURE__ */ new Date();
        o.current.push(b), c(b);
    }, [
        e,
        c
    ]);
    const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((b)=>{
        let u = 0;
        a.current = a.current.filter((p)=>{
            const g = b.getTime() - p.getTime() < Me;
            return g && (u += 1), g;
        }), u > Ce && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn(`useSequentialRoomConnectDisconnect: room connect / disconnect occurring in rapid sequence (over ${Ce}x in ${Me}ms). This is not recommended and may be the sign of a bug like a useEffect dependency changing every render.`);
    }, []), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (...b)=>new Promise((u, p)=>{
            if (!e) throw new Error("Called connect(), but room was unset");
            const g = /* @__PURE__ */ new Date();
            i(g), n.current.push({
                type: "connect",
                room: e,
                args: b,
                resolve: u,
                reject: p
            }), a.current.push(g), s();
        }), [
        e,
        i,
        s
    ]), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (...b)=>new Promise((u, p)=>{
            if (!e) throw new Error("Called discconnect(), but room was unset");
            const g = /* @__PURE__ */ new Date();
            i(g), n.current.push({
                type: "disconnect",
                room: e,
                args: b,
                resolve: u,
                reject: p
            }), a.current.push(g), s();
        }), [
        e,
        i,
        s
    ]);
    return {
        connect: e ? d : null,
        disconnect: e ? l : null
    };
}
var te = {
    exports: {}
}, ke;
function cn() {
    if (ke) return te.exports;
    ke = 1;
    var e = typeof Reflect == "object" ? Reflect : null, n = e && typeof e.apply == "function" ? e.apply : function(f, h, v) {
        return Function.prototype.apply.call(f, h, v);
    }, t;
    e && typeof e.ownKeys == "function" ? t = e.ownKeys : Object.getOwnPropertySymbols ? t = function(f) {
        return Object.getOwnPropertyNames(f).concat(Object.getOwnPropertySymbols(f));
    } : t = function(f) {
        return Object.getOwnPropertyNames(f);
    };
    function s(m) {
        console && console.warn && console.warn(m);
    }
    var o = Number.isNaN || function(f) {
        return f !== f;
    };
    function c() {
        c.init.call(this);
    }
    te.exports = c, te.exports.once = k, c.EventEmitter = c, c.prototype._events = void 0, c.prototype._eventsCount = 0, c.prototype._maxListeners = void 0;
    var a = 10;
    function i(m) {
        if (typeof m != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof m);
    }
    Object.defineProperty(c, "defaultMaxListeners", {
        enumerable: !0,
        get: function() {
            return a;
        },
        set: function(m) {
            if (typeof m != "number" || m < 0 || o(m)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + m + ".");
            a = m;
        }
    }), c.init = function() {
        (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
    }, c.prototype.setMaxListeners = function(f) {
        if (typeof f != "number" || f < 0 || o(f)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + f + ".");
        return this._maxListeners = f, this;
    };
    function d(m) {
        return m._maxListeners === void 0 ? c.defaultMaxListeners : m._maxListeners;
    }
    c.prototype.getMaxListeners = function() {
        return d(this);
    }, c.prototype.emit = function(f) {
        for(var h = [], v = 1; v < arguments.length; v++)h.push(arguments[v]);
        var C = f === "error", E = this._events;
        if (E !== void 0) C = C && E.error === void 0;
        else if (!C) return !1;
        if (C) {
            var y;
            if (h.length > 0 && (y = h[0]), y instanceof Error) throw y;
            var I = new Error("Unhandled error." + (y ? " (" + y.message + ")" : ""));
            throw I.context = y, I;
        }
        var U = E[f];
        if (U === void 0) return !1;
        if (typeof U == "function") n(U, this, h);
        else for(var q = U.length, B = M(U, q), v = 0; v < q; ++v)n(B[v], this, h);
        return !0;
    };
    function l(m, f, h, v) {
        var C, E, y;
        if (i(h), E = m._events, E === void 0 ? (E = m._events = /* @__PURE__ */ Object.create(null), m._eventsCount = 0) : (E.newListener !== void 0 && (m.emit("newListener", f, h.listener ? h.listener : h), E = m._events), y = E[f]), y === void 0) y = E[f] = h, ++m._eventsCount;
        else if (typeof y == "function" ? y = E[f] = v ? [
            h,
            y
        ] : [
            y,
            h
        ] : v ? y.unshift(h) : y.push(h), C = d(m), C > 0 && y.length > C && !y.warned) {
            y.warned = !0;
            var I = new Error("Possible EventEmitter memory leak detected. " + y.length + " " + String(f) + " listeners added. Use emitter.setMaxListeners() to increase limit");
            I.name = "MaxListenersExceededWarning", I.emitter = m, I.type = f, I.count = y.length, s(I);
        }
        return m;
    }
    c.prototype.addListener = function(f, h) {
        return l(this, f, h, !1);
    }, c.prototype.on = c.prototype.addListener, c.prototype.prependListener = function(f, h) {
        return l(this, f, h, !0);
    };
    function b() {
        if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
    }
    function u(m, f, h) {
        var v = {
            fired: !1,
            wrapFn: void 0,
            target: m,
            type: f,
            listener: h
        }, C = b.bind(v);
        return C.listener = h, v.wrapFn = C, C;
    }
    c.prototype.once = function(f, h) {
        return i(h), this.on(f, u(this, f, h)), this;
    }, c.prototype.prependOnceListener = function(f, h) {
        return i(h), this.prependListener(f, u(this, f, h)), this;
    }, c.prototype.removeListener = function(f, h) {
        var v, C, E, y, I;
        if (i(h), C = this._events, C === void 0) return this;
        if (v = C[f], v === void 0) return this;
        if (v === h || v.listener === h) --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete C[f], C.removeListener && this.emit("removeListener", f, v.listener || h));
        else if (typeof v != "function") {
            for(E = -1, y = v.length - 1; y >= 0; y--)if (v[y] === h || v[y].listener === h) {
                I = v[y].listener, E = y;
                break;
            }
            if (E < 0) return this;
            E === 0 ? v.shift() : T(v, E), v.length === 1 && (C[f] = v[0]), C.removeListener !== void 0 && this.emit("removeListener", f, I || h);
        }
        return this;
    }, c.prototype.off = c.prototype.removeListener, c.prototype.removeAllListeners = function(f) {
        var h, v, C;
        if (v = this._events, v === void 0) return this;
        if (v.removeListener === void 0) return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : v[f] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete v[f]), this;
        if (arguments.length === 0) {
            var E = Object.keys(v), y;
            for(C = 0; C < E.length; ++C)y = E[C], y !== "removeListener" && this.removeAllListeners(y);
            return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
        }
        if (h = v[f], typeof h == "function") this.removeListener(f, h);
        else if (h !== void 0) for(C = h.length - 1; C >= 0; C--)this.removeListener(f, h[C]);
        return this;
    };
    function p(m, f, h) {
        var v = m._events;
        if (v === void 0) return [];
        var C = v[f];
        return C === void 0 ? [] : typeof C == "function" ? h ? [
            C.listener || C
        ] : [
            C
        ] : h ? L(C) : M(C, C.length);
    }
    c.prototype.listeners = function(f) {
        return p(this, f, !0);
    }, c.prototype.rawListeners = function(f) {
        return p(this, f, !1);
    }, c.listenerCount = function(m, f) {
        return typeof m.listenerCount == "function" ? m.listenerCount(f) : g.call(m, f);
    }, c.prototype.listenerCount = g;
    function g(m) {
        var f = this._events;
        if (f !== void 0) {
            var h = f[m];
            if (typeof h == "function") return 1;
            if (h !== void 0) return h.length;
        }
        return 0;
    }
    c.prototype.eventNames = function() {
        return this._eventsCount > 0 ? t(this._events) : [];
    };
    function M(m, f) {
        for(var h = new Array(f), v = 0; v < f; ++v)h[v] = m[v];
        return h;
    }
    function T(m, f) {
        for(; f + 1 < m.length; f++)m[f] = m[f + 1];
        m.pop();
    }
    function L(m) {
        for(var f = new Array(m.length), h = 0; h < f.length; ++h)f[h] = m[h].listener || m[h];
        return f;
    }
    function k(m, f) {
        return new Promise(function(h, v) {
            function C(y) {
                m.removeListener(f, E), v(y);
            }
            function E() {
                typeof m.removeListener == "function" && m.removeListener("error", C), h([].slice.call(arguments));
            }
            R(m, f, E, {
                once: !0
            }), f !== "error" && D(m, C, {
                once: !0
            });
        });
    }
    function D(m, f, h) {
        typeof m.on == "function" && R(m, "error", f, h);
    }
    function R(m, f, h, v) {
        if (typeof m.on == "function") v.once ? m.once(f, h) : m.on(f, h);
        else if (typeof m.addEventListener == "function") m.addEventListener(f, function C(E) {
            v.once && m.removeEventListener(f, C), h(E);
        });
        else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof m);
    }
    return te.exports;
}
var pe = cn();
const un = 2e4;
var dn = /* @__PURE__ */ ((e)=>(e.CameraChanged = "cameraChanged", e.MicrophoneChanged = "microphoneChanged", e.StateChanged = "stateChanged", e))(dn || {});
const F = (e)=>({
        isConnected: e === "listening" || e === "thinking" || e === "speaking",
        canListen: e === "pre-connect-buffering" || e === "listening" || e === "thinking" || e === "speaking",
        isFinished: e === "disconnected" || e === "failed",
        isPending: e === "connecting" || e === "initializing" || e === "idle"
    }), ln = ()=>{
    const [e, n] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](null), [t, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](null), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"]("connecting"), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](!1), a = (i)=>setTimeout(()=>{
            if (!c.current) {
                n("Agent did not join the room.");
                return;
            }
            const { isConnected: d } = F(o.current);
            if (!d) {
                n("Agent joined the room but did not complete initializing.");
                return;
            }
        }, i ?? un);
    return {
        agentTimeoutFailureReason: e,
        startAgentTimeout: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((i)=>{
            t && clearTimeout(t), n(null), s(a(i)), o.current = "connecting", c.current = !1;
        }, [
            t
        ]),
        clearAgentTimeout: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](()=>{
            t && clearTimeout(t), n(null), s(null), o.current = "connecting", c.current = !1;
        }, [
            t
        ]),
        updateAgentTimeoutState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((i)=>{
            o.current = i;
        }, []),
        updateAgentTimeoutParticipantExists: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((i)=>{
            c.current = i;
        }, [])
    };
};
function fn(e, n) {
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](n);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        t.current = n;
    }, [
        n
    ]);
    const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (a)=>{
        const { isConnected: i } = F(t.current);
        if (!i) return new Promise((d, l)=>{
            const b = (g)=>{
                const { isConnected: M } = F(g);
                M && (p(), d());
            }, u = ()=>{
                p(), l(new Error("useAgent(/* ... */).waitUntilConnected - signal aborted"));
            }, p = ()=>{
                e.off("stateChanged", b), a == null || a.removeEventListener("abort", u);
            };
            e.on("stateChanged", b), a == null || a.addEventListener("abort", u);
        });
    }, [
        e
    ]), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (a)=>{
        const { canListen: i } = F(t.current);
        if (!i) return new Promise((d, l)=>{
            const b = (g)=>{
                const { canListen: M } = F(g);
                M && (p(), d());
            }, u = ()=>{
                p(), l(new Error("useAgent(/* ... */).waitUntilCouldBeListening - signal aborted"));
            }, p = ()=>{
                e.off("stateChanged", b), a == null || a.removeEventListener("abort", u);
            };
            e.on("stateChanged", b), a == null || a.addEventListener("abort", u);
        });
    }, [
        e
    ]), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (a)=>{
        const { isFinished: i } = F(t.current);
        if (!i) return new Promise((d, l)=>{
            const b = (g)=>{
                const { isFinished: M } = F(g);
                M && (p(), d());
            }, u = ()=>{
                p(), l(new Error("useAgent(/* ... */).waitUntilFinished - signal aborted"));
            }, p = ()=>{
                e.off("stateChanged", b), a == null || a.removeEventListener("abort", u);
            };
            e.on("stateChanged", b), a == null || a.addEventListener("abort", u);
        });
    }, [
        e
    ]);
    return {
        waitUntilConnected: s,
        waitUntilCouldBeListening: o,
        waitUntilFinished: c
    };
}
function Oe(e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ac"])();
    if (e = e ?? n, !e) throw new Error("No session provided, make sure you are inside a Session context or pass the session explicitly");
    const { room: t, internal: { agentConnectTimeoutMilliseconds: s, agentTimeoutFailureReason: o, startAgentTimeout: c, clearAgentTimeout: a, updateAgentTimeoutState: i, updateAgentTimeoutParticipantExists: d } } = e, l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>new pe.EventEmitter(), []), b = me({
        room: t
    }), u = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>b.find((S)=>S.kind === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantKind"].AGENT && !(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].PublishOnBehalf in S.attributes)) ?? null, [
        b
    ]), p = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>u ? b.find((S)=>S.kind === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantKind"].AGENT && S.attributes[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].PublishOnBehalf] === u.identity) ?? null : null, [
        u,
        b
    ]), [g, M] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]({});
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!u) return;
        const S = (_)=>{
            M(_);
        };
        return u.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].AttributesChanged, S), ()=>{
            u.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].AttributesChanged, S);
        };
    }, [
        u,
        l
    ]);
    const T = se([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone
    ], {
        room: t,
        participantIdentity: u == null ? void 0 : u.identity
    }), L = se([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone
    ], {
        room: t,
        participantIdentity: p == null ? void 0 : p.identity
    }), k = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>T.find((S)=>S.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera) ?? L.find((S)=>S.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera), [
        T,
        L
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        l.emit("cameraChanged", k);
    }, [
        l,
        k
    ]);
    const D = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>T.find((S)=>S.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone) ?? L.find((S)=>S.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone), [
        T,
        L
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        l.emit("microphoneChanged", D);
    }, [
        l,
        D
    ]);
    const [R, m] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](t.state);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const S = (_)=>{
            m(_);
        };
        return t.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged, S), ()=>{
            t.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged, S);
        };
    }, [
        t
    ]);
    const [f, h] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!u) return;
        const S = (_)=>{
            _.identity === (u == null ? void 0 : u.identity) && h("Agent left the room unexpectedly.");
        };
        return t.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected, S), ()=>{
            t.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ParticipantDisconnected, S);
        };
    }, [
        u,
        t
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        R === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected && h(null);
    }, [
        R
    ]);
    const [v, C] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](()=>t.localParticipant.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone) ?? null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const S = ()=>{
            C(t.localParticipant.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone) ?? null);
        }, _ = ()=>{
            C(null);
        };
        return t.localParticipant.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished, S), t.localParticipant.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished, _), ()=>{
            t.localParticipant.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackPublished, S), t.localParticipant.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticipantEvent"].LocalTrackUnpublished, _);
        };
    }, [
        t.localParticipant
    ]);
    const E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const S = [];
        return o && S.push(o), f && S.push(f), S;
    }, [
        o,
        f
    ]), y = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        if (E.length > 0) return "failed";
        let S = "disconnected";
        return R !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected && (S = "connecting"), v && (S = "pre-connect-buffering"), u && g[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].AgentState] && (S = g[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a8"].AgentState]), S;
    }, [
        E,
        R,
        v,
        u,
        g
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        l.emit("stateChanged", y), i(y);
    }, [
        l,
        y
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        d(u !== null);
    }, [
        u
    ]);
    const I = e.connectionState === "disconnected";
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!I) return c(s), ()=>{
            a();
        };
    }, [
        I,
        s
    ]);
    const U = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const S = {
            attributes: g,
            internal: {
                agentParticipant: u,
                workerParticipant: p,
                emitter: l
            }
        };
        switch(y){
            case "disconnected":
                return {
                    ...S,
                    state: y,
                    ...F(y),
                    failureReasons: null,
                    // Clear inner values if no longer connected
                    cameraTrack: void 0,
                    microphoneTrack: void 0
                };
            case "connecting":
                return {
                    ...S,
                    state: y,
                    ...F(y),
                    failureReasons: null,
                    // Clear inner values if no longer connected
                    cameraTrack: void 0,
                    microphoneTrack: void 0
                };
            case "initializing":
            case "idle":
                return {
                    ...S,
                    state: y,
                    ...F(y),
                    failureReasons: null,
                    cameraTrack: k,
                    microphoneTrack: D
                };
            case "pre-connect-buffering":
                return {
                    ...S,
                    state: y,
                    ...F(y),
                    failureReasons: null,
                    cameraTrack: k,
                    microphoneTrack: D
                };
            case "listening":
            case "thinking":
            case "speaking":
                return {
                    ...S,
                    state: y,
                    ...F(y),
                    failureReasons: null,
                    cameraTrack: k,
                    microphoneTrack: D
                };
            case "failed":
                return {
                    ...S,
                    state: "failed",
                    ...F("failed"),
                    failureReasons: E,
                    // Clear inner values if no longer connected
                    cameraTrack: void 0,
                    microphoneTrack: void 0
                };
        }
    }, [
        g,
        l,
        u,
        y,
        k,
        D
    ]), { waitUntilConnected: q, waitUntilCouldBeListening: B, waitUntilFinished: P } = fn(l, y), N = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((S)=>new Promise((_, K)=>{
            const j = (W)=>{
                W && ($(), _(W));
            }, z = ()=>{
                $(), K(new Error("useAgent(/* ... */).waitUntilCamera - signal aborted"));
            }, $ = ()=>{
                l.off("cameraChanged", j), S == null || S.removeEventListener("abort", z);
            };
            l.on("cameraChanged", j), S == null || S.addEventListener("abort", z);
        }), [
        l
    ]), X = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((S)=>new Promise((_, K)=>{
            const j = (W)=>{
                W && ($(), _(W));
            }, z = ()=>{
                $(), K(new Error("useAgent(/* ... */).waitUntilMicrophone - signal aborted"));
            }, $ = ()=>{
                l.off("microphoneChanged", j), S == null || S.removeEventListener("abort", z);
            };
            l.on("microphoneChanged", j), S == null || S.addEventListener("abort", z);
        }), [
        l
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            ...U,
            waitUntilConnected: q,
            waitUntilCouldBeListening: B,
            waitUntilFinished: P,
            waitUntilCamera: N,
            waitUntilMicrophone: X
        }), [
        U,
        q,
        B,
        P,
        N,
        X
    ]);
}
var mn = /* @__PURE__ */ ((e)=>(e.ConnectionStateChanged = "connectionStateChanged", e.MediaDevicesError = "mediaDevicesError", e.EncryptionError = "encryptionError", e))(mn || {});
function pn(e, n) {
    const t = /* @__PURE__ */ new Set([
        ...Object.keys(e),
        ...Object.keys(n)
    ]);
    for (const s of t)switch(s){
        case "roomName":
        case "participantName":
        case "participantIdentity":
        case "participantMetadata":
        case "participantAttributes":
        case "agentName":
        case "agentMetadata":
            if (e[s] !== n[s]) return !1;
            break;
        default:
            const o = s;
            throw new Error(`Options key ${o} not being checked for equality!`);
    }
    return !0;
}
function hn(e, n) {
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](n);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        t.current = n;
    }, [
        n
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (o, c)=>{
        if (t.current !== o) return new Promise((a, i)=>{
            const d = (u)=>{
                u === o && (b(), a());
            }, l = ()=>{
                b(), i(new Error(`useSession(/* ... */).waitUntilConnectionState(${o}, /* signal */) - signal aborted`));
            }, b = ()=>{
                e.off("connectionStateChanged", d), c == null || c.removeEventListener("abort", l);
            };
            e.on("connectionStateChanged", d), c == null || c.addEventListener("abort", l);
        });
    }, [
        e
    ]);
}
function bn(e, n) {
    const t = e instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TokenSourceConfigurable"], s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](t ? n : null);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!t) {
            s.current = null;
            return;
        }
        s.current !== null && pn(s.current, n) || (s.current = n);
    }, [
        t,
        n
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async ()=>{
        if (t) {
            if (!s.current) throw new Error("AgentSession - memoized token fetch options are not set, but the passed tokenSource was an instance of TokenSourceConfigurable. If you are seeing this please make a new GitHub issue!");
            return e.fetch(s.current);
        } else return e.fetch();
    }, [
        t,
        e
    ]);
}
function cs(e, n = {}) {
    const { room: t, agentConnectTimeoutMilliseconds: s, ...o } = n, c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(), a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>c ?? t ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Room"](), [
        c,
        t
    ]), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>new pe.EventEmitter(), []), d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((P)=>({
            isConnected: P === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connected || P === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Reconnecting || P === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].SignalReconnecting
        }), []), [l, b] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](a.state);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const P = (N)=>{
            b(N);
        };
        return a.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged, P), ()=>{
            a.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].ConnectionStateChanged, P);
        };
    }, [
        a
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const P = async (N)=>{
            i.emit("mediaDevicesError", N);
        };
        return a.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].MediaDevicesError, P), ()=>{
            a.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].MediaDevicesError, P);
        };
    }, [
        a,
        i
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const P = async (N)=>{
            i.emit("encryptionError", N);
        };
        return a.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].EncryptionError, P), ()=>{
            a.off(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].EncryptionError, P);
        };
    }, [
        a,
        i
    ]);
    const { localParticipant: u } = De({
        room: a
    }), p = u.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera), g = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>!p || p.isMuted ? null : {
            source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera,
            participant: u,
            publication: p
        }, [
        u,
        p,
        p == null ? void 0 : p.isMuted
    ]), M = u.getTrackPublication(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>!M || M.isMuted ? null : {
            source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
            participant: u,
            publication: M
        }, [
        u,
        M,
        M == null ? void 0 : M.isMuted
    ]), { agentTimeoutFailureReason: L, startAgentTimeout: k, clearAgentTimeout: D, updateAgentTimeoutState: R, updateAgentTimeoutParticipantExists: m } = ln(), f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            emitter: i,
            tokenSource: e,
            agentConnectTimeoutMilliseconds: s,
            agentTimeoutFailureReason: L,
            startAgentTimeout: k,
            clearAgentTimeout: D,
            updateAgentTimeoutState: R,
            updateAgentTimeoutParticipantExists: m
        }), [
        i,
        s,
        e,
        L,
        k,
        D,
        R,
        m
    ]), h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const P = {
            room: a,
            internal: f
        };
        switch(l){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connecting:
                return {
                    ...P,
                    connectionState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connecting,
                    ...d(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connecting),
                    local: {
                        cameraTrack: null,
                        microphoneTrack: null
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connected:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Reconnecting:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].SignalReconnecting:
                return {
                    ...P,
                    connectionState: l,
                    ...d(l),
                    local: {
                        cameraTrack: g,
                        microphoneTrack: T
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected:
                return {
                    ...P,
                    connectionState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected,
                    ...d(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected),
                    local: {
                        cameraTrack: null,
                        microphoneTrack: null
                    }
                };
        }
    }, [
        f,
        a,
        l,
        g,
        T,
        d
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        i.emit("connectionStateChanged", h.connectionState);
    }, [
        i,
        h.connectionState
    ]);
    const v = hn(i, h.connectionState), C = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (P)=>v(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connected, P), [
        v
    ]), E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (P)=>v(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected, P), [
        v
    ]), y = Oe(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            connectionState: h.connectionState,
            room: a,
            internal: f
        }), [
        h,
        a,
        f
    ])), I = bn(e, o), U = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async (P = {})=>{
        var j, z;
        const { signal: N, tracks: X = {
            microphone: {
                enabled: !0,
                publishOptions: {
                    preConnectBuffer: !0
                }
            }
        }, roomConnectOptions: S } = P;
        await E(N);
        const _ = ()=>{
            a.disconnect();
        };
        N == null || N.addEventListener("abort", _);
        let K = !1;
        await Promise.all([
            I().then(({ serverUrl: $, participantToken: W })=>{
                var he, be;
                return K = (((be = (he = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["decodeTokenPayload"])(W).roomConfig) == null ? void 0 : he.agents) == null ? void 0 : be.length) ?? 0) > 0, a.connect($, W, S);
            }),
            // Start microphone (with preconnect buffer) by default
            (j = X.microphone) != null && j.enabled ? a.localParticipant.setMicrophoneEnabled(!0, void 0, ((z = X.microphone) == null ? void 0 : z.publishOptions) ?? {}) : Promise.resolve()
        ]), await C(N), K && await y.waitUntilConnected(N), N == null || N.removeEventListener("abort", _);
    }, [
        a,
        E,
        I,
        C,
        y.waitUntilConnected
    ]), q = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async ()=>{
        await a.disconnect();
    }, [
        a
    ]), B = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](async ()=>{
        const P = await I();
        await a.prepareConnection(P.serverUrl, P.participantToken);
    }, [
        I,
        a
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        B().catch((P)=>{
            console.warn("WARNING: Room.prepareConnection failed:", P);
        });
    }, []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            ...h,
            waitUntilConnected: C,
            waitUntilDisconnected: E,
            prepareConnection: B,
            start: U,
            end: q
        }), [
        h,
        C,
        E,
        B,
        U,
        q
    ]);
}
function is(e, n, t, s) {
    const o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>()=>{}, []), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"](t ?? o, s ?? []), a = s ? c : t, i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>e ? "internal" in e ? e.internal.emitter : e : null, [
        e
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        if (!(!i || !a)) return i.on(n, a), ()=>{
            i.off(n, a);
        };
    }, [
        i,
        n,
        a
    ]);
}
var gn = /* @__PURE__ */ ((e)=>(e.MessageReceived = "messageReceived", e))(gn || {});
function us(e) {
    const { room: n } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ad"])(e), t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>new pe.EventEmitter(), []), s = Oe(e), o = an({
        room: n
    }), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            room: n
        }), [
        n
    ]), a = Qt(c), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>o.map((p)=>{
            var g, M, T;
            switch(p.participantInfo.identity){
                case n.localParticipant.identity:
                    return {
                        type: "userTranscript",
                        message: p.text,
                        id: p.streamInfo.id,
                        timestamp: p.streamInfo.timestamp,
                        from: n.localParticipant
                    };
                case (g = s.internal.agentParticipant) == null ? void 0 : g.identity:
                case (M = s.internal.workerParticipant) == null ? void 0 : M.identity:
                    return {
                        type: "agentTranscript",
                        message: p.text,
                        id: p.streamInfo.id,
                        timestamp: p.streamInfo.timestamp,
                        from: ((T = s.internal.agentParticipant) == null ? void 0 : T.identity) === p.participantInfo.identity ? s.internal.agentParticipant : s.internal.workerParticipant
                    };
                default:
                    return {
                        type: "agentTranscript",
                        message: p.text,
                        id: p.streamInfo.id,
                        timestamp: p.streamInfo.timestamp,
                        from: Array.from(n.remoteParticipants.values()).find((L)=>L.identity === p.participantInfo.identity)
                    };
            }
        }), [
        o,
        n
    ]), d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>[
            ...i,
            ...a.chatMessages
        ], [
        i,
        a.chatMessages
    ]), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](/* @__PURE__ */ new Map()), b = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>{
        const p = /* @__PURE__ */ new Date();
        for (const g of d)l.current.has(g.id) || l.current.set(g.id, p);
        return d.sort((g, M)=>{
            const T = l.current.get(g.id), L = l.current.get(M.id);
            return typeof T > "u" || typeof L > "u" ? 0 : T.getTime() - L.getTime();
        });
    }, [
        d
    ]), u = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](/* @__PURE__ */ new Set());
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        for (const p of b)u.current.has(p.id) || (u.current.add(p.id), t.emit("messageReceived", p));
    }, [
        b
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            messages: b,
            send: a.send,
            isSending: a.isSending,
            internal: {
                emitter: t
            }
        }), [
        b,
        a.send,
        a.isSending
    ]);
}
;
 //# sourceMappingURL=hooks-CA8cirWq.mjs.map
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$",
    ()=>Pt,
    "A",
    ()=>Ma,
    "B",
    ()=>Kt,
    "C",
    ()=>sa,
    "D",
    ()=>ia,
    "E",
    ()=>pt,
    "F",
    ()=>Ea,
    "G",
    ()=>wa,
    "H",
    ()=>wt,
    "I",
    ()=>ie,
    "J",
    ()=>kt,
    "K",
    ()=>Rt,
    "L",
    ()=>Ra,
    "M",
    ()=>fa,
    "N",
    ()=>Mt,
    "O",
    ()=>yt,
    "P",
    ()=>Ot,
    "Q",
    ()=>bt,
    "R",
    ()=>ba,
    "S",
    ()=>oa,
    "T",
    ()=>va,
    "U",
    ()=>St,
    "V",
    ()=>Bt,
    "W",
    ()=>Ct,
    "X",
    ()=>It,
    "Y",
    ()=>Re,
    "Z",
    ()=>xt,
    "_",
    ()=>oe,
    "a",
    ()=>xa,
    "b",
    ()=>Nt,
    "c",
    ()=>ua,
    "d",
    ()=>da,
    "e",
    ()=>ma,
    "f",
    ()=>ga,
    "g",
    ()=>ka,
    "h",
    ()=>pa,
    "i",
    ()=>Ia,
    "j",
    ()=>Ce,
    "k",
    ()=>Ca,
    "l",
    ()=>Gt,
    "m",
    ()=>Pa,
    "n",
    ()=>ca,
    "o",
    ()=>la,
    "p",
    ()=>Tt,
    "q",
    ()=>ha,
    "r",
    ()=>ye,
    "s",
    ()=>ne,
    "t",
    ()=>K,
    "u",
    ()=>be,
    "v",
    ()=>ya,
    "w",
    ()=>Sa,
    "x",
    ()=>jt,
    "y",
    ()=>_t,
    "z",
    ()=>Ta
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.2_react-dom@19.1.1_react@19.1.1__react@19.1.1/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/room-BH8Rm3Ha.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/livekit-client@2.15.15_@types+dom-mediacapture-record@1.0.22/node_modules/livekit-client/dist/livekit-client.esm.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
const ca = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function(n, a) {
    const { buttonProps: c } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(n);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: a,
        ...c
    }, n.children);
}), la = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ room: n, ...a }, c) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(n);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: c,
        ...a
    }, r);
}), sa = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function(n, a) {
    const { mergedProps: c } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["b"])({
        props: n
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: a,
        ...c
    }, n.children);
}), ia = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function(n, a) {
    const { buttonProps: c } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: a,
        ...c
    }, n.children);
}), pt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentColor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M1.354.646a.5.5 0 1 0-.708.708l14 14a.5.5 0 0 0 .708-.708L11 10.293V4.5A1.5 1.5 0 0 0 9.5 3H3.707zM0 4.5a1.5 1.5 0 0 1 .943-1.393l9.532 9.533c-.262.224-.603.36-.975.36h-8A1.5 1.5 0 0 1 0 11.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "m15.2 3.6-2.8 2.1a1 1 0 0 0-.4.8v3a1 1 0 0 0 .4.8l2.8 2.1a.5.5 0 0 0 .8-.4V4a.5.5 0 0 0-.8-.4z"
    })), wt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentColor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 4.5A1.5 1.5 0 0 1 1.5 3h8A1.5 1.5 0 0 1 11 4.5v7A1.5 1.5 0 0 1 9.5 13h-8A1.5 1.5 0 0 1 0 11.5zM15.2 3.6l-2.8 2.1a1 1 0 0 0-.4.8v3a1 1 0 0 0 .4.8l2.8 2.1a.5.5 0 0 0 .8-.4V4a.5.5 0 0 0-.8-.4z"
    })), oa = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        viewBox: "0 0 24 24",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "#FFF",
        d: "M4.99 3.99a1 1 0 0 0-.697 1.717L10.586 12l-6.293 6.293a1 1 0 1 0 1.414 1.414L12 13.414l6.293 6.293a1 1 0 1 0 1.414-1.414L13.414 12l6.293-6.293a1 1 0 0 0-.727-1.717 1 1 0 0 0-.687.303L12 10.586 5.707 4.293a1 1 0 0 0-.717-.303z"
    })), ua = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 18,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M0 2.75A2.75 2.75 0 0 1 2.75 0h10.5A2.75 2.75 0 0 1 16 2.75v13.594a.75.75 0 0 1-1.234.572l-3.691-3.12a1.25 1.25 0 0 0-.807-.296H2.75A2.75 2.75 0 0 1 0 10.75v-8ZM2.75 1.5c-.69 0-1.25.56-1.25 1.25v8c0 .69.56 1.25 1.25 1.25h7.518c.65 0 1.279.23 1.775.65l2.457 2.077V2.75c0-.69-.56-1.25-1.25-1.25H2.75Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M3 4.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5Zm0 2a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5Zm0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5Z",
        clipRule: "evenodd"
    })), ie = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentcolor",
        fillRule: "evenodd",
        d: "M5.293 2.293a1 1 0 0 1 1.414 0l4.823 4.823a1.25 1.25 0 0 1 0 1.768l-4.823 4.823a1 1 0 0 1-1.414-1.414L9.586 8 5.293 3.707a1 1 0 0 1 0-1.414z",
        clipRule: "evenodd"
    })), kt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M10 1.75h4.25m0 0V6m0-4.25L9 7M6 14.25H1.75m0 0V10m0 4.25L7 9"
    }))), da = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentcolor",
        fillRule: "evenodd",
        d: "M8.961.894C8.875-.298 7.125-.298 7.04.894c-.066.912-1.246 1.228-1.76.472-.67-.99-2.186-.115-1.664.96.399.824-.465 1.688-1.288 1.289-1.076-.522-1.95.994-.961 1.665.756.513.44 1.693-.472 1.759-1.192.086-1.192 1.836 0 1.922.912.066 1.228 1.246.472 1.76-.99.67-.115 2.186.96 1.664.824-.399 1.688.465 1.289 1.288-.522 1.076.994 1.95 1.665.961.513-.756 1.693-.44 1.759.472.086 1.192 1.836 1.192 1.922 0 .066-.912 1.246-1.228 1.76-.472.67.99 2.186.115 1.664-.96-.399-.824.465-1.688 1.288-1.289 1.076.522 1.95-.994.961-1.665-.756-.513-.44-1.693.472-1.759 1.192-.086 1.192-1.836 0-1.922-.912-.066-1.228-1.246-.472-1.76.99-.67.115-2.186-.96-1.664-.824.399-1.688-.465-1.289-1.288.522-1.076-.994-1.95-1.665-.961-.513.756-1.693.44-1.759-.472ZM8 13A5 5 0 1 0 8 3a5 5 0 0 0 0 10Z",
        clipRule: "evenodd"
    })), ma = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M2 2.75A2.75 2.75 0 0 1 4.75 0h6.5A2.75 2.75 0 0 1 14 2.75v10.5A2.75 2.75 0 0 1 11.25 16h-6.5A2.75 2.75 0 0 1 2 13.25v-.5a.75.75 0 0 1 1.5 0v.5c0 .69.56 1.25 1.25 1.25h6.5c.69 0 1.25-.56 1.25-1.25V2.75c0-.69-.56-1.25-1.25-1.25h-6.5c-.69 0-1.25.56-1.25 1.25v.5a.75.75 0 0 1-1.5 0v-.5Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M8.78 7.47a.75.75 0 0 1 0 1.06l-2.25 2.25a.75.75 0 1 1-1.06-1.06l.97-.97H1.75a.75.75 0 0 1 0-1.5h4.69l-.97-.97a.75.75 0 0 1 1.06-1.06l2.25 2.25Z",
        clipRule: "evenodd"
    })), Rt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentcolor",
        fillRule: "evenodd",
        d: "M4 6.104V4a4 4 0 1 1 8 0v2.104c1.154.326 2 1.387 2 2.646v4.5A2.75 2.75 0 0 1 11.25 16h-6.5A2.75 2.75 0 0 1 2 13.25v-4.5c0-1.259.846-2.32 2-2.646ZM5.5 4a2.5 2.5 0 0 1 5 0v2h-5V4Z",
        clipRule: "evenodd"
    })), Mt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentColor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M12.227 11.52a5.477 5.477 0 0 0 1.246-2.97.5.5 0 0 0-.995-.1 4.478 4.478 0 0 1-.962 2.359l-1.07-1.07C10.794 9.247 11 8.647 11 8V3a3 3 0 0 0-6 0v1.293L1.354.646a.5.5 0 1 0-.708.708l14 14a.5.5 0 0 0 .708-.708zM8 12.5c.683 0 1.33-.152 1.911-.425l.743.743c-.649.359-1.378.59-2.154.66V15h2a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1h2v-1.522a5.502 5.502 0 0 1-4.973-4.929.5.5 0 0 1 .995-.098A4.5 4.5 0 0 0 8 12.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M8.743 10.907 5 7.164V8a3 3 0 0 0 3.743 2.907z"
    })), yt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentColor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fillRule: "evenodd",
        d: "M2.975 8.002a.5.5 0 0 1 .547.449 4.5 4.5 0 0 0 8.956 0 .5.5 0 1 1 .995.098A5.502 5.502 0 0 1 8.5 13.478V15h2a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1h2v-1.522a5.502 5.502 0 0 1-4.973-4.929.5.5 0 0 1 .448-.547z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M5 3a3 3 0 1 1 6 0v5a3 3 0 0 1-6 0z"
    })), bt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentcolor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-6a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-6a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    })), St = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentcolor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        opacity: 0.25
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M12 .5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M12 .5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }))), Ct = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentcolor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        opacity: 0.25
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M6 6.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M6 6.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5zm6-6a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M12 .5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5z"
    }))), It = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "currentColor",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        opacity: 0.25
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-4Zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-9Zm6-6a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V.5Z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M0 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-4Zm6-5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-9Zm6-6a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V.5Z"
    }))), Re = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 20,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M0 2.75A2.75 2.75 0 0 1 2.75 0h14.5A2.75 2.75 0 0 1 20 2.75v10.5A2.75 2.75 0 0 1 17.25 16H2.75A2.75 2.75 0 0 1 0 13.25V2.75ZM2.75 1.5c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h14.5c.69 0 1.25-.56 1.25-1.25V2.75c0-.69-.56-1.25-1.25-1.25H2.75Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M9.47 4.22a.75.75 0 0 1 1.06 0l2.25 2.25a.75.75 0 0 1-1.06 1.06l-.97-.97v4.69a.75.75 0 0 1-1.5 0V6.56l-.97.97a.75.75 0 0 1-1.06-1.06l2.25-2.25Z",
        clipRule: "evenodd"
    })), xt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 20,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        fill: "currentColor"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M7.28 4.22a.75.75 0 0 0-1.06 1.06L8.94 8l-2.72 2.72a.75.75 0 1 0 1.06 1.06L10 9.06l2.72 2.72a.75.75 0 1 0 1.06-1.06L11.06 8l2.72-2.72a.75.75 0 0 0-1.06-1.06L10 6.94z"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fillRule: "evenodd",
        d: "M2.75 0A2.75 2.75 0 0 0 0 2.75v10.5A2.75 2.75 0 0 0 2.75 16h14.5A2.75 2.75 0 0 0 20 13.25V2.75A2.75 2.75 0 0 0 17.25 0zM1.5 2.75c0-.69.56-1.25 1.25-1.25h14.5c.69 0 1.25.56 1.25 1.25v10.5c0 .69-.56 1.25-1.25 1.25H2.75c-.69 0-1.25-.56-1.25-1.25z",
        clipRule: "evenodd"
    }))), oe = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M8 0a.75.75 0 0 1 .75.75v2.5a.75.75 0 0 1-1.5 0V.75A.75.75 0 0 1 8 0Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M8 12a.75.75 0 0 1 .75.75v2.5a.75.75 0 0 1-1.5 0v-2.5A.75.75 0 0 1 8 12Z",
        clipRule: "evenodd",
        opacity: 0.7
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M12 1.072a.75.75 0 0 1 .274 1.024l-1.25 2.165a.75.75 0 0 1-1.299-.75l1.25-2.165A.75.75 0 0 1 12 1.072Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M6 11.464a.75.75 0 0 1 .274 1.025l-1.25 2.165a.75.75 0 0 1-1.299-.75l1.25-2.165A.75.75 0 0 1 6 11.464Z",
        clipRule: "evenodd",
        opacity: 0.6
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M14.928 4a.75.75 0 0 1-.274 1.025l-2.165 1.25a.75.75 0 1 1-.75-1.3l2.165-1.25A.75.75 0 0 1 14.928 4Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M4.536 10a.75.75 0 0 1-.275 1.024l-2.165 1.25a.75.75 0 0 1-.75-1.298l2.165-1.25A.75.75 0 0 1 4.536 10Z",
        clipRule: "evenodd",
        opacity: 0.5
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M16 8a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h2.5A.75.75 0 0 1 16 8Z",
        clipRule: "evenodd"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M4 8a.75.75 0 0 1-.75.75H.75a.75.75 0 0 1 0-1.5h2.5A.75.75 0 0 1 4 8Z",
        clipRule: "evenodd",
        opacity: 0.4
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M14.928 12a.75.75 0 0 1-1.024.274l-2.165-1.25a.75.75 0 0 1 .75-1.299l2.165 1.25A.75.75 0 0 1 14.928 12Z",
        clipRule: "evenodd",
        opacity: 0.9
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M4.536 6a.75.75 0 0 1-1.025.275l-2.165-1.25a.75.75 0 1 1 .75-1.3l2.165 1.25A.75.75 0 0 1 4.536 6Z",
        clipRule: "evenodd",
        opacity: 0.3
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M12 14.928a.75.75 0 0 1-1.024-.274l-1.25-2.165a.75.75 0 0 1 1.298-.75l1.25 2.165A.75.75 0 0 1 12 14.928Z",
        clipRule: "evenodd",
        opacity: 0.8
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        fill: "currentColor",
        fillRule: "evenodd",
        d: "M6 4.536a.75.75 0 0 1-1.024-.275l-1.25-2.165a.75.75 0 1 1 1.299-.75l1.25 2.165A.75.75 0 0 1 6 4.536Z",
        clipRule: "evenodd",
        opacity: 0.2
    })), Pt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 16,
        height: 16,
        fill: "none",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M13.25 7H9m0 0V2.75M9 7l5.25-5.25M2.75 9H7m0 0v4.25M7 9l-5.25 5.25"
    }))), Tt = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ trackRef: n, ...a }, c) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ae"])(), { mergedProps: s, inFocus: o } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["d"])({
        trackRef: n ?? r,
        props: a
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["af"].Consumer, null, (l)=>l !== void 0 && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
            ref: c,
            ...s
        }, a.children ? a.children : o ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Pt, null) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](kt, null)));
}), fa = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ kind: n, initialSelection: a, onActiveDeviceChange: c, onDeviceListChange: r, onDeviceSelectError: s, exactMatch: o, track: l, requestPermissions: i, onError: d, ...u }, v) {
    const f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(), p = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"]("default"), E = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((w)=>{
        f && f.emit(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RoomEvent"].MediaDevicesError, w), d == null || d(w);
    }, [
        f,
        d
    ]), { devices: h, activeDeviceId: m, setActiveMediaDevice: y, className: C } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])({
        kind: n,
        room: f,
        track: l,
        requestPermissions: i,
        onError: E
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        a !== void 0 && y(a);
    }, [
        y
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        typeof r == "function" && r(h);
    }, [
        r,
        h
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        m !== p.current && (c == null || c(m)), p.current = m;
    }, [
        m
    ]);
    const A = async (w)=>{
        try {
            await y(w, {
                exact: o ?? !0
            });
        } catch (M) {
            if (M instanceof Error) s == null || s(M);
            else throw M;
        }
    }, N = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(u, {
            className: C
        }, {
            className: "lk-list"
        }), [
        C,
        u
    ]), g = !!h.find((w)=>w.label.toLowerCase().startsWith("default"));
    function R(w, M, P) {
        return w === M || !g && P === 0 && M === "default";
    }
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("ul", {
        ref: v,
        ...N
    }, h.map((w, M)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("li", {
            key: w.deviceId,
            id: w.deviceId,
            "data-lk-active": R(w.deviceId, m, M),
            "aria-selected": R(w.deviceId, m, M),
            role: "option"
        }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
            className: "lk-button",
            onClick: ()=>A(w.deviceId)
        }, w.label))));
}), ha = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ label: n = "Allow Audio", ...a }, c) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"])(a.room), { mergedProps: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])({
        room: r,
        props: a
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: c,
        ...s
    }, n);
}), ga = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ label: n, ...a }, c) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])(), { mergedProps: s, canPlayAudio: o } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"])({
        room: r,
        props: a
    }), { mergedProps: l, canPlayVideo: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["g"])({
        room: r,
        props: s
    }), { style: d, ...u } = l;
    return d.display = o && i ? "none" : "block", /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: c,
        style: d,
        ...u
    }, n ?? `Start ${o ? "Video" : "Audio"}`);
});
function Me(t, n) {
    switch(t){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone:
            return n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](yt, null) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Mt, null);
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera:
            return n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](wt, null) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](pt, null);
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare:
            return n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](xt, null) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Re, null);
        default:
            return;
    }
}
function At(t) {
    switch(t){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionQuality"].Excellent:
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](bt, null);
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionQuality"].Good:
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](St, null);
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionQuality"].Poor:
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Ct, null);
        default:
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](It, null);
    }
}
const va = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ showIcon: n, ...a }, c) {
    const { buttonProps: r, enabled: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["h"])(a), [o, l] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](!1);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        l(!0);
    }, []), o && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        ref: c,
        ...r
    }, (n ?? !0) && Me(a.source, s), a.children);
}), ye = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function(n, a) {
    const { className: c, quality: r } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(n), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>({
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(n, {
                className: c
            }),
            "data-lk-quality": r
        }), [
        r,
        n,
        c
    ]);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: a,
        ...s
    }, n.children ?? At(r));
}), K = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ participant: n, ...a }, c) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n), { className: s, infoObserver: o } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ag"])(r), [
        r
    ]), { identity: l, name: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(o, {
        name: r.name,
        identity: r.identity,
        metadata: r.metadata
    }), d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(a, {
            className: s,
            "data-lk-participant-name": i
        }), [
        a,
        s,
        i
    ]);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        ref: c,
        ...d
    }, i !== "" ? i : l, a.children);
}), be = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ trackRef: n, show: a = "always", ...c }, r) {
    const { className: s, isMuted: o } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(n), l = a === "always" || a === "muted" && o || a === "unmuted" && !o, i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(c, {
            className: s
        }), [
        s,
        c
    ]);
    return l ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: r,
        ...i,
        "data-lk-muted": o
    }, c.children ?? Me(n.source, !o)) : null;
}), Nt = (t)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        width: 320,
        height: 320,
        viewBox: "0 0 320 320",
        preserveAspectRatio: "xMidYMid meet",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...t
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M160 180C204.182 180 240 144.183 240 100C240 55.8172 204.182 20 160 20C115.817 20 79.9997 55.8172 79.9997 100C79.9997 144.183 115.817 180 160 180Z",
        fill: "white",
        fillOpacity: 0.25
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("path", {
        d: "M97.6542 194.614C103.267 191.818 109.841 192.481 115.519 195.141C129.025 201.466 144.1 205 159.999 205C175.899 205 190.973 201.466 204.48 195.141C210.158 192.481 216.732 191.818 222.345 194.614C262.703 214.719 291.985 253.736 298.591 300.062C300.15 310.997 291.045 320 280 320H39.9997C28.954 320 19.8495 310.997 21.4087 300.062C28.014 253.736 57.2966 214.72 97.6542 194.614Z",
        fill: "white",
        fillOpacity: 0.25
    }));
function Se(t, n = {}) {
    const [a, c] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["X"])(t)), [r, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](a == null ? void 0 : a.isMuted), [o, l] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](a == null ? void 0 : a.isSubscribed), [i, d] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](a == null ? void 0 : a.track), [u, v] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"]("landscape"), f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](), { className: p, trackObserver: E } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Y"])(t), [
        t.participant.sid ?? t.participant.identity,
        t.source,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a1"])(t) && t.publication.trackSid
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        const h = E.subscribe((m)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("update track", m), c(m), s(m == null ? void 0 : m.isMuted), l(m == null ? void 0 : m.isSubscribed), d(m == null ? void 0 : m.track);
        });
        return ()=>h == null ? void 0 : h.unsubscribe();
    }, [
        E
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        var h, m;
        return i && (f.current && i.detach(f.current), (h = n.element) != null && h.current && !(t.participant.isLocal && (i == null ? void 0 : i.kind) === "audio") && i.attach(n.element.current)), f.current = (m = n.element) == null ? void 0 : m.current, ()=>{
            f.current && (i == null || i.detach(f.current));
        };
    }, [
        i,
        n.element
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        var h, m;
        if (typeof ((h = a == null ? void 0 : a.dimensions) == null ? void 0 : h.width) == "number" && typeof ((m = a == null ? void 0 : a.dimensions) == null ? void 0 : m.height) == "number") {
            const y = a.dimensions.width > a.dimensions.height ? "landscape" : "portrait";
            v(y);
        }
    }, [
        a
    ]), {
        publication: a,
        isMuted: r,
        isSubscribed: o,
        track: i,
        elementProps: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(n.props, {
            className: p,
            "data-lk-local-participant": t.participant.isLocal,
            "data-lk-source": a == null ? void 0 : a.source,
            ...(a == null ? void 0 : a.kind) === "video" && {
                "data-lk-orientation": u
            }
        })
    };
}
var Y, ue;
function Lt() {
    if (ue) return Y;
    ue = 1;
    var t = "Expected a function", n = NaN, a = "[object Symbol]", c = /^\s+|\s+$/g, r = /^[-+]0x[0-9a-f]+$/i, s = /^0b[01]+$/i, o = /^0o[0-7]+$/i, l = parseInt, i = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ah"] == "object" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ah"] && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ah"].Object === Object && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ah"], d = typeof self == "object" && self && self.Object === Object && self, u = i || d || Function("return this")(), v = Object.prototype, f = v.toString, p = Math.max, E = Math.min, h = function() {
        return u.Date.now();
    };
    function m(g, R, w) {
        var M, P, O, L, b, T, F = 0, re = !1, Z = !1, D = !0;
        if (typeof g != "function") throw new TypeError(t);
        R = N(R) || 0, y(w) && (re = !!w.leading, Z = "maxWait" in w, O = Z ? p(N(w.maxWait) || 0, R) : O, D = "trailing" in w ? !!w.trailing : D);
        function U(k) {
            var x = M, H = P;
            return M = P = void 0, F = k, L = g.apply(H, x), L;
        }
        function xe(k) {
            return F = k, b = setTimeout(W, R), re ? U(k) : L;
        }
        function Pe(k) {
            var x = k - T, H = k - F, se = R - x;
            return Z ? E(se, O - H) : se;
        }
        function ce(k) {
            var x = k - T, H = k - F;
            return T === void 0 || x >= R || x < 0 || Z && H >= O;
        }
        function W() {
            var k = h();
            if (ce(k)) return le(k);
            b = setTimeout(W, Pe(k));
        }
        function le(k) {
            return b = void 0, D && M ? U(k) : (M = P = void 0, L);
        }
        function Te() {
            b !== void 0 && clearTimeout(b), F = 0, M = T = P = b = void 0;
        }
        function Ae() {
            return b === void 0 ? L : le(h());
        }
        function G() {
            var k = h(), x = ce(k);
            if (M = arguments, P = this, T = k, x) {
                if (b === void 0) return xe(T);
                if (Z) return b = setTimeout(W, R), U(T);
            }
            return b === void 0 && (b = setTimeout(W, R)), L;
        }
        return G.cancel = Te, G.flush = Ae, G;
    }
    function y(g) {
        var R = typeof g;
        return !!g && (R == "object" || R == "function");
    }
    function C(g) {
        return !!g && typeof g == "object";
    }
    function A(g) {
        return typeof g == "symbol" || C(g) && f.call(g) == a;
    }
    function N(g) {
        if (typeof g == "number") return g;
        if (A(g)) return n;
        if (y(g)) {
            var R = typeof g.valueOf == "function" ? g.valueOf() : g;
            g = y(R) ? R + "" : R;
        }
        if (typeof g != "string") return g === 0 ? g : +g;
        g = g.replace(c, "");
        var w = s.test(g);
        return w || o.test(g) ? l(g.slice(2), w ? 2 : 8) : r.test(g) ? n : +g;
    }
    return Y = m, Y;
}
var zt = Lt();
const de = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ai"])(zt);
function Vt(t) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(t);
    n.current = t, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>{
            n.current();
        }, []);
}
function Ft(t, n = 500, a) {
    const c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    Vt(()=>{
        c.current && c.current.cancel();
    });
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const s = de(t, n, a), o = (...l)=>s(...l);
        return o.cancel = ()=>{
            s.cancel();
        }, o.isPending = ()=>!!c.current, o.flush = ()=>s.flush(), o;
    }, [
        t,
        n,
        a
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        c.current = de(t, n, a);
    }, [
        t,
        n,
        a
    ]), r;
}
function Zt(t, n, a) {
    const c = (d, u)=>d === u, r = t instanceof Function ? t() : t, [s, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(r), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(r), i = Ft(o, n, a);
    return c(l.current, r) || (i(r), l.current = r), [
        s,
        i
    ];
}
function Ht({ threshold: t = 0, root: n = null, rootMargin: a = "0%", freezeOnceVisible: c = !1, initialIsIntersecting: r = !1, onChange: s } = {}) {
    var o;
    const [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [d, u] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>({
            isIntersecting: r,
            entry: void 0
        })), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    v.current = s;
    const f = ((o = d.entry) == null ? void 0 : o.isIntersecting) && c;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!l || !("IntersectionObserver" in window) || f) return;
        const h = new IntersectionObserver((m)=>{
            const y = Array.isArray(h.thresholds) ? h.thresholds : [
                h.thresholds
            ];
            m.forEach((C)=>{
                const A = C.isIntersecting && y.some((N)=>C.intersectionRatio >= N);
                u({
                    isIntersecting: A,
                    entry: C
                }), v.current && v.current(A, C);
            });
        }, {
            threshold: t,
            root: n,
            rootMargin: a
        });
        return h.observe(l), ()=>{
            h.disconnect();
        };
    }, [
        l,
        // eslint-disable-next-line react-hooks/exhaustive-deps
        JSON.stringify(t),
        n,
        a,
        f,
        c
    ]);
    const p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var h;
        !l && (h = d.entry) != null && h.target && !c && !f && p.current !== d.entry.target && (p.current = d.entry.target, u({
            isIntersecting: r,
            entry: void 0
        }));
    }, [
        l,
        d.entry,
        c,
        f,
        r
    ]);
    const E = [
        i,
        !!d.isIntersecting,
        d.entry
    ];
    return E.ref = E[0], E.isIntersecting = E[1], E.entry = E[2], E;
}
const Bt = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ onTrackClick: n, onClick: a, onSubscriptionStatusChanged: c, trackRef: r, manageSubscription: s, ...o }, l) {
    const i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(r), d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useImperativeHandle"](l, ()=>d.current);
    const u = Ht({
        root: d.current
    }), [v] = Zt(u, 3e3);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        s && i.publication instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoteTrackPublication"] && (v == null ? void 0 : v.isIntersecting) === !1 && (u == null ? void 0 : u.isIntersecting) === !1 && i.publication.setSubscribed(!1);
    }, [
        v,
        i,
        s
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        s && i.publication instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoteTrackPublication"] && (u == null ? void 0 : u.isIntersecting) === !0 && i.publication.setSubscribed(!0);
    }, [
        u,
        i,
        s
    ]);
    const { elementProps: f, publication: p, isSubscribed: E } = Se(i, {
        element: d,
        props: o
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        c == null || c(!!E);
    }, [
        E,
        c
    ]);
    const h = (m)=>{
        a == null || a(m), n == null || n({
            participant: i == null ? void 0 : i.participant,
            track: p
        });
    };
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("video", {
        ref: d,
        ...f,
        muted: !0,
        onClick: h
    });
}), ne = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ trackRef: n, onSubscriptionStatusChanged: a, volume: c, ...r }, s) {
    const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(n), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useImperativeHandle"](s, ()=>l.current);
    const { elementProps: i, isSubscribed: d, track: u, publication: v } = Se(o, {
        element: l,
        props: r
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        a == null || a(!!d);
    }, [
        d,
        a
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        u === void 0 || c === void 0 || (u instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoteAudioTrack"] ? u.setVolume(c) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn("Volume can only be set on remote audio tracks."));
    }, [
        c,
        u
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        v === void 0 || r.muted === void 0 || (v instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoteTrackPublication"] ? v.setEnabled(!r.muted) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].warn("Can only call setEnabled on remote track publications."));
    }, [
        r.muted,
        v,
        u
    ]), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("audio", {
        ref: l,
        ...i
    });
});
function jt(t) {
    const n = !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"])();
    return t.participant && !n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aj"].Provider, {
        value: t.participant
    }, t.children) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, t.children);
}
function _t(t) {
    const n = !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ae"])();
    return t.trackRef && !n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ak"].Provider, {
        value: t.trackRef
    }, t.children) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, t.children);
}
const Ot = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ trackRef: n, children: a, onParticipantClick: c, disableSpeakingIndicator: r, ...s }, o) {
    var p, E;
    const l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(n), { elementProps: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"])({
        htmlProps: s,
        disableSpeakingIndicator: r,
        onParticipantClick: c,
        trackRef: l
    }), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(l.participant), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(), v = (p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["al"])()) == null ? void 0 : p.autoSubscription, f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"]((h)=>{
        l.source && !h && u && u.pin.dispatch && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"])(l, u.pin.state) && u.pin.dispatch({
            msg: "clear_pin"
        });
    }, [
        l,
        u
    ]);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: o,
        style: {
            position: "relative"
        },
        ...i
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](_t, {
        trackRef: l
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](jt, {
        participant: l.participant
    }, a ?? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a1"])(l) && (((E = l.publication) == null ? void 0 : E.kind) === "video" || l.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera || l.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShare) ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Bt, {
        trackRef: l,
        onSubscriptionStatusChanged: f,
        manageSubscription: v
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a1"])(l) && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ne, {
        trackRef: l,
        onSubscriptionStatusChanged: f
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-participant-placeholder"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Nt, null)), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-participant-metadata"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-participant-metadata-item"
    }, l.source === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Camera ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, d && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Rt, {
        style: {
            marginRight: "0.25rem"
        }
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](be, {
        trackRef: {
            participant: l.participant,
            source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone
        },
        show: "muted"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](K, null)) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Re, {
        style: {
            marginRight: "0.25rem"
        }
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](K, null, "'s screen"))), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ye, {
        className: "lk-participant-metadata-item"
    }))), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Tt, {
        trackRef: l
    }))));
});
function Ea(t) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(t, {
        className: "lk-focus-layout"
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ...n
    }, t.children);
}
function pa({ trackRef: t, ...n }) {
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Ot, {
        trackRef: t,
        ...n
    });
}
function Ce({ tracks: t, ...n }) {
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, t.map((a)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ak"].Provider, {
            value: a,
            key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(a)
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n.children))));
}
function Wt({ totalPageCount: t, nextPage: n, prevPage: a, currentPage: c, pagesContainer: r }) {
    const [s, o] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](!1);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        let l;
        return r && (l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["am"])(r.current, 2e3).subscribe(o)), ()=>{
            l && l.unsubscribe();
        };
    }, [
        r
    ]), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-pagination-control",
        "data-lk-user-interaction": s
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        className: "lk-button",
        onClick: a
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ie, null)), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        className: "lk-pagination-count"
    }, `${c} of ${t}`), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("button", {
        className: "lk-button",
        onClick: n
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ie, null)));
}
const qt = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ totalPageCount: n, currentPage: a }, c) {
    const r = new Array(n).fill("").map((s, o)=>o + 1 === a ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
            "data-lk-active": !0,
            key: o
        }) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
            key: o
        }));
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: c,
        className: "lk-pagination-indicator"
    }, r);
});
function wa({ tracks: t, ...n }) {
    const a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createRef"](), c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(n, {
            className: "lk-grid-layout"
        }), [
        n
    ]), { layout: r } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"])(a, t.length), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["o"])(r.maxTiles, t);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(a, {
        onLeftSwipe: s.nextPage,
        onRightSwipe: s.prevPage
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: a,
        "data-lk-pagination": s.totalPageCount > 1,
        ...c
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Ce, {
        tracks: s.tracks
    }, n.children), t.length > r.maxTiles && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](qt, {
        totalPageCount: s.totalPageCount,
        currentPage: s.currentPage
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Wt, {
        pagesContainer: a,
        ...s
    })));
}
const $t = 130, Dt = 140, me = 1, Ie = 16 / 10, Ut = (1 - Ie) * -1;
function ka({ tracks: t, orientation: n, ...a }) {
    const c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"](null), [r, s] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](0), { width: o, height: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(c), i = n || (l >= o ? "vertical" : "horizontal"), d = i === "vertical" ? Math.max(o * Ut, $t) : Math.max(l * Ie, Dt), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["an"])(), v = Math.max(i === "vertical" ? (l - u) / d : (o - u) / d, me);
    let f = Math.round(v);
    Math.abs(v - r) < 0.5 ? f = Math.round(r) : r !== v && s(v);
    const p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["r"])(t, f);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLayoutEffect"](()=>{
        c.current && (c.current.dataset.lkOrientation = i, c.current.style.setProperty("--lk-max-visible-tiles", f.toString()));
    }, [
        f,
        i
    ]), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("aside", {
        key: i,
        className: "lk-carousel",
        ref: c,
        ...a
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Ce, {
        tracks: p
    }, a.children));
}
function Ra({ value: t, onPinChange: n, onWidgetChange: a, children: c }) {
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ao"])(t);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("PinState Updated", {
            state: r.pin.state
        }), n && r.pin.state && n(r.pin.state);
    }, [
        r.pin.state,
        n
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"].debug("Widget Updated", {
            widgetState: r.widget.state
        }), a && r.widget.state && a(r.widget.state);
    }, [
        a,
        r.widget.state
    ]), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["af"].Provider, {
        value: r
    }, c);
}
const Ma = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ trackRef: n, ...a }, c) {
    const u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(n), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])(u, {
        bands: 7,
        loPass: 300
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("svg", {
        ref: c,
        width: "100%",
        height: "100%",
        viewBox: "0 0 200 90",
        ...a,
        className: "lk-audio-visualizer"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("rect", {
        x: "0",
        y: "0",
        width: "100%",
        height: "100%"
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("g", {
        style: {
            transform: `translate(${(200 - 7 * 10) / 2}px, 0)`
        }
    }, v.map((f, p)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("rect", {
            key: p,
            x: p * 10,
            y: 90 / 2 - f * 50 / 2,
            width: 6,
            height: f * 50
        }))));
});
function ya({ participants: t, ...n }) {
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, t.map((a)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aj"].Provider, {
            value: a,
            key: a.identity
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(n.children))));
}
function ba({ room: t, volume: n, muted: a }) {
    const c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["t"])([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Microphone,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.ScreenShareAudio,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Source.Unknown
    ], {
        updateOnlyOn: [],
        onlySubscribed: !0,
        room: t
    }).filter((r)=>!r.participant.isLocal && r.publication.kind === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Track"].Kind.Audio);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        style: {
            display: "none"
        }
    }, c.map((r)=>/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ne, {
            key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"])(r),
            trackRef: r,
            volume: n,
            muted: a
        })));
}
const Sa = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ childrenPosition: n = "before", children: a, ...c }, r) {
    const { name: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["v"])();
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        ref: r,
        ...c
    }, n === "before" && a, s, n === "after" && a);
});
function Gt(t) {
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(t, {
            className: "lk-toast"
        }), [
        t
    ]);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ...n
    }, t.children);
}
const Qt = (t)=>{
    const n = [];
    for(let a = 0; a < t; a++)n.push([
        a,
        t - 1 - a
    ]);
    return n;
}, fe = (t)=>[
        [
            Math.floor(t / 2)
        ],
        [
            -1
        ]
    ], Xt = (t, n, a)=>{
    const [c, r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0), [s, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        []
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (t === "thinking") o(fe(n));
        else if (t === "connecting" || t === "initializing") {
            const i = [
                ...Qt(n)
            ];
            o(i);
        } else o(t === "listening" ? fe(n) : t === void 0 || t === "speaking" ? [
            new Array(n).fill(0).map((i, d)=>d)
        ] : [
            []
        ]);
        r(0);
    }, [
        t,
        n
    ]);
    const l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let i = performance.now();
        const d = (u)=>{
            u - i >= a && (r((f)=>f + 1), i = u), l.current = requestAnimationFrame(d);
        };
        return l.current = requestAnimationFrame(d), ()=>{
            l.current !== null && cancelAnimationFrame(l.current);
        };
    }, [
        a,
        n,
        t,
        s.length
    ]), s[c % s.length];
}, Yt = /* @__PURE__ */ new Map([
    [
        "connecting",
        2e3
    ],
    [
        "initializing",
        2e3
    ],
    [
        "listening",
        500
    ],
    [
        "thinking",
        150
    ]
]), Jt = (t, n)=>{
    if (t === void 0) return 1e3;
    let a = Yt.get(t);
    if (a) switch(t){
        case "connecting":
            a /= n;
            break;
    }
    return a;
}, Kt = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ state: n, options: a, barCount: c = 15, trackRef: r, track: s, children: o, ...l }, i) {
    const d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(l, {
        className: "lk-audio-bar-visualizer"
    });
    let u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ae"])();
    (r || s) && (u = r || s);
    const v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])(u, {
        bands: c,
        loPass: 100,
        hiPass: 200
    }), f = (a == null ? void 0 : a.minHeight) ?? 20, p = (a == null ? void 0 : a.maxHeight) ?? 100, E = Xt(n, c, Jt(n, c) ?? 100);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: i,
        ...d,
        "data-lk-va-state": n
    }, v.map((h, m)=>o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$room$2d$BH8Rm3Ha$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"])(o, {
            "data-lk-highlighted": E.includes(m),
            "data-lk-bar-index": m,
            className: "lk-audio-bar",
            style: {
                height: `${Math.min(p, Math.max(f, h * 100 + 5))}%`
            }
        }) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
            key: m,
            "data-lk-highlighted": E.includes(m),
            "data-lk-bar-index": m,
            className: `lk-audio-bar ${E.includes(m) && "lk-highlighted"}`,
            style: {
                // TODO transform animations would be more performant, however the border-radius gets distorted when using scale transforms. a 9-slice approach (or 3 in this case) could work
                // transform: `scale(1, ${Math.min(maxHeight, Math.max(minHeight, volume))}`,
                height: `${Math.min(p, Math.max(f, h * 100 + 5))}%`
            }
        })));
}), Ca = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ children: n, disableSpeakingIndicator: a, onParticipantClick: c, trackRef: r, ...s }, o) {
    const l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(r), { elementProps: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"])({
        trackRef: l,
        htmlProps: s,
        disableSpeakingIndicator: a,
        onParticipantClick: c
    });
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: o,
        style: {
            position: "relative",
            minHeight: "160px"
        },
        ...i
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ak"].Provider, {
        value: l
    }, n ?? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a1"])(l) && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ne, {
        trackRef: l
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Kt, {
        barCount: 7,
        options: {
            minHeight: 8
        }
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-participant-metadata"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("div", {
        className: "lk-participant-metadata-item"
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](be, {
        trackRef: l
    }), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](K, null)), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](ye, {
        className: "lk-participant-metadata-item"
    })))));
});
function Ia(t) {
    const [n, a] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](void 0), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"])(t.room);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"](()=>{
        switch(c){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Reconnecting:
                a(/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](oe, {
                    className: "lk-spinner"
                }), " Reconnecting"));
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Connecting:
                a(/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](oe, {
                    className: "lk-spinner"
                }), " Connecting"));
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$livekit$2d$client$40$2$2e$15$2e$15_$40$types$2b$dom$2d$mediacapture$2d$record$40$1$2e$0$2e$22$2f$node_modules$2f$livekit$2d$client$2f$dist$2f$livekit$2d$client$2e$esm$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectionState"].Disconnected:
                a(/* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null, "Disconnected"));
                break;
            default:
                a(void 0);
                break;
        }
    }, [
        c
    ]), n ? /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](Gt, {
        className: "lk-toast-connection-state"
    }, n) : /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], null);
}
const xa = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](function({ entry: n, hideName: a = !1, hideTimestamp: c = !1, messageFormatter: r, ...s }, o) {
    var f, p, E, h;
    const l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"](()=>r ? r(n.message) : n.message, [
        n.message,
        r
    ]), i = !!n.editTimestamp, d = new Date(n.timestamp), u = typeof navigator < "u" ? navigator.language : "en-US", v = ((f = n.from) == null ? void 0 : f.name) ?? ((p = n.from) == null ? void 0 : p.identity);
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("li", {
        ref: o,
        className: "lk-chat-entry",
        title: d.toLocaleTimeString(u, {
            timeStyle: "full"
        }),
        "data-lk-message-origin": (E = n.from) != null && E.isLocal ? "local" : "remote",
        ...s
    }, (!c || !a || i) && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        className: "lk-meta-data"
    }, !a && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("strong", {
        className: "lk-participant-name"
    }, v), (!c || i) && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        className: "lk-timestamp"
    }, i && "edited ", d.toLocaleTimeString(u, {
        timeStyle: "short"
    }))), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        className: "lk-message-body"
    }, l), /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("span", {
        className: "lk-message-attachements"
    }, (h = n.attachedFiles) == null ? void 0 : h.map((m)=>m.type.startsWith("image/") && /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("img", {
            style: {
                maxWidth: "300px",
                maxHeight: "300px"
            },
            key: m.name,
            src: URL.createObjectURL(m),
            alt: m.name
        }))));
});
function Pa(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ap"])(t, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aq"])()).map((n, a)=>{
        if (typeof n == "string") return n;
        {
            const c = n.content.toString(), r = n.type === "url" ? /^http(s?):\/\//.test(c) ? c : `https://${c}` : `mailto:${c}`;
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"]("a", {
                className: "lk-chat-link",
                key: a,
                href: r,
                target: "_blank",
                rel: "noreferrer"
            }, c);
        }
    });
}
function Ta(t) {
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ar"].Provider, {
        value: t.session
    }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["R"].Provider, {
        value: t.session.room
    }, t.children));
}
;
 //# sourceMappingURL=components-CMpq9Z_u.mjs.map
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript) <export R as RoomAudioRenderer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RoomAudioRenderer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["R"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript) <export q as StartAudio>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StartAudio",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript) <export aB as useSessionContext>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSessionContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aB"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export a6 as useSessionMessages>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSessionMessages",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a6"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript) <export B as BarVisualizer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BarVisualizer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript) <export V as VideoTrack>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VideoTrack",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["V"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export C as useLocalParticipant>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLocalParticipant",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["C"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export t as useTracks>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTracks",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["t"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export X as useVoiceAssistant>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVoiceAssistant",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["X"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export w as useChat>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChat",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export M as useRemoteParticipants>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRemoteParticipants",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["M"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export x as usePersistentUserChoices>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePersistentUserChoices",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["x"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export h as useTrackToggle>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTrackToggle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["h"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export A as useLocalParticipantPermissions>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLocalParticipantPermissions",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["A"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript) <export w as useMaybeRoomContext>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMaybeRoomContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export e as useMediaDeviceSelect>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMediaDeviceSelect",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript) <export z as SessionProvider>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SessionProvider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$components$2d$CMpq9Z_u$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/components-CMpq9Z_u.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export a3 as useSession>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSession",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a3"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript) <export S as useAgent>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAgent",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["S"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$hooks$2d$CA8cirWq$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/hooks-CA8cirWq.mjs [app-ssr] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript) <export f as useRoomContext>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRoomContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$livekit$2b$components$2d$react$40$2$2e$9$2e$16_$40$livekit$2b$krisp$2d$noise$2d$filter$40$0$2e$2$2e$16_livekit$2d$client$40$2$2e$15$2e$15_$40$t_f7oueunlpdq5khmwra6mjg6ga4$2f$node_modules$2f40$livekit$2f$components$2d$react$2f$dist$2f$contexts$2d$CjCD4TaH$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@livekit+components-react@2.9.16_@livekit+krisp-noise-filter@0.2.16_livekit-client@2.15.15_@t_f7oueunlpdq5khmwra6mjg6ga4/node_modules/@livekit/components-react/dist/contexts-CjCD4TaH.mjs [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=1e56d_%40livekit_components-react_dist_31cb940a._.js.map