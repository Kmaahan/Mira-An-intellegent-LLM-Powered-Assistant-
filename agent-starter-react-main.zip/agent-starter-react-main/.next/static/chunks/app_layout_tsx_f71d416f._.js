(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ff8c00f0._.css",
  "static/chunks/node_modules__pnpm_1d0bf55c._.js",
  "static/chunks/_9f7ca432._.js"
],
    source: "dynamic"
});
