(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_00e9013b._.js",
  "static/chunks/36d90_livekit-client_dist_livekit-client_esm_mjs_cc9826ca._.js",
  "static/chunks/1e56d_@livekit_components-react_dist_1b0c5d30._.js",
  "static/chunks/26277_motion_dist_es_c72bd248._.js",
  "static/chunks/1189f_@phosphor-icons_react_dist_97df2cf4._.js",
  "static/chunks/24ae1_@radix-ui_react-select_dist_index_mjs_10045c58._.js",
  "static/chunks/node_modules__pnpm_07f72111._.js"
],
    source: "dynamic"
});
